package com.mpts.auth.struts.bundle.model;

import java.util.Map;

public class UserInfo {
	private String userId; 
	private String email; 
	private String userAlias;  
	
	private String firstName;  
	private String lastName;  
	private String authLevel;  
	private String issuerId;  
	private String corpId;  
	private String issuerGroupId;  
	private String companyGroupId;  
	private Map<String, String> securityQuestions;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	public String getUserAlias() {
		return userAlias;
	}
	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getIssuerId() {
		return issuerId;
	}
	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}
	public String getAuthLevel() {
		return authLevel;
	}
	public void setAuthLevel(String authLevel) {
		this.authLevel = authLevel;
	}
	public String getIssuerGroupId() {
		return issuerGroupId;
	}
	public void setIssuerGroupId(String issuerGroupId) {
		this.issuerGroupId = issuerGroupId;
	}
	public String getCorpId() {
		return corpId;
	}
	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}
	public Map<String, String> getSecurityQuestions() {
		return securityQuestions;
	}
	public void setSecurityQuestions(Map<String, String> securityQuestions) {
		this.securityQuestions = securityQuestions;
	}
	
	public String getCompanyGroupId() {
		return companyGroupId;
	}
	public void setCompanyGroupId(String companyGroupId) {
		this.companyGroupId = companyGroupId;
	}
	
}
