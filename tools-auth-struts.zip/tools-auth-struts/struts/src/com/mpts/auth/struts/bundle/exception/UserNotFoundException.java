package com.mpts.auth.struts.bundle.exception;

public class UserNotFoundException extends AuthException {

	private static final long serialVersionUID = -460713329426802038L;
	
	public UserNotFoundException(String error) {
		super(error);
	}
}
