package com.mpts.auth.struts.bundle.exception;

public class OTPExpiredException extends AuthException {

	private static final long serialVersionUID = -460713329426802038L;

	public OTPExpiredException() {
		this(null);
	}

	public OTPExpiredException(String error) {
		super(error);
	}
}
