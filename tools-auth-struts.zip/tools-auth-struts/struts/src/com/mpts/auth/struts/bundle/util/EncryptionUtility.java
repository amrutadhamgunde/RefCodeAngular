package com.mpts.auth.struts.bundle.util;

import java.util.HashMap;
import java.util.Map;

public class EncryptionUtility {
	protected static final Map<String, String> allEncyptionTypes = new HashMap<>();
	
	private EncryptionUtility() {
		
	}

	public static void loadAllEncryptionTypes() {
		allEncyptionTypes.put("SHA1", EncrytionTypes.SHA1);
		allEncyptionTypes.put("SHA2", EncrytionTypes.SHA256);
		allEncyptionTypes.put("SHA3", EncrytionTypes.SHA384);
		allEncyptionTypes.put("SHA5", EncrytionTypes.SHA512);
		allEncyptionTypes.put("MD2", EncrytionTypes.MD2);
		allEncyptionTypes.put("MD5", EncrytionTypes.MD5);
	}

	public static String getEncrptionType(String encrption) {
		return allEncyptionTypes.get(encrption);
	}
}
