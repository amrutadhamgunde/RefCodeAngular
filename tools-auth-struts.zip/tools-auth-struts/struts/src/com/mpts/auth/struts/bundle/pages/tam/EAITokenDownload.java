package com.mpts.auth.struts.bundle.pages.tam;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.ws.soap.SOAPFaultException;

import org.apache.log4j.Logger;

import com.mastercard.ssi.security.UserIdentity;
import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class EAITokenDownload extends ActionSupport {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(EAITokenDownload.class);
	private transient InputStream fileInputStream;
	private String tokenFileName;
	
	private static final String ERROR_MESSAGE = "errorMessage";

	public String showTokenDownloadPage(){
		return SUCCESS;
	}
	
	@Override
	public String execute() {
		String tamUserId = null;
		try {
			UserIdentity userIdentity = new UserIdentity();
			tamUserId = userIdentity.getUserID();
			tokenFileName = tamUserId +".sdtid";
		} catch (Exception ex) {
			logger.debug("Error while getting the User: " + Utility.getStackTrace(ex));
			logger.error("User is not authenticated so routing to login page.");
			logger.error(ex);
			
			ActionContext.getContext().put(ERROR_MESSAGE,
					CommonAuthService.getInstance().getProperty(Constants.USER_NOT_AUTHORIZED));
			return ERROR;
		}
		
		return getSoftToken(tamUserId);
	}
	
	private String getSoftToken(String tamUserId) {
		try {
			String softToken = CommonAuthService.getInstance().getAccessProvider().getSoftToken(tamUserId);
			if (!softToken.startsWith("<?xml version=\"1.0\"?>")) {
				softToken = "<?xml version=\"1.0\"?>" + softToken;
			}
			fileInputStream = new ByteArrayInputStream(softToken.getBytes());			
			return SUCCESS;
		} catch (SOAPFaultException e) {
			logger.debug(e.getFault().getFaultString());
			logger.debug("Error while getting Token File.");
			logger.error(Utility.getStackTrace(e));
			ActionContext.getContext().put(ERROR_MESSAGE, "Error occured while getting the token for the user.");
			return ERROR;
		} catch (AuthException ex) {
			logger.error(Utility.getStackTrace(ex));
			ActionContext.getContext().put(ERROR_MESSAGE, "Error getting the token for the user.");
			return ERROR;
		}
	}

	public String logout(){
		return SUCCESS;
	}
	
	public String appLogout(){
		return SUCCESS;
	}
	

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public String getTokenFileName() {
		return tokenFileName;
	}

	public void setTokenFileName(String tokenFileName) {
		this.tokenFileName = tokenFileName;
	}
}
