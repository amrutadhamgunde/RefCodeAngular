package com.mpts.auth.struts.bundle.pages.tam;

import com.opensymphony.xwork2.ActionSupport;

public abstract class CommonAction extends ActionSupport  {

	private static final long serialVersionUID = 1L;
	protected String tamUserId;
	protected String securityQuestion1;
	protected String securityQuestion2;
	protected String securityAnswer1;
	protected String securityAnswer2;
	protected String errorMessage;
	protected String oneTimePassword;

	public String getTamUserId() {
		return tamUserId;
	}

	public void setTamUserId(String tamUserId) {
		this.tamUserId = tamUserId;
	}

	public String getSecurityQuestion1() {
		return securityQuestion1;
	}

	public void setSecurityQuestion1(String securityQuestion1) {
		this.securityQuestion1 = securityQuestion1;
	}

	public String getSecurityQuestion2() {
		return securityQuestion2;
	}

	public void setSecurityQuestion2(String securityQuestion2) {
		this.securityQuestion2 = securityQuestion2;
	}

	public String getSecurityAnswer1() {
		return securityAnswer1;
	}

	public void setSecurityAnswer1(String securityAnswer1) {
		this.securityAnswer1 = securityAnswer1;
	}

	public String getSecurityAnswer2() {
		return securityAnswer2;
	}

	public void setSecurityAnswer2(String securityAnswer2) {
		this.securityAnswer2 = securityAnswer2;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getOneTimePassword() {
		return oneTimePassword;
	}

	public void setOneTimePassword(String oneTimePassword) {
		this.oneTimePassword = oneTimePassword;
	}
}
