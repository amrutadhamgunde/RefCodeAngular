package com.mpts.auth.struts.bundle.model;

public class LangLocale {

	private String locale;
	private String language;

	public LangLocale(String locale, String language) {
		this.locale = locale;
		this.language = language;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	
	@Override
	public String toString() {
		return language;
	}
}
