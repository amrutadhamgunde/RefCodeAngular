package com.mpts.auth.struts.bundle;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLSocketFactory;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import org.apache.log4j.Logger;
import org.picketlink.trust.jbossws.handler.SAML2Handler;

import com.mastercard.ssi.cspws.csr.CsrProvisioningService;
import com.mastercard.ssi.cspws.csr.CsrProvisioningService_Service;
import com.mastercard.ssi.cspws.priv.PrivateProvisioningService;
import com.mastercard.ssi.cspws.priv.PrivateProvisioningService_Service;
import com.mastercard.ssi.cspws.pub.PublicProvisioningService;
import com.mastercard.ssi.cspws.pub.PublicProvisioningService_Service;
import com.mpts.auth.struts.bundle.interceptor.LoggingHandler;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.Utility;

public class ConsumerProvisioningServiceProvider {
	private static final Logger logger = Logger.getLogger(ConsumerProvisioningServiceProvider.class);
	private static SSLSocketFactory sslSocketFactory;
	public static final String SSL_SOCKET_FACTORY = "com.sun.xml.internal.ws.transport.https.client.SSLSocketFactory";
	private static final String WSDL= "?wsdl";

	private static PublicProvisioningService publicProvisioningService;
	private static PrivateProvisioningService privateProvisioningService;
	private static CsrProvisioningService csrProvisioningService;
	
	private ConsumerProvisioningServiceProvider() {
	}

	public static void registerPublicService(String endPointURL) {
		if (publicProvisioningService != null) {
			return;
		}
		logger.info("Init public provisioning web service.");
		getSocketFactory();
		try {
			PublicProvisioningService_Service publicService = new PublicProvisioningService_Service(
					new URL(endPointURL + WSDL));
			publicProvisioningService = publicService.getPublicProvisioningServicePort();
			addLoggingHandler(endPointURL, (BindingProvider) publicProvisioningService, false);
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
		}
	}

	public static void registerPrivateService(String endPointURL) {
		if (privateProvisioningService != null) {
			return;
		}
		logger.info("Init private provisioning web service.");
		getSocketFactory();
		try {
			PrivateProvisioningService_Service privateService = new PrivateProvisioningService_Service(
					new URL(endPointURL + WSDL));
			privateProvisioningService = privateService.getPrivateProvisioningServicePort();
			addLoggingHandler(endPointURL, (BindingProvider) privateProvisioningService, true);
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
		}
	}

	public static void registerCSRService(String endPointURL) {
		if (csrProvisioningService != null) {
			return;
		}
		logger.info("Init CSR provisioning web service.");
		getSocketFactory();
		try {
			CsrProvisioningService_Service csrService = new CsrProvisioningService_Service(
					new URL(endPointURL + WSDL));
			csrProvisioningService = csrService.getCsrProvisioningServicePort();
			addLoggingHandler(endPointURL, (BindingProvider) csrProvisioningService, false);
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
		}
	}

	public static PublicProvisioningService getPublicProvisioningService() {
		if (publicProvisioningService == null) {
			registerPublicService(
					CommonAuthService.getInstance().getProperties().getProperty(Constants.PUBLIC_ENDPPOINT_URL));
		}
		return publicProvisioningService;
	}

	public static PrivateProvisioningService getPrivateProvisioningService() {
		if (privateProvisioningService == null) {
			registerPrivateService(
					CommonAuthService.getInstance().getProperties().getProperty(Constants.PRIVATE_ENDPPOINT_URL));
		}
		return privateProvisioningService;
	}

	public static CsrProvisioningService getCsrProvisioningService() {
		if (csrProvisioningService == null) {
			registerCSRService(
					CommonAuthService.getInstance().getProperties().getProperty(Constants.CSR_ENDPPOINT_URL));
		}
		return csrProvisioningService;
	}
	
	public static SSLSocketFactory getSocketFactory() {
		if (sslSocketFactory != null) {
			return sslSocketFactory;
		}
		
		sslSocketFactory = Utility.getSocketFactory(Constants.ESB_SECURITY_DOMAIN);
		return sslSocketFactory;
	}
	
	@SuppressWarnings("rawtypes")
	private static void addLoggingHandler(String endPointURL, BindingProvider bindingProvider, boolean addSAML2Handler) {
		bindingProvider.getRequestContext()
				.put(SSL_SOCKET_FACTORY, sslSocketFactory);
		bindingProvider.getRequestContext().put("com.sun.xml.ws.transport.https.client.SSLSocketFactory",
				sslSocketFactory);
		bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endPointURL);
		
		List<Handler> handlerList = bindingProvider.getBinding().getHandlerChain();
		if (handlerList == null) {
			handlerList = new ArrayList<>();
		}
		if(addSAML2Handler) {
			logger.info("Adding saml2handler");
			handlerList.add(new SAML2Handler());
		}
		
		String enableSoapMsg = CommonAuthService.getInstance().getProperties()
				.getProperty(Constants.ENABLE_SOAP_MSG, Constants.NO);
		if (enableSoapMsg.trim().equals(Constants.YES)) {
			logger.info("Adding logging handler");
			LoggingHandler loggingHandler = new LoggingHandler();
			handlerList.add(loggingHandler);
			logger.info("Added logging handler");
		}
		bindingProvider.getBinding().setHandlerChain(handlerList);
	}
	
}
