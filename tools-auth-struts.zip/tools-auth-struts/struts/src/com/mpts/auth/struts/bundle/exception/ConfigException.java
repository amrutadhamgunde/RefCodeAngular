package com.mpts.auth.struts.bundle.exception;

public class ConfigException extends AuthException {

	private static final long serialVersionUID = 1L;

	public ConfigException(String message) {
		super(message);
	}
	
}
