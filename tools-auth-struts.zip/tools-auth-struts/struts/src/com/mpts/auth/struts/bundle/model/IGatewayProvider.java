package com.mpts.auth.struts.bundle.model;

import com.mpts.auth.struts.bundle.exception.GatewayException;

public interface IGatewayProvider {

	/**
	 * The method is used to send the temporary password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * forgot password operation.
	 * 
	 * @param userAlias
	 * @param tempPassword
	 */
	void sendTempPasswordForgotPassword(String userAlias, String tempPassword) throws GatewayException;
	
	/**
	 * The method is used to send the temporary password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * create user operation.
	 * 
	 * @param userAlias
	 * @param tempPassword
	 */
	void sendTempPasswordCreateUser(String userAlias, String tempPassword) throws GatewayException;
	
	/**
	 * The method is used to send the temporary password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * reset password operation.
	 * 
	 * @param userAlias
	 * @param tempPassword
	 */
	void sendTempPasswordResetPassword(String userAlias, String tempPassword) throws GatewayException;

	/**
	 * The method is used to send the user alias to the user on their registered
	 * email and mobile number. The method will get called during the forgot
	 * user id operation.
	 * 
	 * @param userAlias
	 */
	void sendUserAlias(String userAlias) throws GatewayException;

	/**
	 * The method is used to send the one time password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * forgot user alias operation.
	 * 
	 * @param userAlias
	 * @param password
	 */
	void sendOTPForgotUserAlias(String userAlias, String password) throws GatewayException;
	
	/**
	 * The method is used to send the one time password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * forgot password operation.
	 * 
	 * @param userAlias
	 * @param password
	 */
	void sendOTPForgotPassword(String userAlias, String password) throws GatewayException;
	
	/**
	 * The method is used to send the one time password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * forgot token operation.
	 * 
	 * @param userAlias
	 * @param password
	 */
	void sendOTPForgotToken(String userAlias, String password) throws GatewayException;
	
	/**
	 * The method is used to send the one time password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * forgot pin operation.
	 * 
	 * @param userAlias
	 * @param password
	 */
	void sendOTPForgotPIN(String userAlias, String otp) throws GatewayException;
	
	/**
	 * The method is used to send the one time password to the user on their
	 * registered email and mobile number. The method will get called during the
	 * unlock user operation.
	 * 
	 * @param userAlias
	 * @param password
	 */
	void sendOTPUnlockUser(String userAlias, String otp) throws GatewayException;
	
	/**
	 * The method is used to notify user unlock to the user on their registered
	 * email and mobile number. The method will get called during the unlock
	 * user id operation.
	 * 
	 * @param userAlias
	 */
	void notifyUnlockUser(String userAlias, boolean unlockedByAdmin) throws GatewayException;
	
	/**
	 * The method is used to notify the change pin event on their registered
	 * email and mobile number. This method will get called during change pin
	 * operation
	 * 
	 * @param userAlias
	 * @throws Exception
	 */
	void notifyChangePin(String userAlias) throws GatewayException;
	
	/**
	 * The method is used to send the pin to the user on their
	 * registered email and mobile number. The method will get called during the
	 * first time token download operation.
	 * 
	 * @param userAlias
	 * @param pin
	 */
	void sendPIN(String userAlias, String pin) throws GatewayException;

	/**
	 * The method is used to send the temporary PIN to the user on their
	 * registered email and mobile number. The method will get called during the
	 * forgot PIN operation.
	 * 
	 * @param userAlias
	 * @param tempPIN
	 */
	void sendTempPINForgotPIN(String userAlias, String tempPIN) throws GatewayException;
	
	/**
	 * The method is used to send the temporary PIN to the user on their
	 * registered email and mobile number. The method will get called during the
	 * reset PIN operation.
	 * 
	 * @param userAlias
	 * @param tempPIN
	 */
	void sendTempPINResetPIN(String userAlias, String tempPIN) throws GatewayException;
}
