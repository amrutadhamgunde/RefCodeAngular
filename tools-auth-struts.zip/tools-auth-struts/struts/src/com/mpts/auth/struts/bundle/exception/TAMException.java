package com.mpts.auth.struts.bundle.exception;

public class TAMException extends AuthException {
	private static final long serialVersionUID = 1L;

	public TAMException(String error) {
		super(error);
	}

	public TAMException(Throwable t) {
		super(t);
	}

}
