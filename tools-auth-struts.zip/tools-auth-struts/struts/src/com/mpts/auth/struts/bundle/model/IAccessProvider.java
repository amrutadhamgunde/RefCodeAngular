package com.mpts.auth.struts.bundle.model;

import java.util.Map;

import com.mpts.auth.struts.bundle.exception.AMISOperationFailedException;
import com.mpts.auth.struts.bundle.exception.AuthException;


public interface IAccessProvider {

	/**
	 * This method is used to create the user.
	 * 
	 * @param userAlias
	 * @param password
	 * @param email
	 * @param firstName
	 * @param lastNname
	 * @return Returns the User-ID once the user is created.
	 */
	public String createUser(CreateUserInfo userInfo) throws AuthException;
	
	
	public String createUser(CreateUserInfo userInfo, String applicationId, String roleName) throws AuthException;
	
	/**
	 * The getSoftToken method is used to get the soft token for the user from
	 * TAM.
	 * 
	 * @param tamUserId
	 * @return
	 * @throws Exception
	 */
	public String getSoftToken(String tamUserId) throws AuthException;
	
	
	/**
	 * The resetPassword method is used to reset the password at the
	 * TAM end.
	 * 
	 * @param tamUserId
	 * @return
	 * @throws Exception
	 */
	public String resetPassword(String userAlias, String tamUserId) throws AuthException;
	
	/**
	 * The changeSecurityQuestions method is used to change the security questions at the
	 * TAM end.
	 * 
	 * @param tamUserId
	 * @param securityQuestions
	 * @return
	 * @throws Exception
	 */
	public boolean changeSecurityQuestions(String tamUserId, Map<String, String> securityQuestions) throws AuthException;
	
	/**
	 * This method is used to create the admin user.
	 * 
	 * @param userAlias
	 * @param password
	 * @param email
	 * @param firstName
	 * @param lastNname
	 * @return Returns the User-ID once the user is created.
	 */
	public String selfRegister(CreateUserInfo userInfo, Map<String, String> securityQuestions) throws AuthException;
	
	
	/**
	 * This method change the password of logged in user
	 * @return
	 * @param oldPassword 
	 * @param newPassword
	 * @throws Exception
	 */
	public boolean changePassword(String oldPassword, String newPassword) throws AuthException;
	
	public String getLoggedInTAMUserId() throws AuthException;

	/**
	 * This method change the PIN of logged in user
	 * @return
	 * @param pin
	 * @throws Exception
	 */
	public boolean changePIN(String userAlias, String newPIN) throws AuthException;

	/**
	 * This method unlock the locked user in RSA
	 * @return
	 * @throws Exception
	 */
	public boolean unlockUser(String userAlias, String tamUserId) throws AuthException;
	
	/**
	 * Enable the user in RSA server. This method should be called to enable the
	 * users which gets suspended in security question verification and OTP
	 * verification phase
	 * 
	 * @param userAlias
	 * @param tamUserId
	 * @return
	 * @throws Exception
	 */
	public boolean restoreUser(String userAlias, String tamUserId) throws AuthException;
	
	/**
	 * This method reset the PIN of user
	 * @param tamUserId - tam user id referred in RSA server to reset the pin
	 * @return
	 * @throws Exception
	 */
	public boolean resetPIN(String userAlias, String tamUserId) throws AuthException;
	
	/**
	 * This method is used to update the user properties in ldap.
	 * If passed as null then certain field will not be updated
	 * @param tamUserId
	 * @param userAlias
	 * @param email
	 * @param firstName
	 * @param lastName
	 * @return
	 * @throws Exception
	 */
	public boolean updateUser(String tamUserId, String userAlias, String email, String firstName, String lastName)
			throws AuthException;
	
	/**
	 * This method is used to delete the user.
	 * 
	 * @param tamUserId
	 * @return Returns whether user is deleted or not
	 * @throws AMISOperationFailedException 
	 */
	public boolean deleteUser(String tamUserId) throws AuthException;
}
