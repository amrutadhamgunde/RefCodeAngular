package com.mpts.auth.struts.bundle;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.ConfigException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.IAccessProvider;
import com.mpts.auth.struts.bundle.model.IDaoProvider;
import com.mpts.auth.struts.bundle.model.IGatewayProvider;
import com.mpts.auth.struts.bundle.model.LangLocale;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.util.LocalizedTextUtil;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class CommonAuthService {
	private static final Logger LOGGER = Logger.getLogger(CommonAuthService.class);
	
	private static final CommonAuthService commonAuthService = new CommonAuthService();
	private Map<String, String> internalPageMap = new HashMap<>();
	private List<String> cssReference = new ArrayList<>();
	private List<String> javascriptReference = new ArrayList<>();
	private Map<String,LangLocale> langMap;
	private Properties properties;
	private IGatewayProvider gatewayProvider;
	private IDaoProvider daoProvider;
	private IAccessProvider accessProvider;
	private WebResource apiService;
	private int maxNoAttempts = -1;
	private String favicon;
	private String pageTitle;
	private boolean amisEnabled;
	private String homePage;
	private String algorithmMode = "SHA-512";

	private CommonAuthService() {
	}

	public static CommonAuthService getInstance() {
		return commonAuthService;
	}

	public void intialize(File propertyFile) throws ConfigException {
		try (FileInputStream inputStream = new FileInputStream(propertyFile)){
			properties = new Properties();
			properties.load(inputStream);
			intialize(properties);
		} catch(IOException exception) {
			LOGGER.error(Utility.getStackTrace(exception));
			throw new ConfigException(exception.getMessage());
		}
	}

	public void intialize(Properties properties) {
		this.properties = properties;
		String provider = properties.getProperty(Constants.IDENTITY_PROVIDER);
		if (provider != null && provider.equals(Constants.TAM)) {
			String userType = getUserType();
			if (Constants.B2C.equals(userType)) {
				ConsumerProvisioningServiceProvider
						.registerPublicService(properties.getProperty(Constants.PUBLIC_ENDPPOINT_URL));
				ConsumerProvisioningServiceProvider
						.registerPrivateService(properties.getProperty(Constants.PRIVATE_ENDPPOINT_URL));
				ConsumerProvisioningServiceProvider
						.registerCSRService(properties.getProperty(Constants.CSR_ENDPPOINT_URL));
				accessProvider = TAMConsumerProvisioningImpl.getInstance();
			} else {
				IdentityMgmtServiceProvider.registerPublicAccessIdentityMgmt(properties, properties.getProperty(Constants.PUBLIC_ENDPPOINT_URL));
				IdentityMgmtServiceProvider.registerPrivateAccessIdentityMgmt(properties, properties.getProperty(Constants.PRIVATE_ENDPPOINT_URL));
				IdentityMgmtServiceProvider.registerSystemAccessIdentityMgmt(properties, properties.getProperty(Constants.SYSTEM_ENDPPOINT_URL));

				accessProvider = TAMAccessProviderImpl.getInstance();
				String amisEnabledFlag = properties.getProperty(Constants.AMIS_ENABLE);
				if (StringUtils.isNotEmpty(amisEnabledFlag) && Boolean.valueOf(amisEnabledFlag)) {
					this.amisEnabled = true;
					AMISAccessProvider.setAmisUrl(properties.getProperty(Constants.AMIS_API_URL));
					AMISAccessProvider.setAm3aUser(properties.getProperty(Constants.AMIS_AM3A_USER));
					AMISAccessProvider.setIdentityToken(properties.getProperty(Constants.AMIS_IDENTITY_TOKEN));
					String enableSoapMsg = properties.getProperty(Constants.ENABLE_SOAP_MSG, Constants.NO);
					if (Constants.YES.equalsIgnoreCase(enableSoapMsg)) {
						AMISAccessProvider.enableLogging();
					}
				} else {
					this.amisEnabled = false;
				}
			}
		} else {
			ClientConfig config = new DefaultClientConfig();
			Client client = Client.create(config);
			apiService = client.resource(UriBuilder.fromUri(properties.getProperty(Constants.API_URL)).build());
			accessProvider = new OpenIDAccessProviderImpl();
		}
	}

	public String getUserType() {
		return properties.getProperty(Constants.TYPE_OF_USER, Constants.B2B);
	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	public String getProperty(String key, String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}

	public Properties getProperties() {
		return properties;
	}

	public IGatewayProvider getGatewayProvider() {
		return gatewayProvider;
	}

	public void setGatewayProvider(IGatewayProvider gatewayProvider) {
		this.gatewayProvider = gatewayProvider;
	}

	public IDaoProvider getDaoProvider() {
		return daoProvider;
	}

	public void setDaoProvider(IDaoProvider daoProvider) {
		this.daoProvider = daoProvider;
	}

	public List<String> getCSSReference() {
		return cssReference;
	}

	public void addCSSReference(String url) {
		cssReference.add(url);
	}

	public void setCSSReference(List<String> cssReference) {
		this.cssReference = cssReference;
	}

	public List<String> getJavascriptReference() {
		return javascriptReference;
	}

	public void addJavascriptReference(String url) {
		javascriptReference.add(url);
	}

	public void setJavascriptReference(List<String> javascriptReference) {
		this.javascriptReference = javascriptReference;
	}

	public IAccessProvider getAccessProvider() {
		return accessProvider;
	}

	public void setAccessProvider(IAccessProvider accessProvider) {
		this.accessProvider = accessProvider;
	}

	public WebResource getAPIService() {
		return apiService;
	}

	public void registerPage(String opcode, String page) {
		if (StringUtils.isNotEmpty(opcode)) {
			internalPageMap.put(opcode, page);
		}
	}

	public String getPage(String opcode) {
		if (StringUtils.isNotEmpty(opcode)) {
			return internalPageMap.remove(opcode);
		}
		return null;
	}

	public String unRegisterPage(String opcode) {
		if (StringUtils.isNotEmpty(opcode)) {
			return internalPageMap.remove(opcode);
		}
		return null;
	}

	public String getFavicon() {
		return favicon;
	}

	public void setFavicon(String favicon) {
		this.favicon = favicon;
	}

	public String getPageTitle() {
		if(pageTitle == null) {
			pageTitle = Constants.LABEL_PAGE_TITLE;
		}
		return LocalizedTextUtil.findDefaultText(pageTitle, ActionContext.getContext().getLocale());
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public int getMaxNoAttempts() {
		if (maxNoAttempts == -1) {
			String maxAttempts = getProperty(Constants.MAX_NO_ATTEMPTS);
			if (StringUtils.isNotEmpty(maxAttempts)) {
				maxNoAttempts = Integer.valueOf(maxAttempts.trim());
			} else {
				maxNoAttempts = 3;
			}
		}
		return maxNoAttempts;
	}

	public boolean isAmisEnabled() {
		return amisEnabled;
	}
	
	public void registerHomePage(String homePage) {
		this.homePage = homePage;
	}

	public String getHomePage() {
		return homePage;
	}

	public String getAlgorithmMode() {
		return algorithmMode;
	}

	public void setAlgorithmMode(String algorithmMode) {
		this.algorithmMode = algorithmMode;
	}
	
	public String getLoginLabel() {
		if(getUserType().equals(Constants.B2C)) {
			return LocalizedTextUtil.findDefaultText("auth.common.link.label.loginLabel", ActionContext.getContext().getLocale());
		}
		
		return LocalizedTextUtil.findDefaultText("auth.common.link.label.tokenLoginLabel", ActionContext.getContext().getLocale());
	}
	
	public Map<String,LangLocale> getLanguages() {
		return langMap;
	}

	public void setLanguages(Map<String,LangLocale> langMap) {
		this.langMap = langMap;
	}
}
