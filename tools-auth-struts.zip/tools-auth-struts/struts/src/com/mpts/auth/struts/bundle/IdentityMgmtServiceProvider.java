package com.mpts.auth.struts.bundle;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.net.ssl.SSLSocketFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import org.apache.log4j.Logger;
import org.picketlink.trust.jbossws.handler.SAML2Handler;

import com.mastercard.aim.phase1.service.Phase1AccessIdentityManagement;
import com.mastercard.aim.phase1.service.Phase1AccessIdentityManagementService;
import com.mastercard.aim.phase1.service.Phase1PublicAccessIdentityManagement;
import com.mastercard.aim.phase1.service.Phase1PublicAccessIdentityManagementService;
import com.mastercard.aim.phase1.service.Phase1SystemAccessIdentityManagement;
import com.mastercard.aim.phase1.service.Phase1SystemAccessIdentityManagementService;
import com.mpts.auth.struts.bundle.interceptor.LoggingHandler;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.Utility;

public class IdentityMgmtServiceProvider {

	private static final Logger logger = Logger.getLogger(IdentityMgmtServiceProvider.class);
	
	private static final String SERVICE_NAME = "http://aim.mastercard.com/phase1/service/";
	private static final String WSDL = "?wsdl";
	
	private static final QName publicServiceQName = new QName(SERVICE_NAME,
			"Phase_1_Public_AccessIdentityManagementService");
	private static final QName privateServiceQName = new QName(SERVICE_NAME,
			"Phase_1_AccessIdentityManagementService");
	private static final QName systemServiceQName = new QName(SERVICE_NAME,
			"Phase_1_System_AccessIdentityManagementService");

	private static Phase1PublicAccessIdentityManagement publicAccessIdentityMgmt;
	private static Phase1SystemAccessIdentityManagement systemAccessIdentityMgmt;
	private static Phase1AccessIdentityManagement privateAccessIdentityMgmt;
	private static SSLSocketFactory sslSocketFactory;

	private IdentityMgmtServiceProvider() {
	}
	
	public static void registerPublicAccessIdentityMgmt(Properties properties, String endPointUrl) {
		if (publicAccessIdentityMgmt != null) {
			return;
		}
		getSocketFactory();
		logger.info("Init public web service.");
		try {
			Phase1PublicAccessIdentityManagementService publicService = new Phase1PublicAccessIdentityManagementService(
					new URL(endPointUrl + WSDL), publicServiceQName);
			publicAccessIdentityMgmt = publicService.getPhase1PublicAccessIdentityManagementPort();
			
			addLoggingHandler(endPointUrl, (BindingProvider) publicAccessIdentityMgmt, properties, false);
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
		}
	}
	
	public static void registerSystemAccessIdentityMgmt(Properties properties, String endPointUrl) {
		if (systemAccessIdentityMgmt != null) {
			return;
		}
		getSocketFactory();
		logger.info("Init system web service.");
		try {
			Phase1SystemAccessIdentityManagementService systemService = new Phase1SystemAccessIdentityManagementService(
					new URL(endPointUrl + WSDL), systemServiceQName);
			systemAccessIdentityMgmt = systemService.getPhase1SystemAccessIdentityManagementPort();
			
			addLoggingHandler(endPointUrl, (BindingProvider) systemAccessIdentityMgmt, properties, false);
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
		}
	}
	
	public static void registerPrivateAccessIdentityMgmt(Properties properties, String endPointUrl) {
		if (privateAccessIdentityMgmt != null) {
			return;
		}
		getSocketFactory();
		logger.info("Init private web service.");
		try {
			Phase1AccessIdentityManagementService privateService = new Phase1AccessIdentityManagementService(
					new URL(endPointUrl + WSDL), privateServiceQName);
			privateAccessIdentityMgmt = privateService.getPhase1AccessIdentityManagementPort();
			addLoggingHandler(endPointUrl, (BindingProvider) privateAccessIdentityMgmt, properties, true);
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
		}
	}

	public static Phase1PublicAccessIdentityManagement getPublicAccessIdentityMgmt() {
		if (publicAccessIdentityMgmt == null) {
			registerPublicAccessIdentityMgmt(CommonAuthService.getInstance().getProperties(), CommonAuthService
					.getInstance().getProperties().getProperty(Constants.PUBLIC_ENDPPOINT_URL));
		}
		return publicAccessIdentityMgmt;
	}

	public static Phase1SystemAccessIdentityManagement getSystemAccessIdentityMgmt() {
		if (systemAccessIdentityMgmt == null) {
			registerSystemAccessIdentityMgmt(CommonAuthService.getInstance().getProperties(), CommonAuthService
					.getInstance().getProperties().getProperty(Constants.SYSTEM_ENDPPOINT_URL));
		}
		return systemAccessIdentityMgmt;
	}

	public static Phase1AccessIdentityManagement getPrivateAccessIdentityMgmt() {
		if (privateAccessIdentityMgmt == null) {
			registerPrivateAccessIdentityMgmt(CommonAuthService.getInstance().getProperties(), CommonAuthService
					.getInstance().getProperties().getProperty(Constants.PRIVATE_ENDPPOINT_URL));
		}
		return privateAccessIdentityMgmt;
	}
	
	public static SSLSocketFactory getSocketFactory() {
		if (sslSocketFactory != null) {
			return sslSocketFactory;
		}
		
		sslSocketFactory = Utility.getSocketFactory(Constants.ESB_SECURITY_DOMAIN);
		return sslSocketFactory;
	}
	
	@SuppressWarnings("rawtypes")
	private static void addLoggingHandler(String endPointUrl,
			BindingProvider bindingProvider, Properties properties, boolean addSAML2Handler) {
		bindingProvider.getRequestContext().put("com.sun.xml.internal.ws.transport.https.client.SSLSocketFactory", sslSocketFactory);
		bindingProvider.getRequestContext().put("com.sun.xml.ws.transport.https.client.SSLSocketFactory", sslSocketFactory);
		bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endPointUrl);
		
		List<Handler> handlerList = bindingProvider.getBinding().getHandlerChain();
		if (handlerList == null) {
			handlerList = new ArrayList<>();
		}
		if(addSAML2Handler) {
			logger.info("Adding saml2handler");
			handlerList.add(new SAML2Handler());
		}
		
		String enableSoapMsg = properties
				.getProperty(Constants.ENABLE_SOAP_MSG, Constants.NO);
		if (enableSoapMsg.trim().equals(Constants.YES)) {
			logger.info("Adding logging handler");
			LoggingHandler loggingHandler = new LoggingHandler();
			handlerList.add(loggingHandler);
			logger.info("Added logging handler");
		}
		bindingProvider.getBinding().setHandlerChain(handlerList);
	}
}
