package com.mpts.auth.struts.bundle.pages.tam;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.mastercard.ssi.security.UserIdentity;
import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.Errors;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginRouter extends ActionSupport {

	private static final long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger(LoginRouter.class);
	
	public static final String CARD_HOLDER_LOGIN = "cardholderlogin";
	public static final String TOKEN_LOGIN = "tokenlogin";
	public static final String PIN_CHANGE_SUCCESS = "pinchangesucess";
	public static final String REDIRECT = "redirect";
	public static final String LOGOUT = "logout";
	public static final String TOKEN_DOWNLOAD_LOGIN = "tokendownloadlogin";
	public static final String PIN_CHANGE = "pinchange";
	public static final String PASS_EXPIRED = "passwordexpired";
	public static final String FORGOT_PASS = "forgotpassword";
	
	public static final String PASS = "password";
	public static final String PIN = "PIN";

	private String tamUserId;
	private String redirectURL;
	private String error;
	private String brandingContext;
	
	@Override
	public String execute() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		if(selectLanguage != null && selectLanguage.length > 0){
			
			String actionName = context.getName();
			
			return (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
		}
		
		HttpServletRequest request = ServletActionContext.getRequest();
		String portalType = CommonAuthService.getInstance().getUserType();
		String opcode = request.getParameter(Constants.TAM_OPCODE);

		String loginType = updateJunctionAndApp(request, opcode, portalType);

		String successfulLoginAction = CommonAuthService.getInstance().getProperty(Constants.SUCCESSFUL_LOGIN_ACTION);
		String junction = (String) ActionContext.getContext().getSession().get(Constants.JUNCTION);
		if (StringUtils.isEmpty(opcode)) {
			return redirectAlreadyLogin(successfulLoginAction, portalType, junction);
		}

		String pageUrl = CommonAuthService.getInstance().getPage(opcode);
		if (StringUtils.isNotEmpty(pageUrl)) {
			redirectURL = pageUrl;
			return REDIRECT;
		}
		
		return forward(request, opcode, loginType, portalType, successfulLoginAction, junction);
	}

	private String forward(HttpServletRequest request, String opcode, String loginType, String portalType,
			String successfulLoginAction, String junction) {
		String result;
		if (opcode.matches(Constants.LOGIN + "|" + Constants.ACCOUNT_LOCKED + "|" + Constants.ACCOUNT_INACTIVATED)) {
			String errorMsg = Utility.getErrorText(request);
			if(errorMsg != null) {
				addActionError(getLoginErrorMessage(request, errorMsg, portalType));
			}
			result =  forwardToLoginPage(portalType, opcode); 
		} else if (opcode.matches(Constants.TOKEN_LOGIN + "|" + Constants.NEXT_TOKEN + "|" + Constants.PASS_CHG_REQ_SUCCESS)) {
			String errorMsg = Utility.getErrorText(request);
			if (errorMsg != null) {
				errorMsg = getTokenLoginErrorMessage(request, errorMsg, portalType);
				addActionError(errorMsg);
			}
			result = forwardToLoginPage(portalType);
		} else if (opcode.matches(Constants.PASS_EXPIRED + "|" + Constants.PASS_CHG_REQ_FAILED)) {
			result = forwardToPassPINChangePage(request, loginType);
		} else if (opcode.equals(Constants.LOGOUT)) {
			result = forwardToLogoutPage();
		} else if (opcode.matches(Constants.LOGIN_SUCCESS + "|" + Constants.HELP)) {
			result = redirectToSuccessfulLogin(junction, successfulLoginAction);
		} else {
			result = forwardToErrorPage(opcode, request);
		}
		return result;
	}
	
	private String getLoginErrorMessage(HttpServletRequest request, String errorMsg, String portalType) {

		String errorCode = request.getParameter("ERROR_CODE");
		String tamId = request.getParameter("USERNAME");
		if (null != errorCode && StringUtils.isNotEmpty(tamId)) {
			if ("0x132120c8".equals(errorCode)) {
				return CommonAuthService.getInstance().getProperty(Constants.AUTH_FAILED,
						"Authentication failed. Please enter valid User ID or Password.");
			} else if (Constants.B2C.equals(portalType) && "0x132120e9".equals(errorCode)) {
				return CommonAuthService.getInstance().getProperty(Constants.ACCOUNT_LOCKED_MESSAGE,
						"User account is locked.");
			}
		}
		return errorMsg;
	}

	private String getTokenLoginErrorMessage(HttpServletRequest request, String errorMsg, String portalType) {
		String errorMessage = errorMsg;
		try {
			String errorCode = request.getParameter("ERROR_CODE");
			String tamId = request.getParameter("USERNAME");
			if (null != errorCode && "0x132120c8".equals(errorCode) && StringUtils.isNotEmpty(tamId)) {
				return getErrorMessage(portalType, tamId);
			}
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			errorMessage = CommonAuthService.getInstance().getProperty(Constants.AUTH_FAILED,
					"Authentication failed. Please enter valid User ID or Password.");
		}
		return errorMessage;
	}
	
	private String getErrorMessage(String portalType, String tamId) throws AuthException {

		if (Constants.B2B.equals(portalType)) {
			int userStatus = AMISAccessProvider.isUserValid(tamId);
			if (userStatus == 1) {
				return CommonAuthService.getInstance().getProperty(Constants.USER_SUSPENDED,
						"User is suspended. Please contact administrator.");
			} else if (userStatus == 2) {
				return CommonAuthService.getInstance().getProperty(Constants.ACCOUNT_LOCKED_MESSAGE,
						"User account is locked");
			}
		}
		return CommonAuthService.getInstance().getProperty(Constants.AUTH_FAILED,
				"Authentication failed. Please enter valid User ID or Password.");
	}

	private String forwardToPassPINChangePage(HttpServletRequest request, String loginType) {
		String errorMsg = Utility.getErrorText(request);
		String errorCode = request.getParameter("ERROR_CODE");

		if (loginType.equals(Constants.TOKEN)) {
			if(errorMsg != null) {
				if (StringUtils.isNotEmpty(errorCode) && "0x132120cc".equals(errorCode)) {
					errorMsg = CommonAuthService.getInstance().getProperty(Constants.PIN_EXPIRED,
							"The temporary pin has expired and needs to be changed. Please change the pin now.");
				} else if (errorMsg.contains(PASS)) {
					errorMsg = errorMsg.replace(PASS, PIN);
				}
				addActionError(errorMsg);
			}
			return PIN_CHANGE;
		} else if (loginType.equals(Constants.PASS)) {
			if (errorMsg != null) {
				if (StringUtils.isNotEmpty(errorCode) && "0x132120cc".equals(errorCode)) {
					errorMsg = CommonAuthService.getInstance().getProperty(Constants.PAWD_EXPIRED,
							"The temporary password has expired and needs to be changed. Please change the password now.");
				}
				addActionError(errorMsg);
			}
			return PASS_EXPIRED;
		}
		return ERROR;
	}

	private String forwardToLogoutPage() {
		String junctionName = (String)ActionContext.getContext().getSession().get(Constants.JUNCTION);
		ActionContext.getContext().getSession().put(Constants.LOGOUTJUNCTION, junctionName);
		String appName = (String)ActionContext.getContext().getSession().get(Constants.APP);
		ActionContext.getContext().getSession().put(Constants.LOGOUTAPP, appName);
		
		return LOGOUT;
	}

	private String redirectToSuccessfulLogin(String junction, String successfulLoginAction) {
		if (null != successfulLoginAction && !"".equals(successfulLoginAction)) {
			redirectURL = "/" + junction + "/" + successfulLoginAction;
			return REDIRECT;
		} else {
			logger.info(
					"Successful login action is not defined, So taking default action name 'successfulogin'");
			redirectURL = "/" + junction + "/successfulogin";
			return REDIRECT;
		}
	}

	private String forwardToErrorPage(String opcode, HttpServletRequest request) {
		if (opcode.equals(Constants.ERROR)) {
			error = Utility.getErrorText(request);
		} else {
			error = Errors.getErrorMessage(opcode);
		}
		ActionContext.getContext().put("errorMessage", error);
		return ERROR;
	}

	private String redirectAlreadyLogin(String successfulLoginAction, String portalType, String junction) {
		try {
			UserIdentity userIdentity = new UserIdentity();
			String userId = userIdentity.getUserID();
			if (StringUtils.isNotEmpty(userId)) {
				if (StringUtils.isNotEmpty(successfulLoginAction)) {
					redirectURL = "/" + junction + "/" + successfulLoginAction;
					return REDIRECT;
				} else {
					logger.info(
							"Successful login action is not defined, So taking default action name 'successfulogin'");
					redirectURL = "/" + junction + "/successfulogin";
					return REDIRECT;
				}
			}
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
			logger.error("User is not authenticated so routing to login page.");
		}
		
		return forwardToLoginPage(portalType);
	}

	private String forwardToLoginPage(String portalType) {
		if (portalType.equals(Constants.B2C)) {
			return CARD_HOLDER_LOGIN;
		} else {
			String cameFromPinChangeSuccess = (String) ServletActionContext.getRequest().getSession()
					.getAttribute(Constants.PIN_CHANGE_SUCCESS);
			ServletActionContext.getRequest().getSession().removeAttribute(Constants.PIN_CHANGE_SUCCESS);
			if (StringUtils.isNotEmpty(cameFromPinChangeSuccess) && "yes".equals(cameFromPinChangeSuccess)) {
				return PIN_CHANGE_SUCCESS;
			}
			return TOKEN_LOGIN;
		}
	}

	private String forwardToLoginPage(String portalType, String opcode) {

		if (portalType.equals(Constants.B2B)) {
			if (opcode.equals(Constants.LOGIN) || Constants.ACCOUNT_LOCKED.equals(opcode)) {
				return TOKEN_DOWNLOAD_LOGIN;
			}
			String cameFromPinChangeSuccess = (String) ServletActionContext.getRequest().getSession()
					.getAttribute(Constants.PIN_CHANGE_SUCCESS);
			ServletActionContext.getRequest().getSession().removeAttribute(Constants.PIN_CHANGE_SUCCESS);
			if (StringUtils.isNotEmpty(cameFromPinChangeSuccess) && "yes".equals(cameFromPinChangeSuccess)) {
				return PIN_CHANGE_SUCCESS;
			}
			return TOKEN_LOGIN;
		} else {
			return CARD_HOLDER_LOGIN;
		}
	}

	private String updateJunctionAndApp(HttpServletRequest request, String opcode, String portalType) {
		Cookie loginFormTypeCookie = null;
		Cookie junctionCookie = null;
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if ("login-form-type".equals(cookie.getName())) {
					loginFormTypeCookie = cookie;
				} else if ("junction".equals(cookie.getName())) {
					junctionCookie = cookie;
				}
			}
		}
		
		Object jun = ActionContext.getContext().getSession().get(Constants.JUNCTION);
		if (jun == null && StringUtils.isNotEmpty(opcode)) {
			if (opcode.equals(Constants.LOGOUT)) {
				if (junctionCookie != null && !"".equals(junctionCookie.getValue())) {
					ActionContext.getContext().getSession().put(Constants.JUNCTION, junctionCookie.getValue());
				}
			} else {
				String url =  request.getParameter(Constants.URL);
				updateLogoutJuctionAndApp(url);
			}
		}
		return getLoginType(loginFormTypeCookie,portalType);
	}
	
	private void updateLogoutJuctionAndApp(String url) {
		if (StringUtils.isNotEmpty(url)) {
			String url1 = url;
			if (url.startsWith("/")) {
				url1 = url.substring(1);
			}
			int slashIndex = url1.indexOf('/');
			if (slashIndex != -1) {
				ActionContext.getContext().getSession().put(Constants.JUNCTION,
						url1.substring(0, slashIndex));
				ActionContext.getContext().getSession().remove(Constants.LOGOUTJUNCTION);
				String url2 = url1.substring(slashIndex + 1);
				slashIndex = url2.indexOf('/');
				if (slashIndex != -1) {
					ActionContext.getContext().getSession().put(Constants.APP,
							url2.substring(0, slashIndex));
					Utility.setStaticAppName(url2.substring(0, slashIndex));
					ActionContext.getContext().getSession().remove(Constants.LOGOUTAPP);
				}
			}
		}
	}

	private String getLoginType(Cookie loginFormTypeCookie, String portalType) {
		String loginType;
		if (loginFormTypeCookie != null && StringUtils.isNotEmpty(loginFormTypeCookie.getValue())) {
			loginType = loginFormTypeCookie.getValue();
		} else {
			if (portalType.equals(Constants.B2C)) {
				loginType = Constants.PASS;
			} else {
				loginType = Constants.TOKEN;
			}
		}
		return loginType;
	}

	public String getTamUserId() {
		return tamUserId;
	}

	public void setTamUserId(String tamUserId) {
		this.tamUserId = tamUserId;
	}

	public String getRedirectURL() {
		return redirectURL;
	}

	public void setRedirectURL(String redirectURL) {
		this.redirectURL = redirectURL;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getBrandingContext() {
		return brandingContext;
	}

	public void setBrandingContext(String brandingContext) {
		this.brandingContext = brandingContext;
	}

}
