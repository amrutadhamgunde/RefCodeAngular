package com.mpts.auth.struts.bundle.api;

public enum UserStatus {
	ENABLE, LOCK
}
