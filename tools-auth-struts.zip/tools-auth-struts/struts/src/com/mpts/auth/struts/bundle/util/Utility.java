package com.mpts.auth.struts.bundle.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Collection;
import java.util.Random;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.mastercard.aim.exception.phase1.AimError;
import com.mastercard.aim.exception.phase1.AimErrorList;
import com.mastercard.aim.phase1.service.AimErrorResponse;
import com.mastercard.security.MasterCardSocketFactoryService;
import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.LangLocale;
import com.mpts.auth.struts.bundle.model.UserInfo;

public class Utility {

	private static Logger logger = Logger.getLogger(Utility.class);
	private static SecureRandom secureRandom = new SecureRandom();
	private static String appName;
	
	private Utility() {
		
	}

	public static String getStackTrace(Throwable aThrowable) {
		final Writer result = new StringWriter();
		if (aThrowable instanceof AimErrorResponse) {
			AimErrorResponse response = (AimErrorResponse) aThrowable;
			AimErrorList aimErrorList = response.getFaultInfo();
			for (AimError error : aimErrorList.getAimErrorList()) {
				try {
					result.append("AimErrorCode:" + error.getCode());
					result.append("AimErrorDescription:" + error.getDescription());
				} catch (Exception e) {
					logger.error(e);
				}
			}
		}
		final PrintWriter printWriter = new PrintWriter(result);
		aThrowable.printStackTrace(printWriter);
		return result.toString();
	}

	public static String loadPwdFromCryptoVault(String label) {
		try {
			StringBuilder password = new StringBuilder();
			String command = "mcgetpw -label " + label;
			logger.debug("Command: " + command);

			int asciiChar;

			Process child = Runtime.getRuntime().exec(command);
			BufferedReader streamReader = new BufferedReader(new InputStreamReader(child.getInputStream()));

			while ((asciiChar = streamReader.read()) != -1) {
				char character = (char) asciiChar;

				if (character == '\n')
					break;
				password.append(character);
			}

			streamReader.close();
			if (child.waitFor() != 0) {
				logger.debug("Exit value: " + child.exitValue());
			}
			return password.toString();
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}

	public static String getErrorText(HttpServletRequest request) {
		String errorCode = request.getParameter("ERROR_CODE");
		if (StringUtils.isNotEmpty(errorCode) && !"0x00000000".equals(errorCode)) {
			String errorText = request.getParameter("ERROR_TEXT");
			if (StringUtils.isNotEmpty(errorText)) {
				if(errorText.indexOf("   ") >= 0){
					errorText = errorText.substring(errorText.indexOf("   ") + 3);	
				}
				return errorText;
			}
		}
		return null;
	}

	public static byte[] hexStr2Bytes(String hex) {
		// Adding one byte to get the right conversion
		// Values starting with "0" can be converted
		byte[] bArray = new BigInteger("10" + hex, 16).toByteArray();

		// Copy all the REAL bytes, not the "first"
		byte[] ret = new byte[bArray.length - 1];
		for (int i = 0; i < ret.length; i++)
			ret[i] = bArray[i + 1];
		return ret;
	}

	/**
	 * This method is used to generate the secure random number for OTP.
	 * 
	 * @param numBytes
	 * @return
	 */
	public static byte[] generateRandomNumber(int numBytes) {
		return secureRandom.generateSeed(numBytes);
	}
	
	public static String generatePIN(){
		// generate a 4 digit integer 1000 <10000
		Random random = new Random();
		int randomNumber = 1000 + random.nextInt(8999);

        //Store integer in a string
       return String.valueOf(randomNumber);
	}

	/**
	 * The \b boundary helps check that we are the start of the digits (there
	 * are other ways to do this, but here this will do).<br/>
	 * (\d{2}) captures two digits to Group 1 (the two first digits)<br/>
	 * \d+ matches any number of digits<br/>
	 * (\d) captures the final digit to Group 2<br/>
	 * In the replacement, $1 and $2 contain the content matched by Groups 1 and
	 * 2
	 * 
	 * @param mobileNo
	 * @return
	 */
	public static String maskMobileNo(String mobileNo) {
		if(mobileNo == null) {
			return "";
		}
		return mobileNo.replaceAll("\\b(\\d{2})\\d+(\\d)", "$1*******$2");
	}

	/**
	 * The \b boundary helps check that we are the start of the characters
	 * (there are other ways to do this, but here this will do).<br/>
	 * (\w) captures one word char to Group 1 <br/>
	 * [^@]+ matches one or more chars that are not @ <br/>
	 * \S+ matches one or more chars that are not whitespace chars <br/>
	 * (\.[^\s.]+) captures a dot and any chars that are not a dot or space to
	 * Group 2 <br/>
	 * In the replacement, $1 and $2 contain the content matched by Groups 1 and
	 * 2
	 * 
	 * @param emailId
	 * @return
	 */
	public static String maskEmailId(String emailId) {
		if(emailId == null) {
			return "";
		}
		return emailId.replaceAll("\\b(\\w)[^@]+@\\S+(\\.[^\\s.]+)", "$1***@****$2");
	}
	
	
	public static void setStaticAppName(String appName) {
		Utility.appName = appName;
	}
	
	public static String getStaticAppName() {
		return appName ;
	}
	
	public static String getLanguageName(LangLocale locale) {
		if (locale == null) {
			return "";
		}
		return CommonAuthService.getInstance().getLanguages().get(locale.getLocale()).getLanguage();
	}
	
	@SuppressWarnings("rawtypes")
	public static boolean isEmpty(Collection collection) {
		return (collection == null) || (collection.isEmpty());
	}
	
	public static UserInfo getUserInfo(com.mastercard.aim.messages.phase1.UserInfo userInfo) {
		UserInfo userInfo2 = new UserInfo();
		
		userInfo2.setUserId(userInfo.getUserId());
		userInfo2.setUserAlias(userInfo.getUserAlias());
		userInfo2.setFirstName(userInfo.getFirstName());
		userInfo2.setLastName(userInfo.getLastName());
		userInfo2.setEmail(userInfo.getEmail());
		userInfo2.setCorpId(userInfo.getCorpId());
		userInfo2.setIssuerId(userInfo.getIssuerId());
		userInfo2.setIssuerGroupId(userInfo.getIssuerGroupId());
		userInfo2.setCompanyGroupId(userInfo.getCompanyGroupId());
		
		return userInfo2;
	}
	
	public static SSLSocketFactory getSocketFactory(String esbSecurityDomainKey) {		
		String socketFactoryType = CommonAuthService.getInstance().getProperty(Constants.SOCKET_FACTORY_TYPE);
		SSLSocketFactory sslSocketFactory = null;
		if (StringUtils.isNotEmpty(socketFactoryType) && socketFactoryType.equals(Constants.INTERNAL)) {
			try {
				sslSocketFactory = HttpsURLConnection.getDefaultSSLSocketFactory();
			} catch (Exception e) {
				logger.error(Utility.getStackTrace(e));
			}
		} else {
			try {
				String sslDomain = MasterCardSocketFactoryService.SYSTEM_DEFAULT_MSSL;
				String esbSecurityDomain = CommonAuthService.getInstance().getProperty(esbSecurityDomainKey);
				if (StringUtils.isNotEmpty(esbSecurityDomain)) {
					sslDomain = esbSecurityDomain;
				}
				sslSocketFactory = MasterCardSocketFactoryService.getSocketFactoryForDomain(sslDomain);
				HttpsURLConnection.setDefaultSSLSocketFactory(sslSocketFactory);
				HttpsURLConnection.setDefaultHostnameVerifier(getHostNameVerifier());
			} catch (Exception e) {
				logger.error(Utility.getStackTrace(e));
			}
		}
		return sslSocketFactory;
	}
	
	public static HostnameVerifier getHostNameVerifier() {
		return new HostnameVerifier() {
			@Override
			public boolean verify(String urlHostName, SSLSession sslSession) {
				logger.warn("Warning: URL Host: " + urlHostName + " vs. " + sslSession.getPeerHost());
				return true;
			}
		};
	}
}
