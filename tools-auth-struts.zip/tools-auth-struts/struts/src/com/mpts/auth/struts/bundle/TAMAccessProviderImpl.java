package com.mpts.auth.struts.bundle;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.mastercard.aim.domain.phase1.PasswordPolicy;
import com.mastercard.aim.domain.phase1.SecurityQuestion;
import com.mastercard.aim.domain.phase1.UserRole;
import com.mastercard.aim.messages.phase1.CreateUserRequest;
import com.mastercard.aim.messages.phase1.CreateUserResponse;
import com.mastercard.aim.messages.phase1.DeleteUserRequest;
import com.mastercard.aim.messages.phase1.DeleteUserResponse;
import com.mastercard.aim.messages.phase1.ForgotPasswordRequest;
import com.mastercard.aim.messages.phase1.ForgotPasswordResponse;
import com.mastercard.aim.messages.phase1.GetSecurityQuestionsRequest;
import com.mastercard.aim.messages.phase1.GetSecurityQuestionsResponse;
import com.mastercard.aim.messages.phase1.GetSoftTokenRequest;
import com.mastercard.aim.messages.phase1.GetSoftTokenResponse;
import com.mastercard.aim.messages.phase1.GetUserInfoRequest;
import com.mastercard.aim.messages.phase1.ModifyUserRequest;
import com.mastercard.aim.messages.phase1.ModifyUserResponse;
import com.mastercard.aim.messages.phase1.SearchUserRequest;
import com.mastercard.aim.messages.phase1.SearchUserResponse;
import com.mastercard.aim.messages.phase1.SelfRegisterRequest;
import com.mastercard.aim.messages.phase1.SelfRegisterResponse;
import com.mastercard.aim.messages.phase1.SetSoftTokenRequest;
import com.mastercard.aim.messages.phase1.SetSoftTokenResponse;
import com.mastercard.aim.phase1.service.AimErrorResponse;
import com.mastercard.ssi.security.UserIdentity;
import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.AMISOperationFailedException;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.CreateUserFailedException;
import com.mpts.auth.struts.bundle.exception.GatewayException;
import com.mpts.auth.struts.bundle.exception.TAMException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.CreateUserInfo;
import com.mpts.auth.struts.bundle.model.IAccessProvider;
import com.mpts.auth.struts.bundle.model.UserInfo;
import com.mpts.auth.struts.bundle.util.Utility;

public class TAMAccessProviderImpl implements IAccessProvider {

	private static Logger logger = Logger.getLogger(TAMAccessProviderImpl.class);

	private static final String USER_ALIAS = "userAlias";
	private static final String EMAIL = "email";
	
	private static TAMAccessProviderImpl instance = new TAMAccessProviderImpl();

	private TAMAccessProviderImpl() {

	}

	public static TAMAccessProviderImpl getInstance() {

		return instance;
	}

	/**
	 * This method is used to create the user.
	 * 
	 * @param userAlias
	 * @param password
	 * @param email
	 * @param firstName
	 * @param lastNname
	 * @return Returns the User-ID once the user is created.
	 */
	@Override
	public String createUser(CreateUserInfo userInfo) throws AuthException {

		Properties properties = CommonAuthService.getInstance().getProperties();
		String applicationId = properties.getProperty(Constants.APPLICATION_ID);
		String roleName = properties.getProperty(Constants.ROLE_NAME);
		return createUser(userInfo, applicationId, roleName);
	}

	@Override
	public String createUser(CreateUserInfo userInfo, String applicationId, String roleName) throws AuthException {

		logger.info("CreateUser call for the user : " + userInfo.getUserAlias());
		try {
			CreateUserRequest request = new CreateUserRequest();
			request.setEmail(userInfo.getEmail());
			request.setLastName(userInfo.getLastName());
			request.setFirstName(userInfo.getFirstName());
			request.setUserAlias(userInfo.getUserAlias());
			request.setPassword(userInfo.getPassword());
			
			List<UserRole> userRoles = new ArrayList<>();
			UserRole userRole = new UserRole();
			userRole.setApplicationId(applicationId);
			userRole.setRoleName(roleName);
			userRoles.add(userRole);

			request.getUserRoles().addAll(userRoles);

			Properties properties = CommonAuthService.getInstance().getProperties();

			request.setIssuerGroupId(properties.getProperty(Constants.ISSUER_GROUP_ID));
			request.setCompanyGroupId(properties.getProperty(Constants.COMPANY_GROUP_ID));
			request.setIssuerId(properties.getProperty(Constants.ISSUER_ID));
			request.setCorpId(properties.getProperty(Constants.CORP_ID));
			
			PasswordPolicy passwordPolicy = new PasswordPolicy();
			passwordPolicy.setPasswordMaxAgeDays(userInfo.getPasswordMaxAgeDays());
			JAXBElement<PasswordPolicy> passwordPolicyElement = new JAXBElement<>(new QName("passwordPolicy"),
					PasswordPolicy.class, passwordPolicy);
			request.setPasswordPolicy(passwordPolicyElement);
			request.setSuspended(Boolean.valueOf(properties.getProperty(Constants.SUSPEND)));
			CreateUserResponse response = IdentityMgmtServiceProvider.getPrivateAccessIdentityMgmt()
					.createUser(request);

			logger.info("TAM User " + response.getUserId() + " is created for user : " + userInfo.getUserAlias());
			String tamUserId = response.getUserId();

			// create and set the token for the TAM user
			createUserInAMIS(tamUserId, userInfo.getUserAlias(), userInfo.getEmail());

			CommonAuthService.getInstance().getGatewayProvider().sendTempPasswordCreateUser(userInfo.getUserAlias(),
					userInfo.getPassword());

			return tamUserId;
		} catch (AimErrorResponse e) {
			throw new TAMException(e);
		}
	}
	
	private void createUserInAMIS(String tamUserId, String userAlias, String email) throws AuthException {

		try {
			if (CommonAuthService.getInstance().isAmisEnabled()) {

				boolean userCreated = AMISAccessProvider.createUser(tamUserId, userAlias, email, true);
				if (userCreated) {
					AMISAccessProvider.assignTokenSerialNumber(tamUserId);
					return;
				}
				logger.error("AMIS operation failed while creating the user.");
			}
		} catch (Exception e) {
			logger.error("Error while making amis call \n" + Utility.getStackTrace(e));

			if (!deleteUser(tamUserId)) {
				logger.error("Error while deleting user.");
			}

			throw new CreateUserFailedException("Error while creating user");
		}
	}
	
	
	/**
	 * This method is used to delete the user.
	 * 
	 * @param tamUserId
	 * @return Returns whether user is deleted or not
	 * @throws AMISOperationFailedException 
	 */
	@Override
	public boolean deleteUser(String tamUserId) throws AuthException {
		try {
			DeleteUserRequest request = new DeleteUserRequest();
			request.setUserId(tamUserId);
			DeleteUserResponse response = IdentityMgmtServiceProvider.getPrivateAccessIdentityMgmt().deleteUser(request);
			if(response.isDeleteSuccessful()) {
				AMISAccessProvider.deleteUser(tamUserId);
			}
			return response.isDeleteSuccessful();
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	@Override
	public String selfRegister(CreateUserInfo userInfo, Map<String, String> securityQuestions) throws AuthException {

		SelfRegisterRequest selfRegisterRequest = createSelfRegisterRequest(userInfo, null, null, securityQuestions);
		String tamUserId = null;
		try {
			SelfRegisterResponse response = IdentityMgmtServiceProvider.getPublicAccessIdentityMgmt()
					.selfRegister(selfRegisterRequest);

			tamUserId = response.getUserId();

			// create and set the token for the TAM user
			createUserInAMIS(tamUserId, userInfo.getUserAlias(), userInfo.getEmail());
			
			return tamUserId;
		} catch (AimErrorResponse | GatewayException e) {
			throw new TAMException(e);
		} catch (Exception e) {
			logger.error("Error while sending temporary password in create user \n" + Utility.getStackTrace(e));
			throw new TAMException(e);
		}
	}
	
	private SelfRegisterRequest createSelfRegisterRequest(CreateUserInfo userInfo, String applicationId, String roleName, Map<String, String> securityQuestions) {
		SelfRegisterRequest request = new SelfRegisterRequest();
		request.setUserAlias(userInfo.getUserAlias());
		request.setPassword(userInfo.getPassword());
		request.setEmail(userInfo.getEmail());
		request.setFirstName(userInfo.getFirstName());
		request.setLastName(userInfo.getLastName());

		Properties properties = CommonAuthService.getInstance().getProperties();
		request.setIssuerId(properties.getProperty(Constants.ISSUER_ID));
		request.setCorpId(properties.getProperty(Constants.CORP_ID));
		request.setIssuerGroupId(properties.getProperty(Constants.ISSUER_GROUP_ID));
		request.setCompanyGroupId(properties.getProperty(Constants.COMPANY_GROUP_ID));

		List<UserRole> userRoles = new ArrayList<>();
		UserRole userRole = new UserRole();
		userRole.setApplicationId(applicationId != null ? applicationId : properties.getProperty(Constants.APPLICATION_ID));
		userRole.setRoleName(roleName != null ? roleName : properties.getProperty(Constants.ROLE_NAME));
		userRoles.add(userRole);
		request.getUserRoles().addAll(userRoles);

		if (securityQuestions != null && securityQuestions.size() > 0) {
			for (Map.Entry<String, String> entry : securityQuestions.entrySet()) {
				SecurityQuestion securityQuestion = new SecurityQuestion();
				securityQuestion.setQuestion(entry.getKey());
				securityQuestion.setAnswer(entry.getValue());
				request.getSecurityQuestion().add(securityQuestion);
			}
		}

		PasswordPolicy passwordPolicy = new PasswordPolicy();
		passwordPolicy.setPasswordMaxAgeDays(userInfo.getPasswordMaxAgeDays());
		JAXBElement<PasswordPolicy> passwordPolicyElement = new JAXBElement<>(new QName("passwordPolicy"),
				PasswordPolicy.class, passwordPolicy);
		request.setPasswordPolicy(passwordPolicyElement);
		request.setSuspended(Boolean.valueOf(properties.getProperty(Constants.SUSPEND)));
		return request;
	}

	/**
	 * This method is used to generate the temporary password for the given
	 * userID.
	 * 
	 * @param userId
	 * @return
	 */
	public String forgotPassword(String userId) throws AuthException {

		try {
			ForgotPasswordRequest request = new ForgotPasswordRequest();
			request.setUserId(userId);
			ForgotPasswordResponse response = IdentityMgmtServiceProvider.getPublicAccessIdentityMgmt()
					.forgotPassword(request);
			return response.getTemporaryPassword();
		} catch (AimErrorResponse e) {
			throw new TAMException(e);
		}
	}

	/**
	 * This method is used to generate the temporary password for the given
	 * userID.
	 * 
	 * @param userAlias
	 * @param emailId
	 * @return
	 */
	public String forgotUserId(String userAlias, String emailId) throws AimErrorResponse {

		SearchUserRequest request = new SearchUserRequest();
		JAXBElement<String> userAliasElement = new JAXBElement<>(new QName(USER_ALIAS), String.class, userAlias);
		request.setUserAlias(userAliasElement);
		if (emailId != null) {
			JAXBElement<String> emailIdElement = new JAXBElement<>(new QName(EMAIL), String.class, emailId);
			request.setEmail(emailIdElement);
		}
		SearchUserResponse response = IdentityMgmtServiceProvider.getPublicAccessIdentityMgmt().searchUser(request);
		return response.getUserId();
	}

	/**
	 * The modifyUser method is used to modify the existing user details at the
	 * TAM side.
	 * 
	 * @param userId
	 * @param email
	 * @param userAlias
	 * @param firstName
	 * @param lastNname
	 * @param authLevel
	 * @param issuerId
	 * @param corpId
	 * @param issuerGroupId
	 * @param companyGroupId
	 * @return
	 * @throws AimErrorResponse
	 */
	public boolean modifyUser(UserInfo userInfo) throws AuthException {

		ModifyUserRequest modifyUserRequest = new ModifyUserRequest();
		modifyUserRequest.setUserId(userInfo.getUserId());
		modifyUserRequest.setEmail(userInfo.getEmail());
		JAXBElement<String> userAliasElement = new JAXBElement<>(new QName(USER_ALIAS), String.class,
				userInfo.getUserAlias());
		modifyUserRequest.setUserAlias(userAliasElement);
		modifyUserRequest.setFirstName(userInfo.getFirstName());
		modifyUserRequest.setLastName(userInfo.getLastName());
		modifyUserRequest.setAuthLevel(userInfo.getAuthLevel());
		modifyUserRequest.setIssuerId(userInfo.getIssuerId());
		modifyUserRequest.setCorpId(userInfo.getCorpId());
		modifyUserRequest.setIssuerGroupId(userInfo.getIssuerGroupId());
		modifyUserRequest.setCompanyGroupId(userInfo.getCompanyGroupId());

		Map<String, String> securityQuestions = userInfo.getSecurityQuestions();

		if (securityQuestions != null && securityQuestions.size() > 0) {
			for (Map.Entry<String, String> entry : securityQuestions.entrySet()) {
				SecurityQuestion securityQuestion = new SecurityQuestion();
				securityQuestion.setQuestion(entry.getKey());
				securityQuestion.setAnswer(entry.getValue());
				modifyUserRequest.getSecurityQuestion().add(securityQuestion);
			}
		}
		try {
			ModifyUserResponse response = IdentityMgmtServiceProvider.getPrivateAccessIdentityMgmt()
					.modifyUser(modifyUserRequest);
			return response.isModifySuccess();
		} catch (AimErrorResponse response) {
			throw new TAMException(response);
		}
	}

	/**
	 * The getSoftToken method is used to get the soft token for the user from
	 * TAM.
	 * 
	 * @param tamUserId
	 */
	@Override
	public String getSoftToken(String tamUserId) throws AuthException {

		try {
			// get the soft token from AMIS if enabled
			if (CommonAuthService.getInstance().isAmisEnabled()) {
				String tokenSerialNo = AMISAccessProvider.tokenTokenSrNo(tamUserId);
				String deviceType = CommonAuthService.getInstance().getProperty(Constants.AMIS_TOKEN_DEVICE_TYPE);
				return AMISAccessProvider.getSoftToken(tokenSerialNo, deviceType);
			}
			GetSoftTokenRequest request = new GetSoftTokenRequest();
			request.setUserId(tamUserId);
			GetSoftTokenResponse response = IdentityMgmtServiceProvider.getPrivateAccessIdentityMgmt()
					.getSoftToken(request);
			return response.getSoftTokenDetails().getSeedXml();
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	/**
	 * The getSoftToken method is used to get the soft token for the user from
	 * TAM.
	 * 
	 * @param tamUserId
	 */
	public boolean setSoftToken(String tamUserId, String tokenSerialNo, String deviceType, String softToken)
			throws AuthException {

		try {
			Document doc = AMISAccessProvider.getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(softToken.getBytes("utf-8"))));
			String expression = "/TKNBatch/TKNHeader/DefBirth";
			String issueDate = AMISAccessProvider.getXPath().compile(expression).evaluate(doc);
			expression = "/TKNBatch/TKNHeader/DefDeath";
			String expiryDate = AMISAccessProvider.getXPath().compile(expression).evaluate(doc);

			SetSoftTokenRequest request = new SetSoftTokenRequest();
			request.setUserId(tamUserId);
			request.setSeedXml(softToken);
			request.setIssueDate(issueDate);
			request.setExpiryDate(expiryDate);
			request.setSeqNum(tokenSerialNo);
			request.setDeviceId(deviceType);
			SetSoftTokenResponse response = IdentityMgmtServiceProvider.getPrivateAccessIdentityMgmt()
					.setSoftToken(request);
			return response.isSoftTokenSet();
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	/**
	 * The getSecurityQuestion method is used to get the list of security
	 * questions of the user from TAM.
	 * 
	 * @param userId
	 */
	public List<SecurityQuestion> getSecurityQuestion(String userId) throws AuthException {

		try {
			GetSecurityQuestionsRequest request = new GetSecurityQuestionsRequest();
			request.setUserId(userId);
			GetSecurityQuestionsResponse response = IdentityMgmtServiceProvider.getPublicAccessIdentityMgmt()
					.getSecurityQuestions(request);
			return response.getSecurityQuestion();
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	public List<com.mpts.auth.struts.bundle.model.SecurityQuestion> getSecurityQuestions(String userId)
			throws AuthException {
		try {
			GetSecurityQuestionsRequest request = new GetSecurityQuestionsRequest();
			request.setUserId(userId);
			GetSecurityQuestionsResponse response = IdentityMgmtServiceProvider.getPublicAccessIdentityMgmt()
					.getSecurityQuestions(request);
			List<com.mpts.auth.struts.bundle.model.SecurityQuestion> lSecurityQuestions = new ArrayList<>();
			List<SecurityQuestion> securityQuestions = response.getSecurityQuestion();
			for (SecurityQuestion securityQuestion : securityQuestions) {
				lSecurityQuestions.add(new com.mpts.auth.struts.bundle.model.SecurityQuestion(
						securityQuestion.getQuestion(), securityQuestion.getAnswer()));
			}
			return lSecurityQuestions;
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	/**
	 * The getUserInfo method is used to get the user details from TAM.
	 * 
	 * @param userId
	 */
	public UserInfo getUserInfo(String userId) throws AuthException {

		try {
			GetUserInfoRequest request = new GetUserInfoRequest();
			request.setUserId(userId);
			com.mastercard.aim.messages.phase1.UserInfo userInfo = IdentityMgmtServiceProvider
					.getPrivateAccessIdentityMgmt().getUserInfo(request);
			return Utility.getUserInfo(userInfo);
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	/**
	 * The search user method is used to get the user details from TAM.
	 * 
	 * @param userAlias
	 * @param emailId
	 * @return
	 * @throws AimErrorResponse
	 */
	public SearchUserResponse searchUser(String userAlias, String emailId) throws AuthException {

		try {
			SearchUserRequest searchUserRequest = new SearchUserRequest();
			JAXBElement<String> userAliasElement = new JAXBElement<>(new QName(USER_ALIAS), String.class, userAlias);
			searchUserRequest.setUserAlias(userAliasElement);
			if (emailId != null) {
				JAXBElement<String> emailElement = new JAXBElement<>(new QName(EMAIL), String.class, emailId);
				searchUserRequest.setEmail(emailElement);
			}
			return IdentityMgmtServiceProvider.getPublicAccessIdentityMgmt().searchUser(searchUserRequest);
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	@Override
	public String resetPassword(String userAlias, String tamUserId) throws AuthException {

		String tempPassword = forgotPassword(tamUserId);
		CommonAuthService.getInstance().getGatewayProvider().sendTempPasswordResetPassword(userAlias, tempPassword);
		return tempPassword;
	}

	@Override
	public boolean updateUser(String tamUserId, String userAlias, String email, String firstName, String lastName)
			throws AuthException {

		UserInfo userInfo = getUserInfo(tamUserId);
		logger.info("modify user call");
		if (userAlias != null) {
			userInfo.setUserAlias(userAlias);
		}
		if (email != null) {
			userInfo.setEmail(email);
		}
		if (firstName != null) {
			userInfo.setFirstName(firstName);
		}
		if (lastName != null) {
			userInfo.setLastName(lastName);
		}
		userInfo.setAuthLevel("token");
		return modifyUser(userInfo);
	}

	@Override
	public boolean changeSecurityQuestions(String tamUserId, Map<String, String> securityQuestions)
			throws AuthException {

		try {
			logger.info("user info done");
			UserInfo userInfo = getUserInfo(tamUserId);
			logger.info("modify user call");
			userInfo.setAuthLevel("token");
			userInfo.setSecurityQuestions(securityQuestions);
			return modifyUser(userInfo);
		} catch (AuthException e) {
			throw new TAMException(e);
		}
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword) throws AuthException {
		return false;
	}

	@Override
	public String getLoggedInTAMUserId() throws AuthException {

		try {
			UserIdentity userIdentity = new UserIdentity();
			return userIdentity.getUserID();
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	@Override
	public boolean changePIN(String userAlias, String newPIN) throws AuthException {

		// create and set the token for the TAM user
		String tamUserId = null;
		try {
			tamUserId = getLoggedInTAMUserId();
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
			throw new TAMException(e.getMessage());
		}
		String tokenSerialNo = setPIN(tamUserId, newPIN);
		if (tokenSerialNo != null) {
			CommonAuthService.getInstance().getGatewayProvider().notifyChangePin(userAlias);
			return true;
		}
		return false;
	}

	/**
	 * This method is used to generate the temporary pin for the given
	 * userID.
	 * 
	 * @param userId
	 * @return
	 */
	public String forgotPIN(String userId) throws AuthException {

		return resetPIN(userId);
	}

	private String resetPIN(String tamUserId) throws AuthException {

		try {
			// generate random PIN
			String tempPIN = Utility.generatePIN();
			String tokenSerialNo = setPIN(tamUserId, tempPIN);
			AMISAccessProvider.setNewPINMode(tokenSerialNo);
			return tempPIN;
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	private String setPIN(String tamUserId, String newPIN) throws AMISOperationFailedException {

		// set the newPIN for the TAM user in AMIS
		if (CommonAuthService.getInstance().isAmisEnabled()) {
			String tokenSerialNo = AMISAccessProvider.tokenTokenSrNo(tamUserId);

			if (AMISAccessProvider.setPIN(tokenSerialNo, newPIN)) {
				return tokenSerialNo;
			}
			throw new AMISOperationFailedException("SetPin failed in AMIS");
		}
		throw new AMISOperationFailedException("Automated token service is disabled.");
	}

	public boolean unlockUser(String userAlias, String tamUserId, boolean unlockedByAdmin) throws AuthException {

		// unlock the user if AMIS enabled
		if (CommonAuthService.getInstance().isAmisEnabled()) {
			boolean result = AMISAccessProvider.unlock(tamUserId);
			if (result) {
				CommonAuthService.getInstance().getGatewayProvider().notifyUnlockUser(userAlias, unlockedByAdmin);
				return true;
			}
			return false;
		}

		throw new AMISOperationFailedException("Automated token service is disabled.");
	}

	@Override
	public boolean unlockUser(String userAlias, String tamUserId) throws AuthException {
		try {
			return unlockUser(userAlias, tamUserId, true);
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	@Override
	public boolean resetPIN(String userAlias, String tamUserId) throws AuthException {

		String tempPIN = resetPIN(tamUserId);
		CommonAuthService.getInstance().getGatewayProvider().sendTempPINResetPIN(userAlias, tempPIN);
		return true;
	}

	@Override
	public boolean restoreUser(String userAlias, String tamUserId) throws AuthException {
		try {
			if(!AMISAccessProvider.isUserEnabled(tamUserId)) {
				return AMISAccessProvider.enableUser(tamUserId);
			}
			return false;
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}
}
