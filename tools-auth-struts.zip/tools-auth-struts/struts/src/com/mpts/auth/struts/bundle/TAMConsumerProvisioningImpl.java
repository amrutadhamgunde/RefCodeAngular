package com.mpts.auth.struts.bundle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import com.mastercard.ssi.cspws.domain.UserParam;
import com.mastercard.ssi.cspws.pub.CSPFault;
import com.mastercard.ssi.cspws.pub.ConsumerUser;
import com.mastercard.ssi.security.UserIdentity;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.TAMException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.CreateUserInfo;
import com.mpts.auth.struts.bundle.model.IAccessProvider;

public class TAMConsumerProvisioningImpl implements IAccessProvider {

	private static Logger logger = Logger.getLogger(TAMConsumerProvisioningImpl.class);
	
	private static final String MSG_CSP_FAULT = "CSPFault : ";

	private static TAMConsumerProvisioningImpl instance = new TAMConsumerProvisioningImpl();

	private TAMConsumerProvisioningImpl() {
	}

	public static TAMConsumerProvisioningImpl getInstance() {
		return instance;
	}
	
	@Override
	public String createUser(CreateUserInfo userInfo) throws AuthException {
		Properties properties = CommonAuthService.getInstance().getProperties();
		String applicationId = properties.getProperty(Constants.APPLICATION_ID);
		String roleName = properties.getProperty(Constants.ROLE_NAME);
		return createUser(userInfo, applicationId, roleName);
	}

	@Override
	public String createUser(CreateUserInfo userInfo, String applicationId, String roleName) throws AuthException {
		logger.debug("CreateUser call for user:" + userInfo.getUserAlias());

		ConsumerUser consumerUser = new ConsumerUser();
		consumerUser.setAlias(userInfo.getUserAlias());
		consumerUser.setPassword(userInfo.getPassword());
		consumerUser.setEmail(userInfo.getEmail());
		consumerUser.setMobile(userInfo.getMobileNo());
		consumerUser.setFirstName(userInfo.getFirstName());
		consumerUser.setLastName(userInfo.getLastName());

		Properties properties = CommonAuthService.getInstance().getProperties();

		String roleNames = roleName;
		String[] roleNameArray = roleNames.split(",");
		consumerUser.getRoles().addAll(Arrays.asList(roleNameArray));

		String issuerId = properties.getProperty(Constants.ISSUER_ID);
		boolean isActive = Boolean.parseBoolean(properties.getProperty(Constants.ACTIVE));

		Holder<ConsumerUser> consumerUserHolder = new Holder<>(consumerUser);
		try {
			ConsumerProvisioningServiceProvider.getPublicProvisioningService().createUser(consumerUserHolder, issuerId,
					isActive);
		} catch (CSPFault cspFault) {
			logger.error(MSG_CSP_FAULT + cspFault.getMessage());
			throw new TAMException(cspFault);
		}

		String tamUserId = consumerUserHolder.value.getUserId();
		logger.debug("TAM user " + tamUserId + " is created for user:" + userInfo.getUserAlias());

		return tamUserId;
	}

	/**
	 * This method is used modify user details
	 * 
	 * @param email
	 * @param userAlias
	 * @param mobileNo
	 * @return
	 */
	public boolean modifyUser(String email, String userAlias, String mobileNo) throws AuthException {
		String issuerId = CommonAuthService.getInstance().getProperty(Constants.ISSUER_ID);
		List<UserParam> userParams = new ArrayList<>();
		UserParam userParam1 = new UserParam();
		userParam1.setUserParamType("EMAIL");
		userParam1.setUserParamValue(email);
		userParams.add(userParam1);

		UserParam userParam2 = new UserParam();
		userParam2.setUserParamType("MOBILE");
		userParam2.setUserParamValue(mobileNo);
		userParams.add(userParam2);

		UserParam userParam3 = new UserParam();
		userParam3.setUserParamType("ALIAS");
		userParam3.setUserParamValue(userAlias);
		userParams.add(userParam3);
		try {
			ConsumerProvisioningServiceProvider.getPrivateProvisioningService().updateUser(userParams, issuerId);
		} catch(com.mastercard.ssi.cspws.priv.CSPFault cspFault) {
			logger.error(MSG_CSP_FAULT + cspFault.getMessage());
			throw new TAMException(cspFault);
		}
		return true;
	}

	/**
	 * This method is used to invalidate the current password for the given
	 * userID.
	 * 
	 * @param userId
	 * @return
	 */
	public static String forgotPassword(String tamUserId) throws AuthException {

		String result = null;
		try {
			boolean success = ConsumerProvisioningServiceProvider.getPublicProvisioningService()
					.forgotPassword(tamUserId);
			if (success) {
				result = ConsumerProvisioningServiceProvider.getPublicProvisioningService()
						.generateTemporaryPassword(tamUserId);
			}
		} catch (CSPFault cspFault) {
			logger.error(MSG_CSP_FAULT + cspFault.getMessage());
			throw new TAMException(cspFault);
		}
		return result;
	}

	/**
	 * This method is used to set the password for user received in saml
	 * 
	 * @param userId
	 * @return
	 */
	public boolean setPassword(String password) throws AuthException {
		try {
			return ConsumerProvisioningServiceProvider.getPrivateProvisioningService().setPassword(password);
		} catch (com.mastercard.ssi.cspws.priv.CSPFault cspFault) {
			String errorMessage = cspFault.getFaultInfo().getCode() + " : " + cspFault.getMessage();
			logger.error(cspFault);
			throw new TAMException(errorMessage);
		}
	}

	/**
	 * This method is used to reset the password for given userId and generate
	 * the temporary password for the userId
	 */
	@Override
	public String resetPassword(String userAlias, String tamUserId) throws AuthException {

		String tempPassword = forgotPassword(tamUserId);
		CommonAuthService.getInstance().getGatewayProvider().sendTempPasswordResetPassword(userAlias, tempPassword);
		return tempPassword;
	}

	@Override
	public String getSoftToken(String tamUserId) throws AuthException {
		// Not required for B2C user provisioning
		return null;
	}

	@Override
	public boolean changeSecurityQuestions(String tamUserId, Map<String, String> securityQuestions) throws AuthException {
		// Not required for B2C user provisioning
		return false;
	}

	@Override
	public String selfRegister(CreateUserInfo userInfo, Map<String, String> securityQuestions)
			throws AuthException {
		logger.debug("selfRegister call for user : " + userInfo.getUserAlias());
		String tamUserId = null;
		try {
			tamUserId = createUser(userInfo);
		} catch (AuthException e) {
			logger.error(e.getMessage());
			throw e;
		}
		return tamUserId;
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword) throws AuthException {
		logger.debug("changePassword called");
		try {
			return ConsumerProvisioningServiceProvider.getPrivateProvisioningService().changePassword(newPassword,
					oldPassword);
		} catch (com.mastercard.ssi.cspws.priv.CSPFault cspFault) {
			logger.error(cspFault);
			String errorMessage = cspFault.getFaultInfo().getCode() + " : " + cspFault.getMessage();
			throw new TAMException(errorMessage);
		}
	}

	@Override
	public String getLoggedInTAMUserId() throws AuthException {

		try {
			UserIdentity userIdentity = new UserIdentity();
			return userIdentity.getUserID();
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}

	@Override
	public boolean changePIN(String userAlias, String newPIN) throws AuthException {
		return false;
	}

	@Override
	public boolean unlockUser(String userAlias, String tamUserId) throws AuthException {

		try {
			return ConsumerProvisioningServiceProvider.getPublicProvisioningService().activateUser(tamUserId);
		} catch (CSPFault e) {
			throw new TAMException(e);
		}
	}

	@Override
	public boolean updateUser(String tamUserId, String userAlias, String email, String firstName, String lastName)
			throws AuthException {
		return false;
	}

	@Override
	public boolean resetPIN(String userAlias, String tamUserId) throws AuthException {
		return false;
	}

	@Override
	public boolean restoreUser(String userAlias, String tamUserId) throws AuthException {
		
		return false;
	}

	@Override
	public boolean deleteUser(String tamUserId) throws AuthException {
		return false;
	}
}