package com.mpts.auth.struts.bundle.util;

import java.security.MessageDigest;

import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.TAMException;

public class HashGenerator {
	static {
		EncryptionUtility.loadAllEncryptionTypes();
	}
	
	private HashGenerator() {
		
	}
	
	private static String convertToHex(byte[] data) {
		StringBuilder buf = new StringBuilder();
		for (int i = 0; i < data.length; i++) {
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int twoHalfs = 0;
			do {
				if ((0 <= halfbyte) && (halfbyte <= 9))
					buf.append((char) ('0' + halfbyte));
				else
					buf.append((char) ('a' + (halfbyte - 10)));
				halfbyte = data[i] & 0x0F;
			} while (twoHalfs++ < 1);
		}
		return buf.toString();
	}

	public static String encrypt(String algorithm, String text) throws AuthException {
		try {
			String encryptionType = EncryptionUtility.getEncrptionType(algorithm);
			MessageDigest md;
			md = MessageDigest.getInstance(encryptionType);

			byte[] sha1hash;
			md.update(text.getBytes("iso-8859-1"), 0, text.length());
			sha1hash = md.digest();
			return convertToHex(sha1hash);
		} catch (Exception e) {
			throw new TAMException(e);
		}
	}
	
	public static String hash(String algorithm) throws AuthException {
		return encrypt(algorithm == null ? "SHA5" : algorithm, "password123!");
	}

}
