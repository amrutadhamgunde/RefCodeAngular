package com.mpts.auth.struts.bundle.pages.openid;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.model.Constants;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginValidator extends ActionSupport{

	private static final long serialVersionUID = -5700344418760953223L;
	private static final Logger logger = Logger.getLogger(LoginValidator.class);

	private String url; 
	private String userName;
	
	@Override
	public String execute() {
		HttpServletRequest request = ServletActionContext.getRequest();
		// Parse the authorisation response from the callback URI
		String idToken = request.getParameter("id_token");

		if (StringUtils.isNotEmpty(idToken)) {

			try {
				// Create RSA-signer with the public key

				// Retrieve / verify the JWT claims according to the app
				// requirements
				url = CommonAuthService.getInstance().getHomePage();
				
				//TODO need to take dynamically
				ServletActionContext.getRequest().getSession().setAttribute(Constants.JUNCTION, "mpts");
				ActionContext.getContext().getSession().put(Constants.JUNCTION, "mpts");
				userName =  CommonAuthService.getInstance().getProperty("TAM_USER_ID");
				return "redirect";
			} catch (Exception e) {
				logger.error(e);
			}
		} else {
			return ERROR;
		}
		return ERROR;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUserName() {
		return userName;
	}
	
}
