package com.mpts.auth.struts.bundle.model;

public class CreateUserInfo {
	private String email;
	private String mobileNo;
	private String userAlias;
	private String password;
	private String firstName;
	private String lastName;
	private float passwordMaxAgeDays;
	
	public CreateUserInfo(String userAlias, String password, String firstName, String lastName, String email, float passwordMaxAgeDays) {

		this.userAlias = userAlias;
		this.password = password;
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.passwordMaxAgeDays = passwordMaxAgeDays;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserAlias() {
		return userAlias;
	}

	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public float getPasswordMaxAgeDays() {
		return passwordMaxAgeDays;
	}

	public void setPasswordMaxAgeDays(float passwordMaxAgeDays) {
		this.passwordMaxAgeDays = passwordMaxAgeDays;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}
