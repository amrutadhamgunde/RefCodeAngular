package com.mpts.auth.struts.bundle;

import java.util.Map;

import javax.ws.rs.core.MediaType;

import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.CreateUserInfo;
import com.mpts.auth.struts.bundle.model.IAccessProvider;
import com.sun.jersey.api.representation.Form;

public class OpenIDAccessProviderImpl implements IAccessProvider {

	/**
	 * This method is used to create the user.
	 * 
	 * @param userId
	 *            is optional. Pass null or empty string.
	 * @param userAlias
	 * @param password
	 * @param email
	 * @param firstName
	 * @param lastNname
	 * @param issuerId
	 * @param corpId
	 * @param issuerGroupId
	 * @param companyGroupId
	 * @param userRoles
	 * @param passwordPolicy
	 * @param suspend
	 * @return Returns the User-ID once the user is created.
	 */
	@Override
	public String createUser(CreateUserInfo userInfo) throws AuthException {
		return createUser(userInfo, null, null);
	}
	
	@Override
	public String createUser(CreateUserInfo userInfo, String applicationId, String roleName) throws AuthException {
		Form form = new Form();
		form.add("userId", userInfo.getUserAlias());
		form.add("userAlias", userInfo.getUserAlias());
		form.add("password", userInfo.getPassword());
		form.add("passwordMaxAgeDays", userInfo.getPasswordMaxAgeDays());
		form.add("email", userInfo.getEmail());
		form.add("mobileNo", userInfo.getMobileNo());
		form.add("firstName", userInfo.getFirstName());
		form.add("lastNname", userInfo.getLastName());
		form.add("suspend", CommonAuthService.getInstance().getProperty(Constants.SUSPEND));
		return CommonAuthService.getInstance().getAPIService().path("rest").path("user").path("create")
				.type(MediaType.APPLICATION_FORM_URLENCODED).post(String.class, form);
	}

	@Override
	public String getSoftToken(String userId) throws AuthException {
		return null;
	}

	@Override
	public String resetPassword(String userAlias, String tamUserId) throws AuthException {
		return null;
	}

	@Override
	public boolean changeSecurityQuestions(String tamUserId, Map<String, String> securityQuestions) throws AuthException {
		return false;
	}

	@Override
	public String selfRegister(CreateUserInfo userInfo, Map<String, String> securityQuestions)
			throws AuthException {
		return null;
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword) throws AuthException {
		return false;
	}

	@Override
	public String getLoggedInTAMUserId() throws AuthException {
		return null;
	}

	@Override
	public boolean changePIN(String userAlias, String newPIN) throws AuthException {
		return false;
	}

	@Override
	public boolean unlockUser(String userAlias, String tamUserId) throws AuthException {
		return false;
	}
	
	@Override
	public boolean resetPIN(String userAlias, String tamUserId) throws AuthException {
		return false;
	}

	@Override
	public boolean updateUser(String tamUserId, String userAlias, String email, String firstName, String lastName)
			throws AuthException {
		return false;
	}

	@Override
	public boolean deleteUser(String tamUserId) throws AuthException {
		return false;
	}

	@Override
	public boolean restoreUser(String userAlias, String tamUserId) throws AuthException {
		return false;
	}
	
}
