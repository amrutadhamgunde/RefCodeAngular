package com.mpts.auth.struts.bundle.exception;

public class CreateUserFailedException extends TAMException {
	private static final long serialVersionUID = 1L;

	public CreateUserFailedException(String error) {
		super(error);
	}
}
