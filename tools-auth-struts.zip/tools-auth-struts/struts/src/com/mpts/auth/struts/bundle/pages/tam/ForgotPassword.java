package com.mpts.auth.struts.bundle.pages.tam;

import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.TAMAccessProviderImpl;
import com.mpts.auth.struts.bundle.TAMConsumerProvisioningImpl;
import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.AMISOperationFailedException;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.OTPExpiredException;
import com.mpts.auth.struts.bundle.exception.UserNotFoundException;
import com.mpts.auth.struts.bundle.exception.UserNotRegisteredException;
import com.mpts.auth.struts.bundle.model.CommonAuthScopedModel;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.SecurityQuestion;
import com.mpts.auth.struts.bundle.util.EscapeUtils;
import com.mpts.auth.struts.bundle.util.HashOTPGenerator;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.interceptor.ScopedModelDriven;

public class ForgotPassword extends CommonAction implements ScopedModelDriven<CommonAuthScopedModel> {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(ForgotPassword.class);
	
	private static final String ERROR_MESSAGE = "errorMessage";
	private static final String FRGT_PASS_GET_USER = "./forgotPasswordgetUser";
	
	private String useralias;
	private String source;
	private String actionUrl;
	private String brandingContext;
	private String forgotOpType;
	
	protected CommonAuthScopedModel commonAuthModel;
	protected String scopedKey = "ForgotPassword";
	private transient List<SecurityQuestion> securityQuestions;

	@Override
	public CommonAuthScopedModel getModel() {
		return commonAuthModel;
	}

	@Override
	public void setModel(CommonAuthScopedModel commonAuthModel) {
		this.commonAuthModel = commonAuthModel;
	}

	@Override
	public void setScopeKey(String scopedKey) {
		this.scopedKey = scopedKey;
	}
	
	@Override
	public String getScopeKey() {
		return scopedKey;
	}

	public String showForgotPwdPage() {
		actionUrl = FRGT_PASS_GET_USER;
		forgotOpType = Constants.FORGOT_OP_PASS;
		return SUCCESS;
	}
	
	public String showForgotPINPage() {
		actionUrl = FRGT_PASS_GET_USER;
		forgotOpType = Constants.FORGOT_OP_PIN;
		return SUCCESS;
	}
	
	public String showUnlockUserPage() {
		actionUrl = FRGT_PASS_GET_USER;
		forgotOpType = Constants.FORGOT_OP_UNLOCK;
		return SUCCESS;
	}
	
	public String forgotPassword() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			
			String actionName = context.getName();
			String result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
			
			securityQuestions = commonAuthModel.getSecurityQuestions();
		} else {
			if (StringUtils.isEmpty(useralias)) {
				addActionError("Field 'User Id' is required");
				return INPUT;
			}
			
			useralias = EscapeUtils.escapeHtml(useralias);
			String typeOfUser = CommonAuthService.getInstance().getUserType();
			
			String result = getValidTAMUserId(typeOfUser);
			if(SUCCESS.equals(result)) {
				result = getSecurityQuestions(typeOfUser);
			}
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		}
		
		if (securityQuestions.size() >= 2) {
			securityQuestion1 = securityQuestions.get(0).getQuestion();
			securityQuestion2 = securityQuestions.get(1).getQuestion();
		}
		actionUrl = null;
		actionUrl = "./forgotPwdSecQueVerification";
			
		return SUCCESS;
	}
	
	private String getValidTAMUserId(String typeOfUser) {
		String result = SUCCESS;
		try {
			tamUserId = CommonAuthService.getInstance().getDaoProvider().getTAMUserId(useralias);
			if (StringUtils.isEmpty(tamUserId)) {
				String errMsg = CommonAuthService.getInstance().getProperty(Constants.INVALID_CREDENTIALS);
				logger.debug(errMsg);
				addActionError(errMsg);
				result = INPUT;
			} else if (Constants.B2B.equals(typeOfUser)) {
				result = validateUser(tamUserId);
			}
		} catch (UserNotFoundException e) {
			String errorMessage = CommonAuthService.getInstance().getProperty(Constants.INVALID_USER_NAME,
					"Invalid User Id");
			addActionError(errorMessage);
			logger.error(errorMessage, e);
			result = INPUT;
		} catch (UserNotRegisteredException e) {
			if (Constants.B2C.equals(typeOfUser)) {
				onUserException(e.getError(), Constants.USER_NOT_EXISTS_MESSAGE);
				result = INPUT;
			}
			logger.error(e.getError(), e);
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			String errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
			}
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			result = ERROR;
		}
		
		return result;
	}
	
	private String validateUser(String tamUserId) throws AuthException {
		String result = SUCCESS;
		try {
			if (!AMISAccessProvider.isUserEnabled(tamUserId)) {
				String userSuspendedMsg = CommonAuthService.getInstance().getProperty(Constants.USER_SUSPENDED,
						"User '" + useralias + "' is suspended. Please contact administrator.");
				logger.error(userSuspendedMsg);
				addActionError(userSuspendedMsg);
				result = INPUT;
			} else if (Constants.FORGOT_OP_UNLOCK.equals(forgotOpType) && !AMISAccessProvider.isUserLocked(tamUserId)) {
				String message = CommonAuthService.getInstance().getProperty(Constants.USER_NOT_LOCKED);
				if (message == null) {
					message = "User '" + useralias + "' is not locked in the system.";
				}
				addActionError(message);
				result = INPUT;
			}
		} catch (AMISOperationFailedException e) {
			Utility.getStackTrace(e);
			if (Constants.FORGOT_OP_PASS.equals(forgotOpType)) {
				result = SUCCESS;
			} else {
				throw e;
			}
		}
		return result;
	}
	
	private void onUserException(String errorMessage, String errorMsgKey) {
		String errorMessage1 = errorMessage;
		if (StringUtils.isEmpty(errorMessage)) {
			errorMessage1 = CommonAuthService.getInstance().getProperty(errorMsgKey);
		}
		logger.error(errorMessage1);
		addActionError(errorMessage1);
	}

	private String getSecurityQuestions(String typeOfUser) {
		String result = SUCCESS;
		try {
			commonAuthModel.setUserAlias(useralias);
			if (Constants.B2C.equals(typeOfUser)) {
				Map<String, String> secQueList = CommonAuthService.getInstance().getDaoProvider()
						.getSecurityQuestions(commonAuthModel.getUserAlias());
				securityQuestions = new ArrayList<>();
				for(Map.Entry<String, String> secQue : secQueList.entrySet()) {
					securityQuestions.add(new SecurityQuestion(secQue.getKey(), secQue.getValue()));
				}
			} else {				
				securityQuestions = TAMAccessProviderImpl.getInstance().getSecurityQuestions(tamUserId);
			}
			commonAuthModel.setTamUserId(tamUserId);
			commonAuthModel.setSecurityQuestions(securityQuestions);
			
			if (Utility.isEmpty(securityQuestions)
					|| (securityQuestions.size() == 1 && "".equals(securityQuestions.get(0).getAnswer()))) {
				String errorMessage = CommonAuthService.getInstance().getProperty(Constants.SEC_QUEST_NOT_EXISTS); 
				logger.error(errorMessage);
				ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
				result = ERROR;
			}
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			addActionError("Error occured while getting the security questions");
			result = INPUT;
		}
		
		return result;
	}

	public String validateSeqQue() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		securityQuestion1 = commonAuthModel.getSecurityQuestions().get(0).getQuestion();
		securityQuestion2 = commonAuthModel.getSecurityQuestions().get(1).getQuestion();
		
		boolean languageSelected = false;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			languageSelected = true;
			
			String actionName = context.getName();
			String result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		} else {
			if (StringUtils.isEmpty(securityAnswer1)) {
				addActionError("Answer for security question '"
						+ commonAuthModel.getSecurityQuestions().get(0).getQuestion() + "' is required");
				return INPUT;
			}
			securityAnswer1 = EscapeUtils.escapeHtml(securityAnswer1);
			if (StringUtils.isEmpty(securityAnswer2)) {
				addActionError("Answer for security question '"
						+ commonAuthModel.getSecurityQuestions().get(1).getQuestion() + "' is required");
				return INPUT;
			}
			securityAnswer2 = EscapeUtils.escapeHtml(securityAnswer2);
		}
		
		return verifySeqQue(languageSelected);
	}
	
	private String verifySeqQue(boolean languageSelected) {
		if (languageSelected || (getHashedAnswerValue(securityAnswer1.trim()).equals(commonAuthModel.getSecurityQuestions().get(0).getAnswer())
				&& (getHashedAnswerValue(securityAnswer2.trim()).equals(commonAuthModel.getSecurityQuestions().get(1).getAnswer())))) {
			if(!languageSelected) {
				String result = generateAndSendOTP();
				
				if(!SUCCESS.equals(result)) {
					return result;
				}
			}
			
			actionUrl = "./forgotPwdOTPVerification";
			return SUCCESS;
		} else {
			return validateRetryCount(Constants.INVALID_SECURITY_QUESTIONS);
		}
	}
	
	private String getHashedAnswerValue(String answer){
		String typeOfUser = CommonAuthService.getInstance().getUserType();
		
		if (Constants.B2C.equals(typeOfUser)) {
			return CommonAuthService.getInstance().getDaoProvider().hash(answer);
		}
		return answer;
	}

	private String validateRetryCount(String errorMessageKey) {
		int retryCount = commonAuthModel.getInvalidRetryCount();
		if (retryCount >= CommonAuthService.getInstance().getMaxNoAttempts()) {
			try {
				if(!AMISAccessProvider.disableUser(commonAuthModel.getTamUserId())) {
					logger.error(commonAuthModel.getTamUserId() + " is not disabled in forgot user alias . User does not found in RSA.");
				}
			} catch (AuthException exe) {
				logger.error(Utility.getStackTrace(exe));
			}
			errorMessage = CommonAuthService.getInstance().getProperty(Constants.MAX_ATTEMPTS);
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			return ERROR;
		} else {
			String invalidMessage = CommonAuthService.getInstance()
					.getProperty(errorMessageKey);
			invalidMessage = invalidMessage.replace(Constants.NO_OF_ATTEMPTS,
					String.valueOf(CommonAuthService.getInstance().getMaxNoAttempts() - retryCount));
			addActionError(invalidMessage);
			commonAuthModel.setInvalidRetryCount(++retryCount);
			return INPUT;
		}

	}

	private String generateAndSendOTP() {
		commonAuthModel.setInvalidRetryCount(0);
		try {
			String otp = HashOTPGenerator.generateOTP(Utility.generateRandomNumber(32), System.nanoTime(), 7, true,
					4);

			if (Constants.FORGOT_OP_PIN.equals(forgotOpType)) {
				CommonAuthService.getInstance().getGatewayProvider()
						.sendOTPForgotPIN(commonAuthModel.getUserAlias(), otp);
			} else if (Constants.FORGOT_OP_PASS.equals(forgotOpType)) {
				CommonAuthService.getInstance().getGatewayProvider()
						.sendOTPForgotPassword(commonAuthModel.getUserAlias(), otp);
			} else if (Constants.FORGOT_OP_UNLOCK.equals(forgotOpType)) {
				CommonAuthService.getInstance().getGatewayProvider()
						.sendOTPUnlockUser(commonAuthModel.getUserAlias(), otp);
			}
			CommonAuthService.getInstance().getDaoProvider().saveOTP(commonAuthModel.getUserAlias(), otp);
		} catch (GeneralSecurityException e1) {
			logger.error("Error occured while generating the OTP.", e1);
			errorMessage = "Error occured while generating the OTP";
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			return ERROR;
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
			}
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			return ERROR;
		}
		return SUCCESS;
	}

	public String otpVerification() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		boolean languageSelected = false;
		String result;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			languageSelected = true;
			
			String actionName = context.getName();
			result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		}
		
		if(!languageSelected) {
			if (StringUtils.isEmpty(oneTimePassword)) {
				addActionError("Field 'OTP' is required to verification");
				return INPUT;
			}
			oneTimePassword = EscapeUtils.escapeHtml(oneTimePassword);
		}
		
		return verifyOTP(languageSelected);
	}

	private String verifyOTP(boolean languageSelected) {
		String result;
		try {
			if (languageSelected || CommonAuthService.getInstance().getDaoProvider().verifyOTP(commonAuthModel.getUserAlias(),
					oneTimePassword)) {
				result =  onSuccessfulOTPVerification(languageSelected);
			} else {
				result = validateRetryCount(Constants.INVALID_OTP);
			}
		} catch (OTPExpiredException e) {
			errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.OTP_EXPIRED_MESSAGE);
			}
			logger.error(errorMessage, e);
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			result = ERROR;
		} catch (AuthException e) {
			errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
			}
			logger.error(errorMessage, e);
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			result = ERROR;
		}
		return result;
	}

	private String onSuccessfulOTPVerification(boolean languageSelected) throws AuthException  {
		if(!languageSelected) {
			String typeOfUser = CommonAuthService.getInstance().getUserType();
			String tempPassword;
			if(Constants.FORGOT_OP_PIN.equals(forgotOpType)){
				tempPassword = TAMAccessProviderImpl.getInstance().forgotPIN(commonAuthModel.getTamUserId());
				CommonAuthService.getInstance().getGatewayProvider()
						.sendTempPINForgotPIN(commonAuthModel.getUserAlias(), tempPassword);
			} else if(Constants.FORGOT_OP_PASS.equals(forgotOpType)) {
				if(Constants.B2C.equals(typeOfUser)) {
					tempPassword = TAMConsumerProvisioningImpl.forgotPassword(commonAuthModel.getTamUserId());							
				} else {
					tempPassword = TAMAccessProviderImpl.getInstance().forgotPassword(commonAuthModel.getTamUserId());
				}
				CommonAuthService.getInstance().getGatewayProvider()
						.sendTempPasswordForgotPassword(commonAuthModel.getUserAlias(), tempPassword);
			} else if(Constants.FORGOT_OP_UNLOCK.equals(forgotOpType)) {
				if(Constants.B2C.equals(typeOfUser)) {
					TAMConsumerProvisioningImpl.getInstance().unlockUser(commonAuthModel.getUserAlias(), commonAuthModel.getTamUserId());
				} else {
					TAMAccessProviderImpl.getInstance().unlockUser(commonAuthModel.getUserAlias(), commonAuthModel.getTamUserId(), false);
				}
			}
		}
		String message;
		if (Constants.FORGOT_OP_UNLOCK.equals(forgotOpType)) {
			message = CommonAuthService.getInstance().getProperty(Constants.USER_UNLOCK_SUCCESSFUL);
		} else {

			Map<String, String> values = null;
			try {
				values = CommonAuthService.getInstance().getDaoProvider()
						.getUserContacts(commonAuthModel.getUserAlias());
			} catch (Exception e) {
				logger.error(Utility.getStackTrace(e));
				ActionContext.getContext().put(ERROR_MESSAGE,
						CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR));
				return ERROR;
			}
			message = CommonAuthService.getInstance().getProperty(Constants.OTP_VERIFY_SUCCESSFUL);
			message = message.replace(Constants.MOBILE,
					Utility.maskMobileNo(values.get(Constants.MOBILE_NO)));
			message = message.replace(Constants.EMAIL,
					Utility.maskEmailId(values.get(Constants.EMAIL_ID)));
		}
		addActionMessage(message);
		return SUCCESS;
	}

	public String getUseralias() {
		return useralias;
	}

	public void setUseralias(String useralias) {
		this.useralias = useralias;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getActionUrl() {
		return actionUrl;
	}

	public void setActionUrl(String actionUrl) {
		this.actionUrl = actionUrl;
	}

	public String getBrandingContext() {
		return brandingContext;
	}

	public void setBrandingContext(String brandingContext) {
		this.brandingContext = brandingContext;
	}

	public String getForgotOpType() {
		return forgotOpType;
	}

	public void setForgotOpType(String forgotOpType) {
		this.forgotOpType = forgotOpType;
	}
}
