package com.mpts.auth.struts.bundle.exception;

public class UserNotRegisteredException extends AuthException {

	private static final long serialVersionUID = -460713329426802038L;
	
	public UserNotRegisteredException(String error) {
		super(error);
	}
}
