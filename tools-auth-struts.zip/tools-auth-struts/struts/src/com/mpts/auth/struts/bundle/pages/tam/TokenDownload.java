package com.mpts.auth.struts.bundle.pages.tam;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.mastercard.aim.domain.phase1.SecurityQuestion;
import com.mastercard.ssi.security.UserIdentity;
import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.TAMAccessProviderImpl;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.SecureTokenDownload;
import com.mpts.auth.struts.bundle.model.UserInfo;
import com.mpts.auth.struts.bundle.util.EscapeUtils;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.interceptor.ScopedModelDriven;

public class TokenDownload extends ActionSupport implements ScopedModelDriven<SecureTokenDownload> {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(TokenDownload.class);
	
	private static final String SLASH_DOT_DOT = "SLASH_DOT_DOT";
	private static final String ERROR_MESSAGE = "errorMessage";
	
	private SecureTokenDownload secureTokenDownload = null;
	private String scopedKey = "SecureTokenDownload";
	private transient InputStream fileInputStream;
	private String tokenFileName;
	private List<String> secQueList = new ArrayList<>();
	private String brandingContext;
	
	private String selectedSecQuestion1;
	private String securityAnswer1;
	private String selectedSecQuestion2;
	private String securityAnswer2;
	
	public String displayTokenLogin() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		String result;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			
			String actionName = context.getName();
			result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if("setsecurityquestions".equals(result)) {
				secQueList = secureTokenDownload.getDbSecurityQuestions();
			} else if (SUCCESS.equals(result)) {
				// TokenDownload.jsp is called from two different flows that's why added below in script path
				ActionContext.getContext().put(SLASH_DOT_DOT, "");
			}
			
			return result;
		}
		
		String tamUserId = null;
		try {
			UserIdentity userIdentity = new UserIdentity();
			tamUserId = userIdentity.getUserID();
			tokenFileName = tamUserId +".sdtid";
		} catch (Exception ex) {
			logger.debug("Error while getting the User: " + ex);
			logger.error(Utility.getStackTrace(ex));
			return ERROR;
		}
		
		result = getSecurityQuestions(tamUserId);
		if(!SUCCESS.equals(result)) {
			return result;
		}
		
		// TokenDownload.jsp is called from two different flows that's why added below in script path
		ActionContext.getContext().put(SLASH_DOT_DOT, "");
		
		return SUCCESS;
	}

	private String getSecurityQuestions(String tamUserId) {
		List<SecurityQuestion> securityQuestions = null;
		try {
			securityQuestions = TAMAccessProviderImpl.getInstance().getSecurityQuestion(tamUserId);
		} catch (AuthException response) {
			logger.error(Utility.getStackTrace(response));
			ActionContext.getContext().put(ERROR_MESSAGE, response.getError());
			return ERROR;
		}

		if (Utility.isEmpty(securityQuestions)
				|| (securityQuestions.size() == 1 && "".equals(securityQuestions.get(0).getAnswer()))) {
			secureTokenDownload.setTamUserId(tamUserId);
			try {
				secQueList = CommonAuthService.getInstance().getDaoProvider().getSecurityQuestions();
				secureTokenDownload.setDbSecurityQuestions(secQueList);
			} catch(Exception e){
				logger.error("Error while fetching security questions from database");
				logger.error(Utility.getStackTrace(e));
				return ERROR;
			}
			
			secureTokenDownload.setFirstTimeDownload(true);
			
			return "setsecurityquestions";
		}
		return SUCCESS;
	}

	public String tokenLogin() {
		logger.debug("In execute of Secure TokenDownload");
		String tamUserId = null;
		try {
			UserIdentity userIdentity = new UserIdentity();
			tamUserId = userIdentity.getUserID();
			tokenFileName = tamUserId +".sdtid";
		} catch (Exception ex) {
			logger.debug("Error while getting the User: " + ex);
			logger.error(Utility.getStackTrace(ex));
			return ERROR;
		}
		
		return getSoftToken(tamUserId);
	}
	
	private String getSoftToken(String tamUserId) {
		String result;
		try {
			String softToken = CommonAuthService.getInstance().getAccessProvider().getSoftToken(tamUserId);
			if (!softToken.startsWith("<?xml version=\"1.0\"?>")) {
				softToken = "<?xml version=\"1.0\"?>" + softToken;
			}
			fileInputStream = new ByteArrayInputStream(softToken.getBytes());
			
			// set new temp PIN to AMIS if enabled for first time token download operation
			if (CommonAuthService.getInstance().isAmisEnabled() && secureTokenDownload.isFirstTimeDownload()) {
				setPIN(tamUserId);
			}
			result = SUCCESS;
		} catch (SOAPFaultException e) {
			logger.debug("*******SoftwareTokenAuthGetDetails******" + e.getFault().getFaultString()
					+ "**************\n");
			logger.debug("Error while getting Token File.");
			logger.error(e);
			ActionContext.getContext().put(ERROR_MESSAGE, "Error while getting Token File");
			result = ERROR;
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			String errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
			}
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			result = ERROR;
		}
		return result;
	}

	private void setPIN(String tamUserId) {
		try {
			// call to forgotPIN will set a new temporary PIN
			String pin = TAMAccessProviderImpl.getInstance().forgotPIN(tamUserId);
			
			String userAlias = CommonAuthService.getInstance().getDaoProvider().getUserAlias(tamUserId);

			// send PIN to user
			CommonAuthService.getInstance().getGatewayProvider().sendPIN(userAlias, pin);
			logger.debug("Default pin set sucessfully");
		} catch (AuthException e) {
			logger.error("AMIS operation failed while setting generated pin.", e);
		}
	}

	public String setSecurityQuestions() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		String result;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			
			String actionName = context.getName();
			result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if (SUCCESS.equals(result)) {
				// TokenDownload.jsp is called from two different flows that's why added below in script path
				ActionContext.getContext().put(SLASH_DOT_DOT, "/..");
			}
			
			return result;
		}
		
		result = validateSecurityQuestions();
		
		if(!SUCCESS.equals(result)){
			return result;
		}
		
		return updateSecurityQuestions();
	}	

	private String validateSecurityQuestions() {
		secQueList = secureTokenDownload.getDbSecurityQuestions();
		if("-1".equals(selectedSecQuestion1)) {
			addActionError("Please select security question 1.");
			return INPUT;
		}
		if(StringUtils.isEmpty(securityAnswer1)){
			addActionError("Please enter security answer 1.");
			return INPUT;
		}
		securityAnswer1 = EscapeUtils.escapeHtml(securityAnswer1);
		if("-1".equals(selectedSecQuestion2)) {
			addActionError("Please select security question 2.");
			return INPUT;
		}
		
		if(StringUtils.isEmpty(securityAnswer2)){
			addActionError("Please enter security answer 2.");
			return INPUT;
		}
		securityAnswer2 = EscapeUtils.escapeHtml(securityAnswer2);
		
		String result = SUCCESS;
		if (selectedSecQuestion1.equals(selectedSecQuestion2)) {
			logger.info("Both the security question cannot be the same.");
			addActionError("Both the security question cannot be the same.");
			result = INPUT;
		}
		return result;
	}

	private String updateSecurityQuestions() {
		try {
			TAMAccessProviderImpl tamAccessProviderImpl = TAMAccessProviderImpl.getInstance();
			UserInfo userInfo = tamAccessProviderImpl.getUserInfo(secureTokenDownload.getTamUserId());
			Map<String, String> securityQuestionMap = new HashMap<>();
			securityQuestionMap.put(selectedSecQuestion1, securityAnswer1);
			securityQuestionMap.put(selectedSecQuestion2, securityAnswer2);
			userInfo.setAuthLevel("token");
			userInfo.setSecurityQuestions(securityQuestionMap);
			tamAccessProviderImpl.modifyUser(userInfo);
		} catch (AuthException e) {
			logger.error("Error occred while registering the security questions.");
			logger.error(Utility.getStackTrace(e));
			ActionContext.getContext().put("errorMessage", "Error occred while registering the security questions");
			return ERROR;
		}
		
		// TokenDownload.jsp is called from two different flows that's why added below in script path
		ActionContext.getContext().put("SLASH_DOT_DOT", "/..");
		return SUCCESS;
	}

	@Override
	public SecureTokenDownload getModel() {
		return secureTokenDownload;
	}

	@Override
	public String getScopeKey() {
		return scopedKey;
	}

	@Override
	public void setModel(SecureTokenDownload secureTokenDownload) {
		this.secureTokenDownload = secureTokenDownload;
	}

	@Override
	public void setScopeKey(String scopedKey) {
		this.scopedKey = scopedKey;
	}

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public String getTokenFileName() {
		return tokenFileName;
	}

	public void setTokenFileName(String tokenFileName) {
		this.tokenFileName = tokenFileName;
	}

	public List<String> getSecQueList() {
		return secQueList;
	}

	public void setSecQueList(List<String> secQueList) {
		this.secQueList = secQueList;
	}

	public String getSelectedSecQuestion1() {
		return selectedSecQuestion1;
	}

	public void setSelectedSecQuestion1(String selectedSecQuestion1) {
		this.selectedSecQuestion1 = selectedSecQuestion1;
	}

	public String getSecurityAnswer1() {
		return securityAnswer1;
	}

	public void setSecurityAnswer1(String securityAnswer1) {
		this.securityAnswer1 = securityAnswer1;
	}

	public String getSelectedSecQuestion2() {
		return selectedSecQuestion2;
	}

	public void setSelectedSecQuestion2(String selectedSecQuestion2) {
		this.selectedSecQuestion2 = selectedSecQuestion2;
	}

	public String getSecurityAnswer2() {
		return securityAnswer2;
	}

	public void setSecurityAnswer2(String securityAnswer2) {
		this.securityAnswer2 = securityAnswer2;
	}

	public String getBrandingContext() {
		return brandingContext;
	}

	public void setBrandingContext(String brandingContext) {
		this.brandingContext = brandingContext;
	}
}
