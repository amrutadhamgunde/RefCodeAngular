package com.mpts.auth.struts.bundle.pages.tam;

import java.security.GeneralSecurityException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.TAMAccessProviderImpl;
import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.AMISOperationFailedException;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.OTPExpiredException;
import com.mpts.auth.struts.bundle.exception.UserNotFoundException;
import com.mpts.auth.struts.bundle.exception.UserNotRegisteredException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.ForgotUserAliasScopedModel;
import com.mpts.auth.struts.bundle.model.SecurityQuestion;
import com.mpts.auth.struts.bundle.util.EscapeUtils;
import com.mpts.auth.struts.bundle.util.HashOTPGenerator;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.interceptor.ScopedModelDriven;

public class ForgotUserAlias extends CommonAction implements ScopedModelDriven<ForgotUserAliasScopedModel> {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(ForgotUserAlias.class);
	
	private static final String ERROR_MESSAGE = "errorMessage";
	private static final String PAGE_NAME_KEY = "PageName";
	private static final String PAGE_NAME_VALUE = "Forgot UserAlias";
	private static final String RESULT_INPUT_B2C = "inputb2c";
	
	private String emailId;
	private String mobileNumber;
	private String institutionCode;
	private String cardNumber;
	private String actionUrl;
	private String brandingContext;
	private String forgotOpType;
	private String showInstituteCode = "N";
	
	protected ForgotUserAliasScopedModel commonAuthModel;
	protected String scopedKey = "ForgotUserAlias";
	private transient List<SecurityQuestion> securityQuestions;

	@Override
	public ForgotUserAliasScopedModel getModel() {
		return commonAuthModel;
	}

	@Override
	public void setModel(ForgotUserAliasScopedModel commonAuthModel) {
		this.commonAuthModel = commonAuthModel;
	}

	@Override
	public void setScopeKey(String scopedKey) {
		this.scopedKey = scopedKey;
	}
	
	@Override
	public String getScopeKey() {
		return scopedKey;
	}

	public String showForgotUserAliasPage() {
		forgotOpType = Constants.FORGOT_OP_USERALIAS;
		return SUCCESS;
	}

	public String getUser() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		String result;
		boolean languageSelected = false;
		
		String typeOfUser = CommonAuthService.getInstance().getUserType();
		
		if(ArrayUtils.isNotEmpty(selectLanguage)) {
			languageSelected = true;
			
			String actionName = context.getName();
			result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!SUCCESS.equals(result) && !"otpVerification".equals(result)) {
				return result;
			}
		} else {
			result = validateFields(typeOfUser);
			
			if(SUCCESS.equals(result)) {
				result = getValidTAMUserId(typeOfUser);
			}
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		}
		
		if (Constants.B2C.equals(typeOfUser)) {
			result =  forwardToOTPVerification(languageSelected);
		} else {
			result =  forwardToSecQueVerification(typeOfUser,languageSelected);
		}
		
		return result;
	}

	private String forwardToOTPVerification(boolean languageSelected) {
		ActionContext.getContext().put(PAGE_NAME_KEY, PAGE_NAME_VALUE);
		forgotOpType = Constants.FORGOT_OP_USERALIAS;
		String result = generateOTP(languageSelected);
		return SUCCESS.equals(result) ? "otpVerification" : result;
	}

	private String forwardToSecQueVerification(String typeOfUser, boolean languageSelected) {
		if(!languageSelected) {
			String result = getSecurityQuestions(typeOfUser);
			if(!SUCCESS.equals(result)) {
				return result;
			}
		} else {
			securityQuestions = commonAuthModel.getSecurityQuestions();
		}
		
		if (securityQuestions.size() >= 2) {
			securityQuestion1 = securityQuestions.get(0).getQuestion();
			securityQuestion2 = securityQuestions.get(1).getQuestion();
		}
		actionUrl = "./forgotUserIdSecQueVerification";
		ActionContext.getContext().put(PAGE_NAME_KEY, PAGE_NAME_VALUE);
		forgotOpType = Constants.FORGOT_OP_USERALIAS;
		return SUCCESS;
	}

	private String validateFields(String typeOfUser) {
		if (!Constants.B2C.equals(typeOfUser)) {
			if (StringUtils.isEmpty(mobileNumber)) {
				addActionError("Field 'Mobile Number' is required");
				return INPUT;
			}
			mobileNumber = EscapeUtils.escapeHtml(mobileNumber);

			if (StringUtils.isEmpty(emailId)) {
				addActionError("Field 'Email ID' is required");
				return INPUT;
			}
			emailId = EscapeUtils.escapeHtml(emailId);
			if("Y".equals(showInstituteCode)){
				if (StringUtils.isEmpty(institutionCode)) {
					addActionError("Field 'Institution Code' is required");
					return INPUT;
				}
				institutionCode = EscapeUtils.escapeHtml(institutionCode);
			}
		} else {
			if (StringUtils.isEmpty(cardNumber)) {
				addActionError("Field 'Card Number' is required");
				return INPUT;
			}
			cardNumber = EscapeUtils.escapeHtml(cardNumber);
		}
		return SUCCESS;
	}

	private String getSecurityQuestions(String typeOfUser) {
		String result = SUCCESS;
		try {
			securityQuestions = TAMAccessProviderImpl.getInstance().getSecurityQuestions(tamUserId);
			
			commonAuthModel.setSecurityQuestions(securityQuestions);
			commonAuthModel.setTamUserId(tamUserId);
			
			if (Utility.isEmpty(securityQuestions)
					|| (securityQuestions.size() == 1 && "".equals(securityQuestions.get(0).getAnswer()))) {
				logger.error(CommonAuthService.getInstance().getProperty(Constants.SEC_QUEST_NOT_EXISTS));
				ActionContext.getContext().put(ERROR_MESSAGE, CommonAuthService.getInstance().getProperty(Constants.SEC_QUEST_NOT_EXISTS));
				result = ERROR;
			}
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			addActionError("Error occured while getting the security questions");
			if (Constants.B2C.equals(typeOfUser)) {
				result = RESULT_INPUT_B2C;
			} else {
				result = INPUT;
			}
		}
		
		return result;
	}

	private String getValidTAMUserId(String typeOfUser) {
		String result = SUCCESS;
		try {
			String userAlias = null;
			if (Constants.B2C.equals(typeOfUser)) {
				userAlias = CommonAuthService.getInstance().getDaoProvider().getUserAliasByCardNumber(cardNumber);
				tamUserId = CommonAuthService.getInstance().getDaoProvider().getTAMUserId(userAlias);
			} else {
				Map<String, String> userMap;
				if("Y".equals(showInstituteCode)){
					userAlias = commonAuthModel.getUserAlias(emailId, mobileNumber, institutionCode);
				} else {
					userMap = CommonAuthService.getInstance().getDaoProvider().getUserAlias(mobileNumber, emailId);
					if(userMap != null){
						commonAuthModel.setUserDetails(userMap, emailId, mobileNumber);
						if(userMap.size() > 1){
							showInstituteCode = "Y";
							return INPUT;
						} else if(userMap.size() == 1){
							userAlias = userMap.values().iterator().next();
							showInstituteCode = "N";
						}
					}
				}
				
				tamUserId = CommonAuthService.getInstance().getDaoProvider().getTAMUserId(userAlias);
				
				if(!validateUser(userAlias)) {
					return INPUT;
				}
			}
			commonAuthModel.setUserAlias(userAlias);
			
			if (StringUtils.isEmpty(tamUserId)) {
				onUserException(null, Constants.INVALID_CREDENTIALS);
				result = getInputResult(typeOfUser);
			}
		} catch (UserNotFoundException e) {
			String errorMessage = CommonAuthService.getInstance().getProperty(Constants.INVALID_EMAIL_MOBILENO,
					"Invalid Email Id or Mobile Number" + ("Y".equals(showInstituteCode) ? " or Institution Code" : ""));
			logger.error(e.getError(), e);
			addActionError(errorMessage);
			result = getInputResult(typeOfUser);
		} catch(UserNotRegisteredException e) {
			logger.error(e);
		} 
		
		return result;
	}
	
	
	private boolean validateUser(String userAlias) {
		try {
			if (!AMISAccessProvider.isUserEnabled(tamUserId)) {
				String userSuspendedMsg = CommonAuthService.getInstance().getProperty(Constants.USER_SUSPENDED,
						"User '" + userAlias + "' is suspended. Please contact administrator.");
				logger.error(userSuspendedMsg);
				addActionError(userSuspendedMsg);
				return false;
			}
		} catch (AMISOperationFailedException e) {
			Utility.getStackTrace(e);
		}
		return true;
	}
	
	private String getInputResult(String typeOfUser) {
		if (Constants.B2C.equals(typeOfUser)) {
			return RESULT_INPUT_B2C;
		}
		return INPUT;
	}

	private void onUserException(String errorMessage, String errorMsgKey) {
		String errorMessage1 = errorMessage;
		if (errorMessage == null || "".equals(errorMessage)) {
			errorMessage1 = CommonAuthService.getInstance().getProperty(errorMsgKey);
		}
		logger.error(errorMessage1);
		addActionError(errorMessage1);
	}

	private String generateOTP(boolean languageSelected) {
		if(!languageSelected) {
			try {
				commonAuthModel.setInvalidRetryCount(0);
				String otp = HashOTPGenerator.generateOTP(Utility.generateRandomNumber(32), System.nanoTime(), 7, true,
						4);
				
				CommonAuthService.getInstance().getGatewayProvider()
						.sendOTPForgotPassword(commonAuthModel.getUserAlias(), otp);
				CommonAuthService.getInstance().getDaoProvider().saveOTP(commonAuthModel.getUserAlias(), otp);
			} catch (GeneralSecurityException e1) {
				logger.error("Error occured while generating the OTP.", e1);
				errorMessage = "Error occured while generating the OTP";
				ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
				return ERROR;
			} catch (AuthException e) {
				logger.error(Utility.getStackTrace(e));
				errorMessage = e.getError();
				if (StringUtils.isEmpty(errorMessage)) {
					errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
				}
				ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
				return ERROR;
			}
		}
		ActionContext.getContext().put(PAGE_NAME_KEY, PAGE_NAME_VALUE);
		actionUrl = "./forgotUserIdOTPVerification";
		return SUCCESS;
	}
	
	public String validateSeqQue() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		boolean languageSelected = false;
		String result;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			languageSelected = true;
			
			securityQuestion1 = commonAuthModel.getSecurityQuestions().get(0).getQuestion();
			securityQuestion2 = commonAuthModel.getSecurityQuestions().get(1).getQuestion();
			
			String actionName = context.getName();
			result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		} else {
			result = validateSeqAns();
			if(!SUCCESS.equals(result)) {
				return result;
			}
		}
		
		return verifySeqQue(languageSelected);
	}

	private String verifySeqQue(boolean languageSelected) {
		if (languageSelected || (securityAnswer1.trim().equals(commonAuthModel.getSecurityQuestions().get(0).getAnswer())
				&& (securityAnswer2.trim().equals(commonAuthModel.getSecurityQuestions().get(1).getAnswer())))) {
			return generateOTP(languageSelected);
		} else {
			return validateRetryCount(Constants.INVALID_SECURITY_QUESTIONS);
		}
	}

	private String validateSeqAns() {
		if (StringUtils.isEmpty(securityAnswer1)) {
			addActionError("Answer for security question '"
					+ commonAuthModel.getSecurityQuestions().get(0).getQuestion() + "' is required");
			return INPUT;
		}
		securityAnswer1 = EscapeUtils.escapeHtml(securityAnswer1);
		if (StringUtils.isEmpty(securityAnswer2)) {
			addActionError("Answer for security question '"
					+ commonAuthModel.getSecurityQuestions().get(1).getQuestion() + "' is required");
			return INPUT;
		}
		securityAnswer2 = EscapeUtils.escapeHtml(securityAnswer2);
		return SUCCESS;
	}

	private String validateRetryCount(String errorMessageKey) {
		int retryCount = commonAuthModel.getInvalidRetryCount();
		if (retryCount >= CommonAuthService.getInstance().getMaxNoAttempts()) {
			try {
				if(!AMISAccessProvider.disableUser(commonAuthModel.getTamUserId())) {
					logger.error(commonAuthModel.getTamUserId() + " is not disabled in forgot user alias . User does not found in RSA.");
				}
			} catch (AuthException exe) {
				logger.error(Utility.getStackTrace(exe));
			}
			errorMessage = CommonAuthService.getInstance().getProperty(Constants.MAX_ATTEMPTS);
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			return ERROR;
		} else {
			String invalidMessage = CommonAuthService.getInstance()
					.getProperty(errorMessageKey);
			invalidMessage = invalidMessage.replace(Constants.NO_OF_ATTEMPTS,
					String.valueOf(CommonAuthService.getInstance().getMaxNoAttempts() - retryCount));
			addActionError(invalidMessage);
			commonAuthModel.setInvalidRetryCount(++retryCount);
			return INPUT;
		}
	}

	public String otpVerification() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		boolean languageSelected = false;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			languageSelected = true;
			
			String actionName = context.getName();
			String result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		} else {
			if (StringUtils.isEmpty(oneTimePassword)) {
				addActionError("Field 'OTP' is required to verification");
				return INPUT;
			}
			oneTimePassword = EscapeUtils.escapeHtml(oneTimePassword);
		}
		
		return verifyOTP(languageSelected);
	}

	private String verifyOTP(boolean languageSelected) {
		String result;
		try {
			if (languageSelected || CommonAuthService.getInstance().getDaoProvider().verifyOTP(commonAuthModel.getUserAlias(),
					oneTimePassword)) {
				result = onSuccessfulOTPVerification(languageSelected);
			} else {
				result = validateRetryCount(Constants.INVALID_OTP);
			}
		} catch (OTPExpiredException e) {
			errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.OTP_EXPIRED_MESSAGE);
			}
			logger.error(errorMessage, e);
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			result = ERROR;
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			String errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
			}
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			result = ERROR;
		}
		return result;
	}

	private String onSuccessfulOTPVerification(boolean languageSelected) throws AuthException {
		if(!languageSelected) {
			CommonAuthService.getInstance().getGatewayProvider().sendUserAlias(commonAuthModel.getUserAlias());
			logger.info("Forgot user alias, user id :" + commonAuthModel.getUserAlias());
		}
		Map<String, String> values = null;
		try {
			values = CommonAuthService.getInstance().getDaoProvider()
					.getUserContacts(commonAuthModel.getUserAlias());
		} catch (Exception e) {
			logger.error(Utility.getStackTrace(e));
			ActionContext.getContext().put(ERROR_MESSAGE,
					CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR));
			return ERROR;
		}
		String message = CommonAuthService.getInstance().getProperty(Constants.OTP_VERIFY_SUCCESSFUL);
		message = message.replace(Constants.MOBILE, Utility.maskMobileNo(values.get(Constants.MOBILE_NO)));
		message = message.replace(Constants.EMAIL, Utility.maskEmailId(values.get(Constants.EMAIL_ID)));
		addActionMessage(message);
		logger.debug("before returning success");
		return SUCCESS;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getActionUrl() {
		return actionUrl;
	}

	public void setActionUrl(String actionUrl) {
		this.actionUrl = actionUrl;
	}

	public String getForgotOpType() {
		return forgotOpType;
	}

	public void setForgotOpType(String forgotOpType) {
		this.forgotOpType = forgotOpType;
	}

	public String getBrandingContext() {
		return brandingContext;
	}

	public void setBrandingContext(String brandingContext) {
		this.brandingContext = brandingContext;
	}

	public String getInstitutionCode() {
		return institutionCode;
	}

	public void setInstitutionCode(String institutionCode) {
		this.institutionCode = institutionCode;
	}

	public String getShowInstituteCode() {
		return showInstituteCode;
	}

	public void setShowInstituteCode(String showInstituteCode) {
		this.showInstituteCode = showInstituteCode;
	}
}
