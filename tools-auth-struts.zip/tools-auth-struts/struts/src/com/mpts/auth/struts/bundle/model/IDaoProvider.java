package com.mpts.auth.struts.bundle.model;

import java.util.List;
import java.util.Map;

import com.mpts.auth.struts.bundle.exception.OTPExpiredException;
import com.mpts.auth.struts.bundle.exception.UserNotAuthorizedException;
import com.mpts.auth.struts.bundle.exception.UserNotFoundException;
import com.mpts.auth.struts.bundle.exception.UserNotRegisteredException;

public interface IDaoProvider {

	/**
	 * The getTAMUserId method is used to get the TAM UserID against the
	 * UserAlias from the database.
	 * 
	 * @param userAlias
	 * @return TAM UserID is returned.
	 * @throws UserNotFoundException
	 * @throws UserNotAuthorizedException
	 */
	String getTAMUserId(String userAlias) throws UserNotFoundException, UserNotRegisteredException;
	

	/**
	 * The getUserId method is used to get the User Alias against the TAM User
	 * ID from the database.
	 * 
	 * @return User Alias is returned.
	 * @throws UserNotFoundException
	 * @throws UserNotAuthorizedException
	 */
	String getUserAlias(String tamUserId) throws UserNotFoundException;

	/**
	 * The getUserAlias method is used to get the User Alias against the
	 * mobileNo and emailId from the database.
	 * 
	 * @return Map with Institution Code mapped against UserAlias is returned.
	 * @throws UserNotFoundException
	 * @throws UserNotAuthorizedException
	 */
	Map<String, String> getUserAlias(String mobileNo, String emailId) throws UserNotFoundException;
	
	/**
	 * The getUserAliasByCardNumber method is used to get the User Alias against the
	 * card number from the database.
	 * 
	 * @return UserAlias is returned.
	 * @throws UserNotFoundException
	 * @throws UserNotAuthorizedException
	 */
	String getUserAliasByCardNumber(String cardNumber) throws UserNotFoundException;

	/**
	 * The getUserContacts method is used to get the mobileNo and emailId from
	 * the database for the user.<br>
	 * The key for mobile number has to be
	 * <b><i>com.mpts.auth.bundle.model.Constants.MOBILE_NO</i></b><br>
	 * The key for email id has to be
	 * <b><i>com.mpts.auth.bundle.model.Constants.EMAIL_ID</i></b>
	 * 
	 * @return UserAlias is returned.
	 */
	Map<String, String> getUserContacts(String userAlias);

	/**
	 * The getSecurityQuestions method is used to get the list of security
	 * questions from the database.
	 */
	List<String> getSecurityQuestions();

	/**
	 * The saveOTP method is used to save the generated OTP against the TAM
	 * UserID
	 * 
	 * @param userAlias
	 * @param otp
	 */
	void saveOTP(String userAlias, String otp);

	/**
	 * The verifyOTP method is used to verify the saved OTP against the TAM
	 * UserID
	 * 
	 * @param userAlias
	 * @param otp
	 * @throws OTPExpiredException
	 */
	boolean verifyOTP(String userAlias, String otp) throws OTPExpiredException;
	
	/**
	 * The getClientKey method returns the client public key.
	 * 
	 * @return client key
	 * 
	 * Used for OpenId provider only
	 */
	String getClientKey();

	/**
	 * B2C
	 * The getSecurityQuestions method returns the security questions and answers for the user
	 * @param userAlias
	 * @return Map of security question and answers
	 */
	Map<String, String> getSecurityQuestions(String userAlias);
	
	/**
	 * B2C
	 * The generateTempPassword method returns the temporary password 
	 * @param userAlias
	 * @return Map of security question and answers
	 */
	String generateTempPassword();
	
	/**
	 * The getLanguages method returns the locale and languages
	 * @return Map of locale and language
	 */
	Map<String, LangLocale> getLanguages();
	
	/**
	 * The hash method returns the hashed value of input text
	 * @param input
	 * @return hashed value of input text
	 */
	String hash(String input);
}