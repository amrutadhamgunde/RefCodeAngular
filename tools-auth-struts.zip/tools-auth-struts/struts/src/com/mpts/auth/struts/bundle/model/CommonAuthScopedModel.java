package com.mpts.auth.struts.bundle.model;

import java.io.Serializable;
import java.util.List;

import com.mpts.auth.struts.bundle.model.SecurityQuestion;

public class CommonAuthScopedModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String tamUserId;
	private String userAlias;
	private transient List<SecurityQuestion> securityQuestions;
	private int invalidRetryCount;

	public String getTamUserId() {
		return tamUserId;
	}

	public void setTamUserId(String tamUserId) {
		this.tamUserId = tamUserId;
	}

	public List<SecurityQuestion> getSecurityQuestions() {
		return securityQuestions;
	}

	public void setSecurityQuestions(List<SecurityQuestion> securityQuestions) {
		this.securityQuestions = securityQuestions;
	}

	public int getInvalidRetryCount() {
		return invalidRetryCount;
	}

	public void setInvalidRetryCount(int invalidRetryCount) {
		this.invalidRetryCount = invalidRetryCount;
	}

	public String getUserAlias() {
		return userAlias;
	}

	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}
}
