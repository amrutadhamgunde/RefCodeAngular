package com.mpts.auth.struts.bundle.exception;

public class GatewayException extends TAMException {
	private static final long serialVersionUID = 1L;

	public GatewayException(String error) {
		super(error);
	}

	public GatewayException(Throwable t) {
		super(t);
	}
}
