package com.mpts.auth.struts.bundle.pages.tam;

import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class AppLogout extends ActionSupport {

	private static final long serialVersionUID = -5338398379554659255L;
	private String brandingContext;

	public String logout() {
		ActionContext.getContext().getSession().put(Constants.JUNCTION, brandingContext);
		ActionContext.getContext().getSession().put(Constants.APP, Utility.getStaticAppName());
		return SUCCESS;
	}

	public String getBrandingContext() {
		return brandingContext;
	}

	public void setBrandingContext(String brandingContext) {
		this.brandingContext = brandingContext;
	}
}
