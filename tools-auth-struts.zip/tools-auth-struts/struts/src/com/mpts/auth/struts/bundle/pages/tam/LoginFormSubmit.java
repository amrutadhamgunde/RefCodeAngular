package com.mpts.auth.struts.bundle.pages.tam;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.AMISOperationFailedException;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.UserNotFoundException;
import com.mpts.auth.struts.bundle.exception.UserNotRegisteredException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.EscapeUtils;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class LoginFormSubmit extends ActionSupport /*implements ScopedModelDriven<CommonAuthScopedModel>*/ {

	private static final long serialVersionUID = -1296764591579938296L;
	private static final Logger logger = Logger.getLogger(LoginFormSubmit.class);

	private String useralias;
	private String password;
	private String tamUserId;
	private String loginFormType;
	private String loginPageName;
	private String brandingContext;
	private String registerAction;
	private String token;

	@Override
	public void validate() {
		super.validate();
		
		String portalType = CommonAuthService.getInstance().getUserType();
		if(Constants.B2C.equals(portalType)) {
			loginPageName = "CardHolderLogin.jsp";
		} else {
			if(loginFormType.equals(Constants.TOKEN)){
				loginPageName = "TokenLogin.jsp";
			} else {
				loginPageName = "TokenDownloadLogin.jsp";
			}
		}
		
		if(useralias == null || "".equals(useralias)){
			addActionError("Field 'User Id' is required");
		}
		
		if(password == null || "".equals(password)){
			if(loginFormType.equals(Constants.TOKEN)){
				addActionError("Field 'Passcode' is required");
			}else{
				addActionError("Field 'Password' is required");
			}
		}
	}

	@Override
	public String execute() {
		useralias = EscapeUtils.escapeHtml(useralias);
		password = EscapeUtils.escapeHtml(password);
		
		String result = getValidTAMUserId();
		if(!SUCCESS.equals(result)) {
			return result;
		}
		
		HttpServletResponse response = ServletActionContext.getResponse();
		Cookie cookie = new Cookie("login-form-type", loginFormType);
		cookie.setSecure(true);
		cookie.setPath("/");
		response.addCookie(cookie);
		
		return "loginformsubmit";
	}
	
	private String getValidTAMUserId() {
		String result = SUCCESS;
		String portalType = CommonAuthService.getInstance().getUserType();
		try {
			tamUserId = CommonAuthService.getInstance().getDaoProvider().getTAMUserId(useralias);
			if (StringUtils.isEmpty(tamUserId)) {
				String usrName = useralias;
				useralias = "";
				throw new UserNotFoundException("User '" + usrName + "' not found");
			}
			
			if (Constants.PASS.equals(loginFormType)
					&& Constants.B2B.equals(CommonAuthService.getInstance().getUserType())) {
				result = isUserSuspended();
			}
		
		} catch (UserNotFoundException e) {
			String errorMessage = CommonAuthService.getInstance().getProperty(Constants.AUTH_FAILED,
					"Authentication failed. Please enter valid User ID or Password.");
			onUserException(e, errorMessage);
			useralias = "";
			result = INPUT;
		} catch (UserNotRegisteredException e) {
			if (Constants.B2C.equals(portalType)) {
				logger.info(e.getError(),e);
				logger.info("User not registed, so redirecting to user registration");
				registerAction = CommonAuthService.getInstance().getProperty(Constants.REGISTER_ACTION);
				result = "authenticate";
			} else {
				String errorMessage = CommonAuthService.getInstance().getProperty(Constants.AUTH_FAILED,
						"Authentication failed. Please enter valid User ID or Password.");
				onUserException(e, errorMessage);
				result = INPUT;
			}
		} catch (Exception e) {
			addActionError(CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR));
			logger.error(Utility.getStackTrace(e));
			result = INPUT;
		}
		return result;
	}
	
	private String isUserSuspended() {
		try {
			if (!AMISAccessProvider.isUserEnabled(tamUserId)) {
				String userSuspendedMsg = CommonAuthService.getInstance().getProperty(Constants.USER_SUSPENDED,
						"User is suspended. Please contact administrator.");
				addActionError(userSuspendedMsg);
				logger.error(userSuspendedMsg);
				return INPUT;
			}
		} catch (AMISOperationFailedException e) {
			logger.error(Utility.getStackTrace(e));
			String userSuspendedMsg = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR,
					"Internal error.");
			addActionError(userSuspendedMsg);
			return INPUT;
		}
		return SUCCESS;
	}

	private void onUserException(AuthException e, String displayErrorMessage) {
		logger.error(e.getError(),e);
		addActionError(displayErrorMessage);
	}

	public String getUseralias() {
		return useralias;
	}

	public void setUseralias(String useralias) {
		this.useralias = useralias;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTamUserId() {
		return tamUserId;
	}

	public void setTamUserId(String tamUserId) {
		this.tamUserId = tamUserId;
	}

	public String getLoginFormType() {
		return loginFormType;
	}

	public void setLoginFormType(String loginFormType) {
		this.loginFormType = loginFormType;
	}
	
	public String getLoginPageName() {
		return loginPageName;
	}

	public void setLoginPageName(String loginPageName) {
		this.loginPageName = loginPageName;
	}

	public String getBrandingContext() {
		return brandingContext;
	}

	public void setBrandingContext(String brandingContext) {
		this.brandingContext = brandingContext;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRegisterAction() {
		return registerAction;
	}

	public void setRegisterAction(String registerAction) {
		this.registerAction = registerAction;
	}
}
