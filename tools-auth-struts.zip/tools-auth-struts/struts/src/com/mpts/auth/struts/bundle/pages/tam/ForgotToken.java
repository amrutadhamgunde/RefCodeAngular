package com.mpts.auth.struts.bundle.pages.tam;

import java.security.GeneralSecurityException;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.TAMAccessProviderImpl;
import com.mpts.auth.struts.bundle.api.AMISAccessProvider;
import com.mpts.auth.struts.bundle.exception.AuthException;
import com.mpts.auth.struts.bundle.exception.OTPExpiredException;
import com.mpts.auth.struts.bundle.exception.UserNotFoundException;
import com.mpts.auth.struts.bundle.exception.UserNotRegisteredException;
import com.mpts.auth.struts.bundle.model.CommonAuthScopedModel;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.SecurityQuestion;
import com.mpts.auth.struts.bundle.util.EscapeUtils;
import com.mpts.auth.struts.bundle.util.HashOTPGenerator;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.interceptor.ScopedModelDriven;

public class ForgotToken extends CommonAction implements ScopedModelDriven<CommonAuthScopedModel> {

	private static final long serialVersionUID = -1296764591579938296L;
	private static final Logger logger = Logger.getLogger(ForgotToken.class);
	
	private static final String ERROR_MESSAGE = "errorMessage";

	private String useralias;
	private String source;
	private String actionUrl;
	private String forgotOpType;
	
	protected CommonAuthScopedModel commonAuthModel;
	protected String scopedKey = "ForgotToken";
	private transient List<SecurityQuestion> securityQuestions;

	@Override
	public String execute() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		String result;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			
			String actionName = context.getName();
			result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!"securityquestionverification".equals(result)) {
				return result;
			}
			
			securityQuestions = commonAuthModel.getSecurityQuestions();
		} else {
			result = getValidTAMUserId();
			if(SUCCESS.equals(result)) {
				result = getSecurityQuestions();
			}
			
			if(!SUCCESS.equals(result)) {
				return result;
			}
		}
		
		if (securityQuestions.size() >= 2) {
			securityQuestion1 = securityQuestions.get(0).getQuestion();
			securityQuestion2 = securityQuestions.get(1).getQuestion();
		}
		actionUrl = "./securityquestionverificationsubmit";
		ActionContext.getContext().put("PageName", "Forgot Token");
		forgotOpType = Constants.FORGOT_OP_TOKEN;
		return "securityquestionverification";
	}

	private String getValidTAMUserId() {
		String result = SUCCESS;
		
		if (source == null) {
			result = INPUT;
		} else if (StringUtils.isEmpty(useralias)) {
			addActionError("Field 'User Id' is required");
			result = INPUT;
		} else {
			useralias = EscapeUtils.escapeHtml(useralias);
			try {
				tamUserId = CommonAuthService.getInstance().getDaoProvider().getTAMUserId(useralias);
				if (!AMISAccessProvider.isUserEnabled(tamUserId)) {
					String userSuspendedMsg = CommonAuthService.getInstance().getProperty(Constants.USER_SUSPENDED,
							"User '"+ useralias + "' is suspended. Please contact administrator.");
					logger.error(userSuspendedMsg);
					addActionError(userSuspendedMsg);
					result = INPUT;
				}
			} catch (UserNotFoundException e) {
				onUserException(e, Constants.USER_NOT_EXISTS_MESSAGE);
				result = INPUT;
			} catch(UserNotRegisteredException e) {
				logger.error(e.getError(), e);
			} catch (AuthException e) {
				onUserException(e, Constants.INTERNAL_ERROR);
				result = INPUT;
			}
		}
		return result;
	}

	private void onUserException(AuthException e, String errorMsgKey) {
		String errorMessage = e.getError();
		if (StringUtils.isNotEmpty(errorMessage)) {
			errorMessage = CommonAuthService.getInstance().getProperty(errorMsgKey);
		}
		logger.error(errorMessage, e);
		addActionError(errorMessage);
	}
	
	private String getSecurityQuestions() {
		try {
			securityQuestions = TAMAccessProviderImpl.getInstance().getSecurityQuestions(tamUserId);
			
			commonAuthModel.setSecurityQuestions(securityQuestions);
			commonAuthModel.setUserAlias(useralias);
			commonAuthModel.setTamUserId(tamUserId);
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			addActionError("Error occured while getting the security questions");
			return INPUT;
		}

		if (Utility.isEmpty(securityQuestions)) {
			addActionError(CommonAuthService.getInstance().getProperty(Constants.SEC_QUEST_NOT_EXISTS));
			return INPUT;
		}
		return SUCCESS;
	}

	public String validateSecurityQuestions() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		boolean languageSelected = false;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			languageSelected = true;
			
			securityQuestion1 = commonAuthModel.getSecurityQuestions().get(0).getQuestion();
			securityQuestion2 = commonAuthModel.getSecurityQuestions().get(1).getQuestion();
			
			String actionName = context.getName();
			String result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!"verifyotp".equals(result)) {
				return result;
			}
		}
		
		securityQuestion1 = commonAuthModel.getSecurityQuestions().get(0).getQuestion();
		securityQuestion2 = commonAuthModel.getSecurityQuestions().get(1).getQuestion();
		
		if(!languageSelected) {
			if (StringUtils.isEmpty(securityAnswer1)) {
				addActionError("Answer for security question '"
						+ commonAuthModel.getSecurityQuestions().get(0).getQuestion() + "' is required");
				return INPUT;
			}
			securityAnswer1 = EscapeUtils.escapeHtml(securityAnswer1);
			if (StringUtils.isEmpty(securityAnswer2)) {
				addActionError("Answer for security question '"
						+ commonAuthModel.getSecurityQuestions().get(1).getQuestion() + "' is required");
				return INPUT;
			}
			securityAnswer2 = EscapeUtils.escapeHtml(securityAnswer2);
		}
		
		return verifySeqQue(languageSelected);
	}
	
	private String verifySeqQue(boolean languageSelected) {
		if (languageSelected || securityAnswer1.trim().equals(commonAuthModel.getSecurityQuestions().get(0).getAnswer())
				&& (securityAnswer2.trim().equals(commonAuthModel.getSecurityQuestions().get(1).getAnswer()))) {
			if(!languageSelected) {
				String result = generateAndSendOTP();
				if(!SUCCESS.equals(result)) {
					return result;
				}
				
			}
			ActionContext.getContext().put("PageName", "Forgot Token");
			actionUrl = "./auth/eaiauthentication";
			return "verifyotp";
		} else {
			return validateRetryCount(Constants.INVALID_SECURITY_QUESTIONS);
		}
	}

	private String validateRetryCount(String errorMessageKey) {
		int retryCount = commonAuthModel.getInvalidRetryCount();
		if (retryCount >= CommonAuthService.getInstance().getMaxNoAttempts()) {
			try {
				if(!AMISAccessProvider.disableUser(commonAuthModel.getTamUserId())) {
					logger.error(commonAuthModel.getTamUserId() + " is not disabled in forgot user alias . User does not found in RSA.");
				}
			} catch (AuthException exe) {
				logger.error(Utility.getStackTrace(exe));
			}
			errorMessage = CommonAuthService.getInstance().getProperty(Constants.MAX_ATTEMPTS);
			return ERROR;
		} else {
			String invalidMessage = CommonAuthService.getInstance()
					.getProperty(errorMessageKey);
			invalidMessage = invalidMessage.replace(Constants.NO_OF_ATTEMPTS,
					String.valueOf(CommonAuthService.getInstance().getMaxNoAttempts() - retryCount));
			addActionError(invalidMessage);
			commonAuthModel.setInvalidRetryCount(++retryCount);
			return INPUT;
		}
	}

	private String generateAndSendOTP() {
		commonAuthModel.setInvalidRetryCount(0);
		try {
			String otp = HashOTPGenerator.generateOTP(Utility.generateRandomNumber(32), System.nanoTime(), 7, true,
					4);
			
			CommonAuthService.getInstance().getGatewayProvider()
					.sendOTPForgotPassword(commonAuthModel.getUserAlias(), otp);
			CommonAuthService.getInstance().getDaoProvider().saveOTP(commonAuthModel.getUserAlias(), otp);
		} catch (GeneralSecurityException e1) {
			logger.error("Error occured while generating the OTP.", e1);
			errorMessage = "Error occured while generating the OTP";
			return ERROR;
		} catch (AuthException e) {
			logger.error(Utility.getStackTrace(e));
			errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.INTERNAL_ERROR);
			}
			return ERROR;
		}
		return SUCCESS;
	}

	public String otpVerification() {
		ActionContext context = ActionContext.getContext();
		String[] selectLanguage = (String[]) context.getParameters().get(Constants.SELECT_LANGUAGE);
		
		boolean languageSelected = false;
		if(ArrayUtils.isNotEmpty(selectLanguage)){
			languageSelected = true;
			
			String actionName = context.getName();
			String result = (String) context.getSession().remove(Constants.RESULT + "_" + actionName);
			
			if(!"eaiauthenticationformsubmit".equals(result)) {
				return result;
			}
		}
		
		if(!languageSelected) {
			if (oneTimePassword == null || "".equals(oneTimePassword.trim())) {
				addActionError("Field 'OTP' is required to verification");
				return INPUT;
			}
			oneTimePassword = EscapeUtils.escapeHtml(oneTimePassword);
		}
		
		return verifyOTP(languageSelected);
	}

	private String verifyOTP(boolean languageSelected) {
		try {
			if (languageSelected || CommonAuthService.getInstance().getDaoProvider().verifyOTP(commonAuthModel.getUserAlias(),
					oneTimePassword)) {
				ActionContext.getContext().put("TamUserId", commonAuthModel.getTamUserId());
				return "eaiauthenticationformsubmit";
			} else {
				return validateRetryCount(Constants.INVALID_OTP);
			}
		} catch (OTPExpiredException e) {
			errorMessage = e.getError();
			if (StringUtils.isEmpty(errorMessage)) {
				errorMessage = CommonAuthService.getInstance().getProperty(Constants.OTP_EXPIRED_MESSAGE);
			}
			logger.error(errorMessage, e);
			ActionContext.getContext().put(ERROR_MESSAGE, errorMessage);
			return ERROR;
		}
	}

	public String getUseralias() {
		return useralias;
	}

	public void setUseralias(String useralias) {
		this.useralias = useralias;
	}


	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public CommonAuthScopedModel getModel() {
		return commonAuthModel;
	}

	@Override
	public String getScopeKey() {
		return scopedKey;
	}

	@Override
	public void setModel(CommonAuthScopedModel commonAuthModel) {
		this.commonAuthModel = commonAuthModel;
	}

	@Override
	public void setScopeKey(String scopedKey) {
		this.scopedKey = scopedKey;
	}

	public String getActionUrl() {
		return actionUrl;
	}

	public void setActionUrl(String actionUrl) {
		this.actionUrl = actionUrl;
	}

	public String getForgotOpType() {
		return forgotOpType;
	}

	public void setForgotOpType(String forgotOpType) {
		this.forgotOpType = forgotOpType;
	}
}
