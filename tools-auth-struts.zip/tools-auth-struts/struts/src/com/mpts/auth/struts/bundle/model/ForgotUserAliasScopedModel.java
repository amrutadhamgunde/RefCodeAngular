package com.mpts.auth.struts.bundle.model;

import java.util.Map;

public class ForgotUserAliasScopedModel extends CommonAuthScopedModel {

	private static final long serialVersionUID = 1L;

	private String emailId;
	private String mobileNumber;
	private Map<String, String> userMap;

	public String getUserAlias(String emailId, String mobileNumber, String institutionCode) {
		if (this.emailId.equals(emailId) && this.mobileNumber.equals(mobileNumber)) {
			return userMap.get(institutionCode);
		}
		return null;
	}

	public void setUserDetails(Map<String, String> userMap,String emailId, String mobileNumber) {
		this.userMap = userMap;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
	}
}
