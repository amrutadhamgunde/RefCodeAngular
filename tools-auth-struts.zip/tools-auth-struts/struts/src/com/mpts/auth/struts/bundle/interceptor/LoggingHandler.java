package com.mpts.auth.struts.bundle.interceptor;
import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.log4j.Logger;

public class LoggingHandler implements SOAPHandler<SOAPMessageContext> {

    private static final Logger LOGGER = Logger.getLogger(LoggingHandler.class);
    

    @Override
    public boolean handleMessage(final SOAPMessageContext context) {
    	LOGGER.info("***In handle message");
        logMessage(context.getMessage());
        return true;
    }

    @Override
    public boolean handleFault(final SOAPMessageContext context) {
        logMessage(context.getMessage());
        return true;
    }

    private void logMessage(final SOAPMessage msg) {
        try {
            // Write the message to the output stream
            final ByteArrayOutputStream baos = new ByteArrayOutputStream();
            msg.writeTo(baos);
            LOGGER.info("-------------------");
            LOGGER.info(baos.toString());
            LOGGER.info("-------------------");
            baos.close();
        } catch (final Exception e) {
            LOGGER.error("Caught exception: " + e.getMessage(), e);
        }
    }

    @Override
    public void close(final MessageContext context) {
        // Not required for logging
    }

    @Override
    public Set<QName> getHeaders() {
        // Not required for logging
        return new HashSet<>();
    }

}