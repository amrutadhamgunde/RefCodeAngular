package com.mpts.auth.struts.bundle.model;

public enum Errors {
	
	CERT_LOGIN(Constants.CERT_LOGIN, "Login need a client certificate for authentication."), 
	CERT_STEPUP_HTTP(Constants.CERT_STEPUP_HTTP, "HTTPS certificate authentication required."),
	EAI_AUTH_ERROR(Constants.EAI_AUTH_ERROR, "External authentication interface information is invalid."),
	FAILED_CERT(Constants.FAILED_CERT, "An attempt to authenticate with a client certificate failed."),
	LOGIN_SUCCESS(Constants.LOGIN_SUCCESS, "User successfully authenticated, but there is no last cached URL to redirect to."),
	PASSWD_WARN(Constants.PASS_WARN, "Password is soon to expire"),
	PASSWD_WARN_FAILURE(Constants.PASS_WARN_FAILURE, "Password change not performed after notification that the password is soon to expire."),
	STEPUP(Constants.STEPUP, "User must step-up to another authentication level."),
	SWITCH_USER(Constants.SWITCH_USER, "User requested the switch user login page."),
	TOO_MANY_SESSIONS(Constants.TOO_MANY_SESSIONS, "User has reached or exceeded the maximum number of allowed sessions.");

	private final String opcode;
	private final String message;

	private Errors(String opcode, String message) {
		this.opcode = opcode;
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public String getCode() {
		return opcode;
	}

	@Override
	public String toString() {
		return message;
	}
	
	public static String getErrorMessage(String opcode) {
		return Enum.valueOf(Errors.class, opcode.toUpperCase()).getMessage();
	}
}
