package com.mpts.auth.struts.bundle.exception;

public class AuthException extends Exception {
	private static final long serialVersionUID = 1L;

	private final String error;

	public AuthException(String error) {
		super(error);
		this.error = error;
	}

	public AuthException(Throwable t) {
		super(t);
		this.error = t.getMessage();
	}

	public String getError() {
		return error;
	}
}
