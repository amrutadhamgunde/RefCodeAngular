package com.mpts.auth.struts.bundle.api;

import java.io.ByteArrayInputStream;
import java.net.URI;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.mastercard.security.MasterCardJSSESocketFactory;
import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.IdentityMgmtServiceProvider;
import com.mpts.auth.struts.bundle.exception.AMISOperationFailedException;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.Utility;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.LoggingFilter;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

public class AMISAccessProvider {
	private static final String DEFAULT_PIN = "1221"; // NLS
	private static final String CHARSET_UTF8 = "utf-8"; // NLS
	
	private static final String USER_SEARCH_XML = "user_search.xml";
	private static final String SERVICE_RESULT = "/serviceResult/@result";
	private static final String SERVICE_RESULT_ERROR = "/serviceResult/@errorMessage";
	private static final String SERVICE_RESULT_COUNT = "/serviceResult/UserSearchResults/@Count";
	private static final String ERROR_MSG_USR_NOT_EXIST = "User does not exist in RSA.";
	
	private static String defaultPin;
	
	private static String amisUrl;
	private static String am3aUser;
	private static String identityToken;
	
	private static Client client = null;
	
	private AMISAccessProvider() {
	}
	
	private static void initializeClient() {
		ClientConfig config = new DefaultClientConfig();
		
		if (amisUrl.startsWith("https")) {
			SSLSocketFactory sslSocketFactory = IdentityMgmtServiceProvider.getSocketFactory();
			if (sslSocketFactory instanceof MasterCardJSSESocketFactory) {
				MasterCardJSSESocketFactory mcJSSESocketFactory = (MasterCardJSSESocketFactory) sslSocketFactory;
				SSLContext sslContext = mcJSSESocketFactory.getSecurityContext();
				config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
						new HTTPSProperties(Utility.getHostNameVerifier(), sslContext));
			}
		}
		client = Client.create(config);
	}

	public static void enableLogging() {
		if(client == null) {
			initializeClient();
			LoggingFilter loggingFilter = new LoggingFilter();
			client.addFilter(loggingFilter);
		}
	}

	public static Builder getBuilder(String apiPath) throws AMISOperationFailedException {
		String url = getFormattedURL(amisUrl, apiPath);
		if(client == null) {
			initializeClient();
		}
		WebResource resource = client.resource(url);
		Builder builder = resource.getRequestBuilder();
		if(am3aUser != null) {
			builder.header("am3a_user", am3aUser);
		}
		if(identityToken != null) {
			builder.header("identity_token", identityToken);
		}
		builder.type(MediaType.APPLICATION_XML);
		builder.accept(MediaType.APPLICATION_XML);
		return builder;
	}

	public static String getFormattedURL(String baseURL, String path) throws AMISOperationFailedException {
		try {
			String baseURL1 = baseURL;
			if (baseURL.endsWith("/")) {
				baseURL1 = baseURL.substring(0, baseURL.length() - 1);
			}
			String finalPath = baseURL1 + path;
			URI uri = new URI(finalPath);
			return uri.toURL().toString();
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	public static String getDefaultPin() {
		if (defaultPin == null) {
			defaultPin = CommonAuthService.getInstance().getProperty(Constants.AMIS_DEFAULT_PIN, DEFAULT_PIN);
		}
		return defaultPin;
	}

	public static DocumentBuilder getDocumentBuilder() throws AMISOperationFailedException {
		try {
			return DocumentBuilderFactory.newInstance().newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static XPath getXPath() {
		return XPathFactory.newInstance().newXPath();
	}
	
	public static String search(boolean deepSearch, String tamUserId) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream(USER_SEARCH_XML));
			body = body.replace(Constants.AMIS_USER_ID, tamUserId);
			return getBuilder(deepSearch ? "/user/dsearch" : "/user/search").post(String.class, body);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	public static boolean isUserLocked(String tamUserId) throws AMISOperationFailedException {
		return getUserStatus(tamUserId, UserStatus.LOCK);
	}
	
	private static boolean getUserStatus(String tamUserId, UserStatus status) throws AMISOperationFailedException {
		try {
			String response = search(false, tamUserId);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			
			String expression = SERVICE_RESULT_COUNT;
			String count = getXPath().compile(expression).evaluate(doc);
			if (Integer.valueOf(count) == 0) {
				throw new AMISOperationFailedException(ERROR_MSG_USR_NOT_EXIST);
			}
			expression = "/serviceResult/UserSearchResults/Item/"
					+ (status == UserStatus.LOCK ? "isLocked" : "isEnabled");
			String result = getXPath().compile(expression).evaluate(doc);
			
			return Boolean.valueOf(result);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	/*
	 * 0 - not locked, enabled
	 * 1 - not enabled
	 * 2 - locked
	 */
	public static int isUserValid(String tamUserId) throws AMISOperationFailedException {
		try {
			boolean isEnabled = getUserStatus(tamUserId, UserStatus.ENABLE);
			if(Boolean.valueOf(isEnabled)) {
				boolean isLocked = getUserStatus(tamUserId, UserStatus.LOCK);
				return Boolean.valueOf(isLocked) ? 2 : 0;  
			}
			return 1;
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	public static boolean isUserEnabled(String tamUserId) throws AMISOperationFailedException {
		return getUserStatus(tamUserId, UserStatus.ENABLE);
	}
	
	public static String tokenTokenSrNo(String tamUserId) throws AMISOperationFailedException {
		try {
			String response = search(true, tamUserId);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			String expression = "/serviceResult/DeepUserSearchResults/Item/tokens/@serialNumber";
			return getXPath().compile(expression).evaluate(doc);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static boolean createUser(String tamUserId, String userName, String emailAddress, boolean enabled) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream("user_create.xml"));
			body = body.replace(Constants.AMIS_USER_ID, tamUserId).replace(Constants.AMIS_EMAIL_ADDRESS, emailAddress)
					.replace(Constants.AMIS_FIRST_NAME, userName).replace(Constants.AMIS_LAST_NAME, userName)
					.replace(Constants.AMIS_USER_ENABLED, String.valueOf(enabled));
			String response = getBuilder("/user/create_S").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			return getResult(doc);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static boolean enableUser(String tamUserId) throws AMISOperationFailedException {
		return updateUserStatus(true, tamUserId);
	}

	public static boolean disableUser(String tamUserId) throws AMISOperationFailedException {
		return updateUserStatus(false, tamUserId);
	}

	private static boolean updateUserStatus(boolean enable, String tamUserId) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream(USER_SEARCH_XML));
			body = body.replace(Constants.AMIS_USER_ID, tamUserId);
			String response = getBuilder(enable ? "/user/enable" : "/user/disable").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			String expression = "/serviceResult/@value";
			String value = getXPath().compile(expression).evaluate(doc);
			return "1".equals(value);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static String assignTokenSerialNumber(String tamUserId) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream("user_assigntoken.xml"));
			body = body.replace(Constants.AMIS_USER_ID, tamUserId);
			String response = getBuilder("/user/assignNext_S/software").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			String expression = SERVICE_RESULT;
			String result = getXPath().compile(expression).evaluate(doc);
			if (Boolean.valueOf(result)) {
				expression = "/serviceResult/TokenSerialNumber";
				return getXPath().compile(expression).evaluate(doc);
			} else {
				expression = SERVICE_RESULT_ERROR;
				String error = getXPath().compile(expression).evaluate(doc);
				throw new AMISOperationFailedException(error);
			}
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	public static String getSoftToken(String tokenSerialNo, String deviceType) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream("token_updateSerialNo.xml"));
			body = body.replace(Constants.AMIS_TOKEN_SERIAL_NO, tokenSerialNo).replace(Constants.AMIS_DEVICE_TYPE,
					deviceType);
			String response = getBuilder("/token/update_S").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			String expression = SERVICE_RESULT;
			String result = getXPath().compile(expression).evaluate(doc);
			if (Boolean.valueOf(result)) {
				expression = "/serviceResult/distributionResult";
				String encodedValue = getXPath().compile(expression).evaluate(doc);
				return new String(Base64.decodeBase64(encodedValue));
			} else {
				expression = SERVICE_RESULT_ERROR;
				String error = getXPath().compile(expression).evaluate(doc);
				throw new AMISOperationFailedException(error);
			}
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static boolean setNewPINMode(String tokenSerialNo) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream("token_clear_newpin.xml"));
			body = body.replace(Constants.AMIS_TOKEN_SERIAL_NO, tokenSerialNo);
			String response = getBuilder("/token/newpin").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			return getResult(doc);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static boolean setPIN(String serialNo) throws AMISOperationFailedException {
		return setPIN(serialNo, DEFAULT_PIN);
	}
	
	public static boolean setPIN(String serialNo, String pin) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream("token_setpin.xml"));
			body = body.replace(Constants.AMIS_TOKEN_SERIAL_NO, serialNo).replace(Constants.AMIS_PIN, pin);
			String response = getBuilder("/token/setpin").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			return getResult(doc);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}

	public static void setAmisUrl(String amisUrl) {
		AMISAccessProvider.amisUrl = amisUrl;
	}

	public static void setAm3aUser(String am3aUser) {
		AMISAccessProvider.am3aUser = am3aUser;
	}

	public static void setIdentityToken(String identityToken) {
		AMISAccessProvider.identityToken = identityToken;
	}

	public static boolean unlock(String tamUserId) throws AMISOperationFailedException {
		try { 
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream(USER_SEARCH_XML));
			body = body.replace(Constants.AMIS_USER_ID, tamUserId);
			String response = getBuilder("/user/unlock").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			return getResult(doc);
		} catch(Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	public static boolean deleteUser(String tamUserId) throws AMISOperationFailedException {
		try {
			String body = IOUtils.toString(AMISAccessProvider.class.getResourceAsStream("user_assigntoken.xml"));
			body = body.replace(Constants.AMIS_USER_ID, tamUserId);
			String response = getBuilder("/user/delete_S").post(String.class, body);
			Document doc = getDocumentBuilder()
					.parse(new InputSource(new ByteArrayInputStream(response.getBytes(CHARSET_UTF8))));
			return getResult(doc);
		} catch (Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
	
	private static boolean getResult(Document doc) throws AMISOperationFailedException {
		try {
			String expression = SERVICE_RESULT;
			String result = getXPath().compile(expression).evaluate(doc);
			if (Boolean.valueOf(result)) {
				return true;
			} else {
				expression = SERVICE_RESULT_ERROR;
				String error = getXPath().compile(expression).evaluate(doc);
				throw new AMISOperationFailedException(error);
			}
		} catch(Exception e) {
			throw new AMISOperationFailedException(e);
		}
	}
}