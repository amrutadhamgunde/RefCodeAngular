package com.mpts.auth.struts.bundle.pages.openid;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.util.Utility;
import com.nimbusds.oauth2.sdk.AuthorizationRequest;
import com.nimbusds.oauth2.sdk.ResponseType;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.SerializeException;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.id.State;
import com.nimbusds.openid.connect.sdk.Nonce;
import com.nimbusds.openid.connect.sdk.OIDCResponseTypeValue;
import com.opensymphony.xwork2.ActionSupport;

public class Login extends ActionSupport {

	private static final long serialVersionUID = 1306894822257381193L;
	
	private static final Logger logger = Logger.getLogger(Login.class);

	private String url;

	@Override
	public String execute() {

		// The authorisation endpoint of the server
		URI authzEndpoint = null;
		try {
			authzEndpoint = new URI(CommonAuthService.getInstance().getProperty(Constants.AUTHORIZATION_ENDPOINT_URL));
		} catch (URISyntaxException e) {
			logger.error(Utility.getStackTrace(e));
		}

		// The client identifier provisioned by the server
		ClientID clientID = new ClientID(CommonAuthService.getInstance().getProperty(Constants.CLIENT_ID));

		// The requested scope values for the token
		String scopes = CommonAuthService.getInstance().getProperty(Constants.SCOPE);
		if (scopes == null || "".equals(scopes)) {
			scopes = Constants.OPEN_ID;
		}
		List<String> scopeList = Arrays.asList(scopes);
		if (!scopeList.contains(Constants.OPEN_ID)) {
			scopeList.add(Constants.OPEN_ID);
		}
		Scope scope = new Scope(scopeList.toArray(new String[scopeList.size()]));

		// The client callback URI, typically pre-registered with the server
		URI callback = null;
		try {
			callback = new URI(CommonAuthService.getInstance().getProperty(Constants.REDIRECT_URL));
		} catch (URISyntaxException e) {
			logger.error(Utility.getStackTrace(e));
		}

		// Generate random state string for pairing the response to the request
		State state = new State();

		ResponseType responseType = new ResponseType();
		responseType.add(OIDCResponseTypeValue.ID_TOKEN);

		AuthorizationRequest request = new AuthorizationRequest.Builder(responseType, clientID).scope(scope)
				.state(state).redirectionURI(callback).endpointURI(authzEndpoint).build();
		URI requestURI = null;
		try {
			requestURI = request.toURI();

			url = requestURI.toString();
			String responseMode = CommonAuthService.getInstance().getProperty(Constants.RESPONSE_MODE);
			if (responseMode == null || "".equals(responseMode)) {
				responseMode = "form_post";
			}
			url += "&" + Constants.RESPONSE_MODE_KEY + "=" + responseMode;
			Nonce nonce = new Nonce();
			url += "&" + Constants.NONCE_KEY + "=" + nonce.getValue();
			return "redirect";
		} catch (SerializeException e) {
			logger.error(Utility.getStackTrace(e));
		}
		return ERROR;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
