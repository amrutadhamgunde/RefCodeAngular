package com.mpts.auth.struts.bundle.exception;

public class AMISOperationFailedException extends TAMException {

	private static final long serialVersionUID = 1L;

	public AMISOperationFailedException(String error) {
		super(error);
	}

	public AMISOperationFailedException(Throwable e) {
		super(e);
	}
}
