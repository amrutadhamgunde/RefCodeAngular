package com.mpts.auth.struts.bundle.exception;

public class UserNotAuthorizedException extends AuthException {

	private static final long serialVersionUID = -460713329426802038L;

	public UserNotAuthorizedException() {
		this(null);
	}

	public UserNotAuthorizedException(String error) {
		super(error);
	}
}
