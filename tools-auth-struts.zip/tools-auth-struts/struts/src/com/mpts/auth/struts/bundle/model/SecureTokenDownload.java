package com.mpts.auth.struts.bundle.model;

import java.io.Serializable;
import java.util.List;

public class SecureTokenDownload implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String tamUserId;
	private List<String> dbSecurityQuestions;
	private boolean isFirstTimeDownload;
	
	public String getTamUserId() {
		return tamUserId;
	}
	public void setTamUserId(String tamUserId) {
		this.tamUserId = tamUserId;
	}
	public List<String> getDbSecurityQuestions() {
		return dbSecurityQuestions;
	}
	public void setDbSecurityQuestions(List<String> dbSecurityQuestions) {
		this.dbSecurityQuestions = dbSecurityQuestions;
	}
	public boolean isFirstTimeDownload() {
		return isFirstTimeDownload;
	}
	public void setFirstTimeDownload(boolean isFirstTimeDownload) {
		this.isFirstTimeDownload = isFirstTimeDownload;
	}
	
	
}
