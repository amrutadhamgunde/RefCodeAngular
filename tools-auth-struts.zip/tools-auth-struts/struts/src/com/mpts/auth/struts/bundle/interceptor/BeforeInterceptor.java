package com.mpts.auth.struts.bundle.interceptor;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.LangLocale;
import com.mpts.auth.struts.bundle.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class BeforeInterceptor implements Interceptor {

	private static final long serialVersionUID = -9156726098906815843L;
	private static final Logger logger = Logger.getLogger(BeforeInterceptor.class);

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		String[] selectLanguage = (String[]) ActionContext.getContext().getParameters().get(Constants.SELECT_LANGUAGE);
		
		LangLocale langLocale;
		if(selectLanguage != null && selectLanguage.length > 0){
			langLocale = CommonAuthService.getInstance().getLanguages().get(selectLanguage[0]);
			ActionContext.getContext().getSession().put(Constants.LOCALE, langLocale);
		} else {
			langLocale = (LangLocale) ActionContext.getContext().getSession().get(Constants.LOCALE);
		}
		
		if (langLocale == null) {
			// set the default locale
			langLocale = new LangLocale(Locale.ENGLISH.getLanguage(), "English");
			ActionContext.getContext().getSession().put(Constants.LOCALE, langLocale);
		}
		ActionContext.getContext().setLocale(new Locale(langLocale.getLocale()));
		
		String result = invocation.invoke();

		try {
			HttpServletRequest request = ServletActionContext.getRequest();
			request.getSession(false);
			
			String actionName = ActionContext.getContext().getName();
			ActionContext.getContext().getSession().put(Constants.RESULT + "_" + actionName, result);
		} catch(IllegalStateException e){
			logger.debug(Utility.getStackTrace(e));
		}
		
		return result;
	}

	@Override
	public void destroy() {
		// no need to implement
	}

	@Override
	public void init() {
		// no need to implement
	}

}
