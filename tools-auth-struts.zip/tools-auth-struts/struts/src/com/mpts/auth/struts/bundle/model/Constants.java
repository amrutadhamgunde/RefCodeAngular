package com.mpts.auth.struts.bundle.model;

public final class Constants {

	/**
	 * Generic Constants
	 */
	public static final String IDENTITY_PROVIDER = "IDENTITY_PROVIDER";
	public static final String TAM = "TAM";
	public static final String OPENID = "OpenID";
	public static final String HEADER_LAYOUT = "HEADER_LAYOUT";
	public static final String FOOTER_LAYOUT = "FOOTER_LAYOUT";
	public static final String BROWSER_MSG = "BROWSER_MSG";
	public static final String SOCKET_FACTORY_TYPE = "SOCKET_FACTORY_TYPE";
	public static final String INTERNAL = "INTERNAL";
	public static final String LOCALE = "request_locale";
	public static final String LANGUAGE = "language";
	public static final String LANGUAGE_MAP = "langMap";
	public static final String RESULT = "result";
	public static final String FORGOT_OP_PASS = "password";
	public static final String FORGOT_OP_PIN = "pin";
	public static final String FORGOT_OP_UNLOCK = "unlock";
	public static final String FORGOT_OP_USERALIAS = "useralias";
	public static final String FORGOT_OP_TOKEN = "token";
	public static final String SELECT_LANGUAGE = "selectLanguage";
	
	// Label keys for Multilingual support
	public static final String LABEL_PAGE_TITLE = "auth.common.page.title";

	/**
	 * TAM Constants
	 */
	public static final String PUBLIC_ENDPPOINT_URL = "PUBLIC_ENDPPOINT_URL";
	public static final String SYSTEM_ENDPPOINT_URL = "SYSTEM_ENDPPOINT_URL";
	public static final String CSR_ENDPPOINT_URL = "CSR_ENDPPOINT_URL";
	public static final String PRIVATE_ENDPPOINT_URL = "PRIVATE_ENDPPOINT_URL";
	public static final String ESB_SECURITY_DOMAIN = "ESB_SECURITY_DOMAIN";
	public static final String TYPE_OF_USER = "TYPE_OF_USER";
	public static final String B2B = "B2B";
	public static final String B2C = "B2C";
	public static final String PUBLIC_CALL = "Public";
	public static final String PRIVATE_CALL = "Private";
	public static final String SYSTEM_CALL = "System";
	public static final String TAM_OPCODE = "TAM_OP";
	public static final String PASS = "pwd";
	public static final String TOKEN = "token";
	public static final String URL_PREFIX = "URL_PREFIX";
	public static final String APPLICATION_ID = "APPLICATION_ID";
	public static final String ROLE_NAME = "ROLE_NAME";
	public static final String ISSUER_ID = "ISSUER_ID";
	public static final String CORP_ID = "CORP_ID";
	public static final String ISSUER_GROUP_ID = "ISSUER_GROUP_ID";
	public static final String COMPANY_GROUP_ID = "COMPANY_GROUP_ID";
	public static final String SUSPEND = "SUSPEND";
	public static final String ACTIVE = "ACTIVATE";
	public static final String MOBILE_NO = "MOBILE_NO";
	public static final String EMAIL_ID = "EMAIL_ID";
	public static final String MAX_NO_ATTEMPTS = "MAX_NO_ATTEMPTS";
	public static final String PIN_CHANGE_SUCCESS = "pin-change-success";
	public static final String SEC_QUEST_NOT_EXISTS = "SEC_QUEST_NOT_EXISTS";
	public static final String USER_NOT_LOCKED = "USER_NOT_LOCKED";


	/**
	 * Constants for TAM Opcodes
	 */
	public static final String TOKEN_LOGIN = "token_login";
	public static final String LOGIN = "login";
	public static final String NEXT_TOKEN = "next_token";
	public static final String PASS_CHG_REQ_SUCCESS = "passwd_rep_success";
	public static final String ACCOUNT_LOCKED = "acct_locked";
	public static final String ACCOUNT_INACTIVATED = "acct_inactivated";
	public static final String FORGOT_PASS = "passwd";
	public static final String PASS_EXPIRED = "passwd_exp";
	public static final String PASS_CHG_REQ_FAILED = "passwd_rep_failure";
	public static final String LOGOUT = "logout";
	public static final String ERROR = "error";
	public static final String CERT_LOGIN = "cert_login";
	public static final String CERT_STEPUP_HTTP = "cert_stepup_http";
	public static final String EAI_AUTH_ERROR = "eai_auth_error";
	public static final String LOGIN_SUCCESS = "login_success";
	public static final String FAILED_CERT = "failed_cert";
	public static final String PASS_WARN = "passwd_warn";
	public static final String PASS_WARN_FAILURE = "passwd_warn_failure";
	public static final String STEPUP = "stepup";
	public static final String SWITCH_USER = "switch_user";
	public static final String TOO_MANY_SESSIONS = "too_many_sessions";
	public static final String HELP = "help";

	/**
	 * OpenID Constants
	 */
	public static final String AUTHORIZATION_ENDPOINT_URL = "AUTHORIZATION_ENDPOINT_URL";
	public static final String API_URL = "API_URL";
	public static final String CLIENT_ID = "CLIENT_ID";
	public static final String SCOPE = "SCOPE";
	public static final String REDIRECT_URL = "REDIRECT_URL";
	public static final String RESPONSE_MODE = "RESPONSE_MODE";
	public static final String RESPONSE_MODE_KEY = "response_mode";
	public static final String NONCE_KEY = "nonce";
	public static final String ID_TOKEN = "id_token";
	public static final String RSA = "RSA";
	public static final String ISSUER = "ISSUER";
	public static final String OPEN_ID = "openid";

	/**
	 * Display messages text
	 */
	public static final String USER_NOT_AUTHORIZED = "USER_NOT_AUTHORIZED";
	public static final String ACCOUNT_LOCKED_MESSAGE = "ACCOUNT_LOCKED";
	public static final String USER_NOT_EXISTS_MESSAGE = "USER_NOT_EXISTS";
	public static final String USER_NOT_REGISTERED = "USER_NOT_REGISTERED";
	public static final String OTP_EXPIRED_MESSAGE = "OTP_EXPIRED";
	public static final String OTP_VERIFY_SUCCESSFUL = "OTP_VERIFY_SUCCESSFUL";
	public static final String USER_UNLOCK_SUCCESSFUL = "USER_UNLOCK_SUCCESSFUL";
	public static final String MAX_ATTEMPTS = "MAX_ATTEMPTS";
	public static final String TOKEN_NOT_AVAILABLE = "TOKEN_NOT_AVAILABLE";
	public static final String INVALID_CREDENTIALS = "INVALID_CREDENTIALS";
	public static final String INTERNAL_ERROR = "INTERNAL_ERROR";
	public static final String INVALID_OTP = "INVALID_OTP";
	public static final String INVALID_SECURITY_QUESTIONS = "INVALID_SECURITY_QUESTIONS";
	public static final String INVALID_USER_ALIAS = "INVALID_USER_ALIAS";
	public static final String INVALID_USER_NAME = "INVALID_USER_NAME";
	public static final String INVALID_EMAIL_MOBILENO = "INVALID_EMAIL_MOBILENO";
	public static final String LOGGED_OFF = "LOGGED_OFF";
	public static final String USER_SUSPENDED = "USER_SUSPENDED";
	public static final String AUTH_FAILED = "AUTH_FAILED";
	public static final String PAWD_EXPIRED = "PASSWORD_EXPIRED";
	public static final String PIN_EXPIRED = "PIN_EXPIRED";


	/**
	 * Placeholder constants
	 */
	public static final String NO_OF_ATTEMPTS = "$noOfAttempts";
	public static final String MOBILE = "$mobileNo";
	public static final String EMAIL = "$emailId";

	/**
	 * TAM opcode text
	 */
	public static final String TAM_ERROR = "TAM_ERROR";
	public static final String TAM_CERT_LOGIN = "TAM_CERT_LOGIN";
	public static final String TAM_CERT_STEPUP_HTTP = "TAM_CERT_STEPUP_HTTP";
	public static final String TAM_EAI_AUTH_ERROR = "TAM_EAI_AUTH_ERROR";
	public static final String TAM_FAILED_CERT = "TAM_FAILED_CERT";
	public static final String TAM_PASS_WARN = "TAM_PASSWD_WARN";
	public static final String TAM_PASS_WARN_FAILURE = "TAM_PASSWD_WARN_FAILURE";
	public static final String TAM_STEPUP = "TAM_STEPUP";
	public static final String TAM_SWITCH_USER = "TAM_SWITCH_USER";
	public static final String TAM_TOO_MANY_SESSIONS = "TAM_TOO_MANY_SESSIONS";

	/**
	 * AMIS API
	 */
	public static final String AMIS_ENABLE = "AMIS_ENABLE";
	public static final String AMIS_API_URL = "AMIS_API_URL";
	public static final String AMIS_AM3A_USER = "AM3A_USER";
	public static final String AMIS_IDENTITY_TOKEN = "AMIS_IDENTITY_TOKEN";
	public static final String AMIS_TOKEN_DEVICE_TYPE = "AMIS_TOKEN_DEVICE_TYPE";
	public static final String AMIS_DEFAULT_PIN = "AMIS_DEFAULT_PIN";

	/**
	 * AMIS place holders
	 */
	public static final String AMIS_PIN = "$pin";
	public static final String AMIS_USER_ID = "$userId";
	public static final String AMIS_EMAIL_ADDRESS = "$emailAddress";
	public static final String AMIS_FIRST_NAME = "$firstName";
	public static final String AMIS_LAST_NAME = "$lastName";
	public static final String AMIS_DEVICE_TYPE = "$deviceType";
	public static final String AMIS_TOKEN_SERIAL_NO = "$tokenSerialNo";
	public static final String AMIS_USER_ENABLED = "$enabled";
	
	public static final String URL = "URL";
	public static final String JUNCTION = "JUNCTION";
	public static final String APP = "APP";

	public static final String LOGOUTJUNCTION = "LOGOUTJUNCTION";
	public static final String LOGOUTAPP = "LOGOUTAPP";

	public static final String SUCCESSFUL_LOGIN_ACTION = "SUCCESSFUL_LOGIN_ACTION";
	public static final String USERNAME = "USERNAME";
	public static final String REGISTER_ACTION="REGISTER_ACTION";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String ENABLE_SOAP_MSG = "ENABLE_SOAP_MESSAGE"; 
	
	private Constants() {
	}
}
