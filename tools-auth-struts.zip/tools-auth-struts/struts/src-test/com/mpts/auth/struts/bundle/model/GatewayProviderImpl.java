package com.mpts.auth.struts.bundle.model;

import java.util.Map;

import org.apache.log4j.Logger;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.exception.GatewayException;

public class GatewayProviderImpl implements IGatewayProvider {
	
	private static final Logger LOGGER = Logger.getLogger(GatewayProviderImpl.class);

	@Override
	public void sendOTPForgotPassword(String userAlias, String password) {
		sendOneTimePassword(userAlias, password);
	}

	@Override
	public void sendOTPForgotToken(String userAlias, String password) {
		sendOneTimePassword(userAlias, password);
	}

	@Override
	public void sendOTPForgotUserAlias(String userAlias, String password) {
		sendOneTimePassword(userAlias, password);
	}

	@Override
	public void sendTempPasswordCreateUser(String userAlias, String tempPassword) {
		sendTempPassword(userAlias, tempPassword);
	}

	@Override
	public void sendTempPasswordForgotPassword(String userAlias, String tempPassword) {
		sendTempPassword(userAlias, tempPassword);
		
	}

	@Override
	public void sendTempPasswordResetPassword(String userAlias, String tempPassword) {
		sendTempPassword(userAlias, tempPassword);
		
	}

	@Override
	public void sendUserAlias(String userAlias) {
	}
	
	@Override
	public void sendPIN(String userAlias, String pin) {
		sendTempPIN(userAlias, pin);
	}

	@Override
	public void sendTempPINForgotPIN(String userAlias, String tempPIN) {
		sendTempPIN(userAlias, tempPIN);
		
	}
	
	@Override
	public void sendOTPForgotPIN(String userAlias, String otp) {
		sendOneTimePassword(userAlias, otp);
	}

	@Override
	public void sendOTPUnlockUser(String userAlias, String otp) {
		sendOneTimePassword(userAlias, otp);
	}

	@Override
	public void sendTempPINResetPIN(String userAlias, String tempPIN) {
		sendTempPIN(userAlias, tempPIN);
		
	}
	
	private void sendOneTimePassword(String userAlias, String password) {
		System.out.println("GatewayProviderImpl.sendOneTimePassword()");
		LOGGER.info("Generated OTP: " + password);
		
		sendPassword(userAlias,password);
	}
	
	private void sendTempPassword(String userAlias, String tempPassword) {
		System.out.println("GatewayProviderImpl.sendTempPassword()");
		LOGGER.info("Temporary Password: " + tempPassword);
		
		sendPassword(userAlias,tempPassword);
	}
	
	private void sendTempPIN(String userAlias, String tempPIN) {
		System.out.println("GatewayProviderImpl.sendTempPIN()");
		LOGGER.info("Temporary PIN: " + tempPIN);
		
		sendPassword(userAlias,tempPIN);
	}
	
	private void sendPassword(String userAlias, String tempPIN) {
		
		Map<String, String> values = getUserContacts(userAlias);
		
		if (values != null) {
			//String emailID = values.get(Constants.EMAIL_ID);
			
		}
	}
	
	private Map<String, String> getUserContacts(String userAlias){
		Map<String, String> values = null;
		try {
			values = CommonAuthService.getInstance().getDaoProvider().getUserContacts(userAlias);
		} catch (Exception e) {
		}
		return values;
	}
	
	@Override
	public void notifyUnlockUser(String userAlias, boolean unlockedByAdmin) throws GatewayException {

		LOGGER.info("User '" + userAlias + "' unlocked successfully" + (unlockedByAdmin ? " [Admin]" : ""));
	}

	@Override
	public void notifyChangePin(String userAlias) throws GatewayException {
		LOGGER.info("User '" + userAlias + "' has changed pin successfully");
		
	}
}
