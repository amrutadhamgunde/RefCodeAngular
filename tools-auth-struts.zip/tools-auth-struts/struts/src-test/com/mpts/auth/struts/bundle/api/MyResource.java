package com.mpts.auth.struts.bundle.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;

@Path("/")
public class MyResource {
	@POST
	@Path("/user/dsearch")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String deepSearch(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("user_deepsearch_result.xml"));
	}

	@POST
	@Path("/user/search")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String userSearch(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("user_search_result.xml"));
	}
	
	@POST
	@Path("/user/unlock")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String userUnlock(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("result_success.xml"));
	}
	
	@POST
	@Path("/user/enable")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String userEnable(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("result_success.xml"));
	}
	
	@POST
	@Path("/user/disable")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String userDisable(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("result_success.xml"));
	}
	
	@POST
	@Path("/token/newpin")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String newPIN(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("result_success.xml"));
	}
	
	@POST
	@Path("/token/setpin")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String setPIN(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("result_success.xml"));
	}
	
	@POST
	@Path("/token/update_S")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String updateS(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("soft_token.xml"));
	}
	
	@POST
	@Path("/user/create_S")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public String createS(String body) throws Exception {
		return IOUtils.toString(MyResource.class.getClassLoader().getResourceAsStream("result_success.xml"));
	}
	
}