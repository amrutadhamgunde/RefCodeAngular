package com.mpts.auth.struts.bundle.tam.testsuite;

import java.io.File;
import java.net.URL;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.exception.ConfigException;
import com.mpts.auth.struts.bundle.model.DaoProviderImpl;
import com.mpts.auth.struts.bundle.model.GatewayProviderImpl;
import com.mpts.auth.struts.bundle.tam.b2c.LoginRouterTest;

@RunWith(Suite.class)
@SuiteClasses({ LoginRouterTest.class })
public class B2CTestSuite {

	@BeforeClass
	public static void setUpClass() {
		CommonAuthService commonAuthService = CommonAuthService.getInstance();

		try {
			URL url = B2CTestSuite.class.getClassLoader().getResource("tamConfigB2C.properties");
			File file = new File(url.getFile());
			commonAuthService.intialize(file);
		} catch (ConfigException e) {
			e.printStackTrace();
		}

		commonAuthService.registerHomePage("loginrouter");
		commonAuthService.setDaoProvider(new DaoProviderImpl());
		commonAuthService.setGatewayProvider(new GatewayProviderImpl());

		commonAuthService.setLanguages(commonAuthService.getDaoProvider().getLanguages());
	}

	@AfterClass
	public static void tearDownClass() {
		
	}
}
