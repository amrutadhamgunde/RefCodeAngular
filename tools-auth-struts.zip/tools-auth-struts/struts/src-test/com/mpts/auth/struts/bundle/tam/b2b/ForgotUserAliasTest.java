package com.mpts.auth.struts.bundle.tam.b2b;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.apache.struts2.StrutsJUnit4TestCase;
import org.junit.Test;

import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.model.DaoProviderImpl;
import com.mpts.auth.struts.bundle.pages.tam.ForgotUserAlias;
import com.mpts.auth.struts.bundle.pages.tam.LoginRouter;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionProxy;

public class ForgotUserAliasTest extends StrutsJUnit4TestCase<LoginRouter> {

	@Test
	public void testInputMobEmailPage() throws Exception {
		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth/forgotUseralias");
		assertNotNull(proxy);
		Map<String, Object> sessionMap = new HashMap<String, Object>();
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);

		assertEquals(proxy.execute(), Action.SUCCESS);
	}
	
	@Test
	public void testShowSecQueVerificationLang() throws Exception {

		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth/forgotUseraliasgetUser");
		assertNotNull(proxy);

		Map<String, Object> sessionMap = new HashMap<String, Object>();
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);
		proxy.getInvocation().getInvocationContext().getParameters().put(Constants.SELECT_LANGUAGE, new String[] {"en"});

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);

		action.setMobileNumber("1234567890");
		action.setEmailId("csr1@mail.com");

		proxy.execute();
	}

	@Test
	public void testValidUserIdWithSecQue() throws Exception {
		Map<String, Object> sessionMap = new HashMap<String, Object>();

		ForgotUserAlias action = showSecQueVerification(sessionMap);
		
		String actionURI = "/mpts-csr/eaq/auth" + action.getActionUrl().replaceFirst(".", "");

		action = showOTPVerification(actionURI, sessionMap);

		actionURI = "/mpts-csr/eaq/auth" + action.getActionUrl().replaceFirst(".", "");

		ActionProxy proxy = getActionProxy(actionURI);
		assertNotNull(proxy);
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);

		action.setOneTimePassword(DaoProviderImpl.captureGeneratedOTP("csr1"));

		assertEquals(proxy.execute(), Action.SUCCESS);
	}

	private ForgotUserAlias showOTPVerification(String actionURI, Map<String, Object> sessionMap) throws Exception {
	
		ActionProxy proxy = getActionProxy(actionURI);
		assertNotNull(proxy);
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);

		action.setSecurityAnswer1("a1");
		action.setSecurityAnswer2("a2");

		assertEquals(proxy.execute(), Action.SUCCESS);
		
		proxy = getActionProxy(actionURI);
		assertNotNull(proxy);
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);
		proxy.getInvocation().getInvocationContext().getParameters().put(Constants.SELECT_LANGUAGE, new String[] {"en"});

		action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);
		
		action.setSecurityAnswer1("a1");
		action.setSecurityAnswer2("a2");

		assertEquals(proxy.execute(), Action.SUCCESS);
		return action;
	}

	@Test
	public void testValidUserIdWithoutSecQue() throws Exception {
		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth/forgotUseraliasgetUser");
		assertNotNull(proxy);
		Map<String, Object> sessionMap = new HashMap<String, Object>();
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		action.setMobileNumber("1234567890");
		action.setEmailId("csr2@mail.com");

		assertNotNull(action);

		assertEquals(proxy.execute(), Action.INPUT);
	}

	private ForgotUserAlias showSecQueVerification(Map<String, Object> sessionMap) throws Exception {
		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth/forgotUseraliasgetUser");
		assertNotNull(proxy);

		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);

		action.setMobileNumber("1234567890");
		action.setEmailId("csr1@mail.com");

		assertEquals(proxy.execute(), Action.SUCCESS);
		
		proxy = getActionProxy("/mpts-csr/eaq/auth/forgotUseraliasgetUser");
		assertNotNull(proxy);

		proxy.getInvocation().getInvocationContext().setSession(sessionMap);
		proxy.getInvocation().getInvocationContext().getParameters().put(Constants.SELECT_LANGUAGE, new String[] {"en"});

		action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);

		action.setMobileNumber("1234567890");
		action.setEmailId("csr1@mail.com");

		assertEquals(proxy.execute(), Action.SUCCESS);

		return action;
	}
	
	@Test
	public void testRetrySecQue() throws Exception {
		Map<String, Object> sessionMap = new HashMap<String, Object>();

		ForgotUserAlias action = showSecQueVerification(sessionMap);
		
		String actionURI = "/mpts-csr/eaq/auth" + action.getActionUrl().replaceFirst(".", "");

		ActionProxy proxy = retrySecQue(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.INPUT);
		proxy = retrySecQue(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.INPUT);
		proxy = retrySecQue(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.INPUT);
		
		// final retry to exceed retry count and disable user
		proxy = retrySecQue(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.ERROR);
	}

	private ActionProxy retrySecQue(String actionURI, Map<String, Object> sessionMap) throws Exception {
		ActionProxy proxy = getActionProxy(actionURI);
		assertNotNull(proxy);
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);
		
		action.setSecurityAnswer1("a1");
		action.setSecurityAnswer2("a1");
		
		return proxy;
	}
	
	@Test
	public void testRetryOTP() throws Exception {
		Map<String, Object> sessionMap = new HashMap<String, Object>();

		ForgotUserAlias action = showSecQueVerification(sessionMap);
		
		String actionURI = "/mpts-csr/eaq/auth" + action.getActionUrl().replaceFirst(".", "");

		action = showOTPVerification(actionURI, sessionMap);

		actionURI = "/mpts-csr/eaq/auth" + action.getActionUrl().replaceFirst(".", "");
		
		ActionProxy proxy = retryOTP(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.INPUT);

		proxy = retryOTP(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.INPUT);
		
		proxy = retryOTP(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.INPUT);
		
		// final retry to exceed retry count and disable user
		proxy = retryOTP(actionURI, sessionMap);
		assertEquals(proxy.execute(), Action.ERROR);
	}
	
	private ActionProxy retryOTP(String actionURI, Map<String, Object> sessionMap) throws Exception {
		ActionProxy proxy = getActionProxy(actionURI);
		assertNotNull(proxy);
		proxy.getInvocation().getInvocationContext().setSession(sessionMap);

		ForgotUserAlias action = (ForgotUserAlias) proxy.getAction();

		assertNotNull(action);
		
		action.setOneTimePassword("12345678");
		
		return proxy;
	}
	
	@Override
	protected String getConfigPath() {
		return "struts.xml";
	}
}
