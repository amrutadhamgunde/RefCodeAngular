package com.mpts.auth.struts.bundle.tam.b2b;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.apache.struts2.StrutsJUnit4TestCase;
import org.junit.Test;

import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.pages.tam.AppLogout;
import com.mpts.auth.struts.bundle.pages.tam.LoginFormSubmit;
import com.mpts.auth.struts.bundle.pages.tam.LoginRouter;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionProxy;

public class LoginRouterTest extends StrutsJUnit4TestCase<LoginRouter> {
	
	@Test
    public void testTokenLogin() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.TOKEN_LOGIN);
         
        String result = executeLoginRouterAction();
        assertEquals("tokenlogin", result);
    }
	
	@Test
    public void testNextToken() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.NEXT_TOKEN);
        request.setParameter("ERROR_CODE", "0x132120c8");
        request.setParameter("ERROR_TEXT", "Next Token Required!");
        request.setParameter("USERNAME", "tamcsr1");
        
        String result = executeLoginRouterAction();
        assertEquals("tokenlogin", result);
    }
	
	@Test
    public void testAccountLocked() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.ACCOUNT_LOCKED);
        request.setParameter("ERROR_CODE", "0x03000000");
        request.setParameter("ERROR_TEXT", "Account locked!");
        
        String result = executeLoginRouterAction();
        assertEquals("tokendownloadlogin", result);
    }
	
	@Test
    public void testLogin() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.LOGIN);
        request.setParameter("ERROR_CODE", "0x03000000");
        request.setParameter("ERROR_TEXT", "Login Required!");
        
        String result = executeLoginRouterAction();
        assertEquals("tokendownloadlogin", result);
    }
	
	@Test
    public void testPINExpired() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.PASS_EXPIRED);
        request.setParameter("ERROR_CODE", "0x03000000");
        request.setParameter("ERROR_TEXT", "password expired");
        
        String result = executeLoginRouterAction();
        assertEquals("pinchange", result);
    }
	
	@Test
    public void testLogout() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.LOGOUT);
        
        String result = executeLoginRouterAction();
        assertEquals("logout", result);
    }
	
	private String executeLoginRouterAction() throws Exception {
		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth");
        assertNotNull(proxy);
        Map<String, Object> sessionMap = new HashMap<String, Object>();
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        request.setParameter(Constants.URL, "https://dev.customer.portal.mpts.mastercard.int:25595/mpts-csr/eaq/auth");
        LoginRouter action = (LoginRouter) proxy.getAction();
        assertNotNull(action);
        return proxy.execute();
	}
	
	private String executeLoginRouterAction(Map<String, Object> sessionMap) throws Exception {
		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth");
        assertNotNull(proxy);
        
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        LoginRouter action = (LoginRouter) proxy.getAction();
        assertNotNull(action);
        return proxy.execute();
	}

	@Test
    public void testTokenLoginSuccess() throws Exception {
		Map<String, Object> sessionMap = loginFormSubmit();
        
        request.setParameter("TAM_OP", Constants.LOGIN_SUCCESS);
        
        String result = executeLoginRouterAction(sessionMap);
        assertEquals("redirect", result);
    }
	
	@Test
    public void testTokenLoginFailures() throws Exception {
		tokenLoginFailure(Constants.ERROR);
		tokenLoginFailure(Constants.CERT_LOGIN);
		tokenLoginFailure(Constants.CERT_STEPUP_HTTP);
		tokenLoginFailure(Constants.EAI_AUTH_ERROR);
		tokenLoginFailure(Constants.FAILED_CERT);
		tokenLoginFailure(Constants.PASS_WARN);
		tokenLoginFailure(Constants.PASS_WARN_FAILURE);
		tokenLoginFailure(Constants.STEPUP);
		tokenLoginFailure(Constants.SWITCH_USER);
		tokenLoginFailure(Constants.TOO_MANY_SESSIONS);
    }
	
	@Test
    public void testTokenLogoutSuccess() throws Exception {
		Map<String, Object> sessionMap = loginFormSubmit();
        
        request.setParameter("TAM_OP", Constants.LOGIN_SUCCESS);
        
        ActionProxy proxy = getActionProxy("/mpts-csr/app/logoutformsubmit");
        assertNotNull(proxy);
        //sessionMap = new HashMap<String, Object>();
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        AppLogout appLogout = (AppLogout) proxy.getAction();
        assertNotNull(appLogout);
 
        String result = proxy.execute();
        assertEquals(Action.SUCCESS, result);
    }
	
	@Test
    public void testRedirectAlreadyLoggedIn() throws Exception {
		Map<String, Object> sessionMap = loginFormSubmit();
        
        request.removeParameter("TAM_OP");
        
        String result = executeLoginRouterAction(sessionMap);
        assertEquals("redirect", result);
    }
	
	@Test
    public void testRedirectWithNoSuccessfulAction() throws Exception {
		Map<String, Object> sessionMap = loginFormSubmit();
        
        request.removeParameter("TAM_OP");
        
        String result = executeLoginRouterAction(sessionMap);
        assertEquals("redirect", result);
    }
 
    private void tokenLoginFailure(String opcode) throws Exception {
    	Map<String, Object> sessionMap = loginFormSubmit();

		request.setParameter("TAM_OP", opcode);
        
		String result = executeLoginRouterAction(sessionMap);
        assertEquals(Action.ERROR, result);
	}

	private Map<String, Object> loginFormSubmit() throws Exception {
    	 //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.TOKEN_LOGIN);
         
        ActionProxy proxy = getActionProxy("/mpts-csr/eaq/loginformsubmit");
        assertNotNull(proxy);
        Map<String, Object> sessionMap = new HashMap<String, Object>();
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        LoginFormSubmit loginFormSubmit = (LoginFormSubmit) proxy.getAction();
        assertNotNull(loginFormSubmit);
        
        loginFormSubmit.setLoginFormType("token");
        loginFormSubmit.setUseralias("csr1");
        loginFormSubmit.setPassword("1234");
 
        String result = proxy.execute();
        assertEquals("loginformsubmit", result);
        
        Cookie[] cookies = new Cookie[2];
        cookies[0] = new Cookie("login-form-type", "token");
        cookies[1] = new Cookie("junction", "mpts-csr");
        request.setCookies(cookies);
        
		return sessionMap;
	}

	@Override
	protected String getConfigPath() {
		return "struts.xml";
	}
	
}
