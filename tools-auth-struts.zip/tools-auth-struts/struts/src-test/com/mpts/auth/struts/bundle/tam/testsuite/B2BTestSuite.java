package com.mpts.auth.struts.bundle.tam.testsuite;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.jboss.resteasy.plugins.server.tjws.TJWSEmbeddedJaxrsServer;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.mpts.auth.struts.bundle.CommonAuthService;
import com.mpts.auth.struts.bundle.api.MyResource;
import com.mpts.auth.struts.bundle.model.DaoProviderImpl;
import com.mpts.auth.struts.bundle.model.GatewayProviderImpl;
import com.mpts.auth.struts.bundle.tam.b2b.ForgotTokenTest;
import com.mpts.auth.struts.bundle.tam.b2b.ForgotUserAliasTest;
import com.mpts.auth.struts.bundle.tam.b2b.LoginRouterTest;

@RunWith(Suite.class)
@SuiteClasses({ LoginRouterTest.class, ForgotTokenTest.class, ForgotUserAliasTest.class })
public class B2BTestSuite {

	private static TJWSEmbeddedJaxrsServer server;
	
	@BeforeClass
	public static void setUpClass() {
		CommonAuthService commonAuthService = CommonAuthService.getInstance();

		InputStream inputStream = null;
		try {
			inputStream = B2BTestSuite.class.getClassLoader().getResourceAsStream("tamConfigB2B.properties");
			Properties configuration = new Properties();
			configuration.load(inputStream);
			commonAuthService.intialize(configuration);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
				}
			}
		}

		commonAuthService.registerHomePage("loginrouter");
		commonAuthService.setDaoProvider(new DaoProviderImpl());
		commonAuthService.setGatewayProvider(new GatewayProviderImpl());

		commonAuthService.setLanguages(commonAuthService.getDaoProvider().getLanguages());
		
		commonAuthService.getLanguages();
		commonAuthService.getHomePage();
		commonAuthService.getFavicon();
		
		// for Mocking AMIS REST calls
		server = new TJWSEmbeddedJaxrsServer();
		server.setPort(12345);
		server.getDeployment().getResources().add(new MyResource());
		
		server.start();
	}

	@AfterClass
	public static void tearDownClass() {
		if(server != null) {
			server.stop();
		}
	}
}
