package com.mpts.auth.struts.bundle.tam.b2c;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.apache.struts2.StrutsJUnit4TestCase;
import org.junit.Test;

import com.mpts.auth.struts.bundle.model.Constants;
import com.mpts.auth.struts.bundle.pages.tam.LoginFormSubmit;
import com.mpts.auth.struts.bundle.pages.tam.LoginRouter;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionProxy;

public class LoginRouterTest extends StrutsJUnit4TestCase<LoginRouter> {
	
	@Override
	public void setUp() throws Exception {
		super.setUp();
	}
	
	@Test
    public void testCardHolderLogin() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.TOKEN_LOGIN);
         
        String result = executeLoginRouterAction();
        assertEquals("cardholderlogin", result);
    }
	
	@Test
    public void testPasswordExpired() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.PASS_EXPIRED);
        request.setParameter("ERROR_CODE", "0x03000000");
        request.setParameter("ERROR_TEXT", "password expired");
        
        String result = executeLoginRouterAction();
        assertEquals("passwordexpired", result);
    }
	
	@Test
    public void testLogin() throws Exception {
        //set parameters before calling getActionProxy
        request.setParameter("TAM_OP", Constants.LOGIN);
        request.setParameter("ERROR_CODE", "0x03000000");
        request.setParameter("ERROR_TEXT", "Login Required!");
        
        String result = executeLoginRouterAction();
        assertEquals("cardholderlogin", result);
    }
	
	@Test
    public void testCardHolderLoginSuccess() throws Exception {
        Map<String, Object> sessionMap = loginFormSubmit();
        
        request.setParameter("TAM_OP", Constants.LOGIN_SUCCESS);
        
        ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth");
        assertNotNull(proxy);
        //sessionMap = new HashMap<String, Object>();
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        LoginRouter loginRouter = (LoginRouter) proxy.getAction();
        assertNotNull(loginRouter);
 
        String result = proxy.execute();
        assertEquals("redirect", result);
    }
	
	private Map<String, Object> loginFormSubmit() throws Exception {
       request.setParameter("TAM_OP", Constants.TOKEN_LOGIN);
        
       ActionProxy proxy = getActionProxy("/mpts-csr/eaq/loginformsubmit");
       assertNotNull(proxy);
       Map<String, Object> sessionMap = new HashMap<String, Object>();
       proxy.getInvocation().getInvocationContext().setSession(sessionMap);

       LoginFormSubmit loginFormSubmit = (LoginFormSubmit) proxy.getAction();
       assertNotNull(loginFormSubmit);
       
       loginFormSubmit.setLoginFormType("token");
       loginFormSubmit.setUseralias("csr1");
       loginFormSubmit.setPassword("1234");

       String result = proxy.execute();
       assertEquals("loginformsubmit", result);
       
       Cookie[] cookies = new Cookie[2];
       cookies[0] = new Cookie("login-form-type", "pass");
       cookies[1] = new Cookie("junction", "mpts-csr");
       request.setCookies(cookies);
       
       return sessionMap;
	}
	
	@Test
    public void testCardHolderLoginFailure() throws Exception {
        //set parameters before calling getActionProxy
		Map<String, Object> sessionMap = loginFormSubmit();
        
        request.setParameter("TAM_OP", Constants.FAILED_CERT);
        
        ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth");
        assertNotNull(proxy);
        //sessionMap = new HashMap<String, Object>();
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        LoginRouter loginRouter = (LoginRouter) proxy.getAction();
        assertNotNull(loginRouter);
 
        String result = proxy.execute();
        assertEquals(Action.ERROR, result);
    }
 
	private String executeLoginRouterAction() throws Exception {
		ActionProxy proxy = getActionProxy("/mpts-csr/eaq/auth");
        assertNotNull(proxy);
        Map<String, Object> sessionMap = new HashMap<String, Object>();
        proxy.getInvocation().getInvocationContext().setSession(sessionMap);
 
        request.setParameter(Constants.URL, "/mpts-csr/eaq/auth");
        LoginRouter action = (LoginRouter) proxy.getAction();
        assertNotNull(action);
        return proxy.execute();
	}
	
	@Override
	protected String getConfigPath() {
		return "struts.xml";
	}
}
