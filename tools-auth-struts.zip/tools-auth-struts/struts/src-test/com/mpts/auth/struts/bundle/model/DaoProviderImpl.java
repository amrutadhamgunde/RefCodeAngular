package com.mpts.auth.struts.bundle.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.mpts.auth.struts.bundle.exception.OTPExpiredException;
import com.mpts.auth.struts.bundle.exception.UserNotFoundException;
import com.mpts.auth.struts.bundle.exception.UserNotRegisteredException;

public class DaoProviderImpl implements IDaoProvider {
	static Map<String, String> map = new HashMap<String, String>();

	@Override
	public String getClientKey() {
		return "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnmFaTncUJZwudG9WcAA+SlcdKSj8v2zxRrNbmbCPkgLuWhC/kATNXFKLOo8dvmH0PI4XMUDnxppGTaVEPD9CNR7E18MgT5V0A4KJXpj+O78OYzorEQhsUkB3HGw9o3N40slOs2bjm+w8RP1l1KPoj+WJzLhCKFk/ONcTbjDT8op8NoelND4LLJe7Le0QGRTx2c390VJd4jMq0P7uRmt7ACHVryOZwDIyHA2VIJjtLg+QtOfKNe8CKcIWasU4chZqjsZiZkL/YV8zJp6+LToiB96guzi48grpPmuahhgTPmqVp3rBe8tiq3+jVtWPEFbeB8sugEjg/Mhx44pD1OWyVwIDAQAB";
	}

	@Override
	public List<String> getSecurityQuestions() {
		List<String> securityQuestions = new ArrayList<String>();
		securityQuestions.add("que 1");
		securityQuestions.add("que 2");
		securityQuestions.add("que 3");
		securityQuestions.add("que 4");
		return securityQuestions;
	}

	@Override
	public String getTAMUserId(String userAlias) throws UserNotFoundException, UserNotRegisteredException {
		if ((userAlias != null) && ("csr1".equals(userAlias))) {
			return "tamcsr1";
		} else
		if ((userAlias != null) && ("csr2".equals(userAlias))) {
			return "tamcsr2";
		}
		throw new UserNotFoundException(userAlias + " user not found");
	}

	@Override
	public String getUserAlias(String tamUserId) throws UserNotFoundException {
		if (tamUserId != null && tamUserId.equals("tamcsr1")) {
			return "csr1";
		} else if (tamUserId != null && tamUserId.equals("tamcsr2")) {
			return "csr2";
		}
		throw new UserNotFoundException(tamUserId + " user not found");
	}

	@Override
	public Map<String, String> getUserAlias(String mobileNo, String email) throws UserNotFoundException {
		Map<String, String> userMap = new HashMap<String, String>();
		if(mobileNo.equals("1234567890") && email.equals("csr1@mail.com")) {
			userMap.put("112233", "csr1");
			return userMap;
		}
		if(mobileNo.equals("1234567890") && email.equals("csr2@mail.com")) {
			userMap.put("112233", "csr2");
			userMap.put("445566", "csr2");
			return userMap;
		}
		throw new UserNotFoundException("User not found with given mobile number and email");
	}

	@Override
	public Map<String, String> getUserContacts(String userAlias) {
			
		Map<String, String> map = new HashMap<String, String>();
		map.put(Constants.MOBILE_NO, "1234567890");
		if (userAlias.equals("csr1")) {
			map.put(Constants.EMAIL_ID, "csr1@mail.com");
		} else {
			map.put(Constants.EMAIL_ID, "csr2@mail.com");
		}
		return map;
	}

	@Override
	public void saveOTP(String userAlias, String otp) {
		map.put(userAlias, otp);
	}

	@Override
	public boolean verifyOTP(String userAlias, String otp) throws OTPExpiredException {
		return map.get(userAlias).equals(otp);
	}

	@Override
	public Map<String, String> getSecurityQuestions(String userAlias) {
		Map<String, String> secQues = new LinkedHashMap<String, String>();
		secQues.put("q1", "a1");
		secQues.put("q2", "a2");
		return secQues;
	}

	@Override
	public String generateTempPassword() {
		return "mpts@1234";
	}

	@Override
	public String getUserAliasByCardNumber(String arg0) throws UserNotFoundException {
		if("1234567890".equals(arg0)) {			
			return "csr1";
		} else if("1234567891".equals(arg0)) {			
			return "csr2";
		}
		throw new UserNotFoundException("User not found with given card number");
	}

	@Override
	public Map<String, LangLocale> getLanguages() {
		Map<String, LangLocale> langMap = new HashMap<String, LangLocale>();
		langMap.put("en", new LangLocale("en","English"));
		langMap.put("zh", new LangLocale("zh","中文"));
		return langMap;
	}
	
	public static String captureGeneratedOTP(String userAlias) {
		return map.get(userAlias);
	}

	@Override
	public String hash(String input) {
		return null;
	}
}
